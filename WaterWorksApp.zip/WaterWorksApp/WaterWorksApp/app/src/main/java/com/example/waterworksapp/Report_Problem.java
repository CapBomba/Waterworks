package com.example.waterworksapp;
import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.Html;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Report_Problem extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    private TextView hello_details;
    private boolean hasError = false;
    private RecyclerView recyclerView;
    private String URL = "https://luisianawaterworks.com/WaterWorks/Capstone/android/reports_fetch_user.php";
    private Report_Problem_Adapter reportProblemAdapter; // Ensure correct adapter type
    private List<Report_Problem_Class> reportProblemClasses = new ArrayList<>();
    private SearchView searchView;
    private Button report_button, submitButton;
    private static final int REQUEST_IMAGE_CAPTURE = Integer.MAX_VALUE - 1;
    private static final int REQUEST_CAMERA_PERMISSION = Integer.MAX_VALUE;
    private Bitmap imageBitmap;
    private boolean isFullScreen = false;
    private ImageView capturedImageView, reports_logo, no_reports_logo;
    private ImageView cameraIcon, deleteIcon;
    private TextView label_picture,delete_label,take_picture_label;
    private View formView;

    private LinearLayout linear_layout_details;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_problem);

        drawerLayout = findViewById(R.id.drawerLayout);
        NavigationView navigationView = findViewById(R.id.navigationView);
        hello_details = findViewById(R.id.hello_details);
        String bold = "<b>";
        String endBold = "</b>";
        hello_details.setText(Html.fromHtml("Facing issues with our water services? "));


        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize Report_Problem_Adapter
        reportProblemAdapter = new Report_Problem_Adapter(this, reportProblemClasses);
        recyclerView.setAdapter(reportProblemAdapter);

        // Initialize SearchView and set up search listener
        searchView = findViewById(R.id.search_view);
        setupSearchListener(searchView);

        report_button = findViewById(R.id.report_button);

        reports_logo= findViewById(R.id.reports_logo);
        no_reports_logo = findViewById(R.id.no_reports_logo);
        linear_layout_details = findViewById(R.id.linear_layout_details);

        report_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showReportFormDialog();
            }
        });

        // Check user login status and fetch data accordingly
        if (isUserLoggedIn()) {
            SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
            String meter_number = sharedPreferences.getString("meter_number", "");
            fetchDataFromServer(meter_number, null);
        } else {
            startActivity(new Intent(Report_Problem.this, MainActivity.class));
            finish();
        }

        // Set up drawer toggle button
        findViewById(R.id.buttonDrawerToggle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(navigationView)) {
                    drawerLayout.closeDrawer(navigationView);
                } else {
                    drawerLayout.openDrawer(navigationView);
                }
            }
        });

        // Set up navigation menu items
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.navHome) {
                    startActivity(new Intent(Report_Problem.this, ConsumerHome.class));
                } else if (itemId == R.id.navProfile) {
                    startActivity(new Intent(Report_Problem.this, Consumer_Profile.class));
                } else if (itemId == R.id.navHistory) {
                    startActivity(new Intent(Report_Problem.this, Report_Problem.class));
                } else if (itemId == R.id.navViolation) {
                    // Handle navigation item click for History
                    startActivity(new Intent(Report_Problem.this, Consumer_Violation.class));
                } else if (itemId == R.id.navLogout) {
                    logout();
                }
                drawerLayout.closeDrawer(navigationView);
                return true;
            }
        });
        SwipeRefreshLayout swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Add the logic to refresh your RecyclerView data here

                // Simulate a network call or data update (use your actual data refresh logic)
                refreshRecyclerViewData();

                // Once the refresh is complete, stop the refreshing animation
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }
    private void refreshRecyclerViewData() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        String meter_number = sharedPreferences.getString("meter_number", "");
        fetchDataFromServer(meter_number, null); // Reset to default data when query is cleared
    }

    private void showReportFormDialog() {
        // Inflate the form layout
        LayoutInflater inflater = LayoutInflater.from(Report_Problem.this);
        formView = inflater.inflate(R.layout.problem_inflater_form, null);

        // Retrieve saved preferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        String ref_barangay = sharedPreferences.getString("barangay", "");
        String ref_email = sharedPreferences.getString("email", "");
        String ref_meter_number = sharedPreferences.getString("meter_number", "");

        // Log retrieved preferences for debugging
        Log.d("ReportFormDialog", "Retrieved barangay: " + ref_barangay);
        Log.d("ReportFormDialog", "Retrieved email: " + ref_email);
        Log.d("ReportFormDialog", "Retrieved meter number: " + ref_meter_number);

        // Initialize the EditText fields, TextView, and ImageView
        EditText meter_number_edit = formView.findViewById(R.id.editTextMeterNumber);
        EditText emailEditText = formView.findViewById(R.id.editTextEmail);
        EditText editTextBrgy = formView.findViewById(R.id.editTextBrgy);
        EditText descriptionEditText = formView.findViewById(R.id.editTextDescription);
        TextView error_desc = formView.findViewById(R.id.error_desc);
        TextView error_pic = formView.findViewById(R.id.error_pic);
        label_picture = formView.findViewById(R.id.label_picture);
        delete_label = formView.findViewById(R.id.delete_label);
        take_picture_label = formView.findViewById(R.id.take_picture_label);

        cameraIcon = formView.findViewById(R.id.cameraIcon);
        deleteIcon = formView.findViewById(R.id.deleteIcon);
        capturedImageView = formView.findViewById(R.id.capturedImageView);

        // Set initial visibility
        error_desc.setVisibility(View.GONE);
        error_pic.setVisibility(View.GONE);
        deleteIcon.setVisibility(View.GONE);
        capturedImageView.setVisibility(View.GONE);
        delete_label.setVisibility(View.GONE);

        // Set the text of EditText fields with the retrieved preferences
        meter_number_edit.setText(ref_meter_number);
        emailEditText.setText(ref_email);
        editTextBrgy.setText(ref_barangay);

        // Set up camera icon click listener
        cameraIcon.setOnClickListener(v -> dispatchTakePictureIntent());

        // Set up delete icon click listener
        deleteIcon.setOnClickListener(v -> deletePhoto());

        // Create an AlertDialog
        AlertDialog.Builder builder = new AlertDialog.Builder(Report_Problem.this);

        // Customize the title
        TextView title = new TextView(Report_Problem.this);
        title.setText("Report Form");
        title.setPadding(50, 20, 20, 20);
        title.setTextSize(20F);
        title.setTextColor(Color.parseColor("#000000"));

        builder.setCustomTitle(title)
                .setView(formView)
                .setNegativeButton("Cancel", null);

        AlertDialog dialog = builder.create();
        dialog.show();

        // Initialize the Submit button
        Button submitButton = formView.findViewById(R.id.submit_report);
        submitButton.setOnClickListener(v -> handleFormSubmission(formView, dialog));
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            Bundle extras = data.getExtras();
            imageBitmap = (Bitmap) extras.get("data");

            // Update UI elements based on the captured image
            if (formView != null && imageBitmap != null) {
                capturedImageView.setImageBitmap(imageBitmap);
                capturedImageView.setVisibility(View.VISIBLE);  // Show captured image
                deleteIcon.setVisibility(View.VISIBLE);         // Show delete icon
                cameraIcon.setVisibility(View.GONE);            // Hide camera icon
                label_picture.setVisibility(View.GONE); // Hide label text
                take_picture_label.setVisibility(View.GONE);
                delete_label.setVisibility(View.VISIBLE);       // Show delete label
                delete_label.setText("Delete Picture");
            }
        }
    }

    private void dispatchTakePictureIntent() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            // Request camera permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, REQUEST_CAMERA_PERMISSION);
        } else {
            // Permission already granted, launch the camera
            launchCamera();
        }
    }
    private void launchCamera() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, launch the camera
                launchCamera();
            } else {
                // Permission denied, show an explanation to the user
                Toast.makeText(this, "Camera permission is required to take pictures", Toast.LENGTH_SHORT).show();
            }
        }
    }
    private void deletePhoto() {
        capturedImageView.setVisibility(View.GONE);  // Hide captured image
        deleteIcon.setVisibility(View.GONE);         // Hide delete icon
        cameraIcon.setVisibility(View.VISIBLE);      // Show camera icon
        label_picture.setVisibility(View.VISIBLE);   // Show label text
        delete_label.setVisibility(View.GONE);       // Hide delete label
        take_picture_label.setVisibility(View.VISIBLE);     // Reset label text to "Take a Picture"
        imageBitmap = null;
    }


    private void handleFormSubmission(View formView, AlertDialog dialog) {
        // Get EditText fields
        EditText meterNumberEdit = formView.findViewById(R.id.editTextMeterNumber);
        EditText emailEditText = formView.findViewById(R.id.editTextEmail);
        EditText editTextBrgy = formView.findViewById(R.id.editTextBrgy);
        EditText descriptionEditText = formView.findViewById(R.id.editTextDescription);
        TextView errorDesc = formView.findViewById(R.id.error_desc);
        TextView errorPic = formView.findViewById(R.id.error_pic);

        // Retrieve values from EditText fields
        String meterNumber = meterNumberEdit.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();
        String barangay = editTextBrgy.getText().toString().trim();
        String description = descriptionEditText.getText().toString().trim();

        // Reset error state
        boolean hasError = false;

        // Validate the description field
        if (description.isEmpty()) {
            errorDesc.setVisibility(View.VISIBLE);
            errorDesc.setText("Description is required!");
            hasError = true;
        } else {
            errorDesc.setVisibility(View.GONE);
        }

        // Validate the captured image
        if (imageBitmap == null) {
            errorPic.setVisibility(View.VISIBLE);
            errorPic.setText("Please capture an image!");
            hasError = true;
        } else {
            errorPic.setVisibility(View.GONE);
        }

        // Stop the submission process if there's an error
        if (hasError) {
            return;
        }

        // Convert Bitmap to Base64
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        imageBitmap.compress(Bitmap.CompressFormat.JPEG, 100, byteArrayOutputStream);
        byte[] imageData = byteArrayOutputStream.toByteArray();
        String imageBase64 = Base64.encodeToString(imageData, Base64.DEFAULT);

        // Log the Base64 string
        Log.d("SubmitReport", "Image Base64 String: " + imageBase64);

        // Create a HashMap for the request parameters
        HashMap<String, String> params = new HashMap<>();
        params.put("meter_number", meterNumber);
        params.put("barangay", barangay);
        params.put("email", email);
        params.put("description", description);
        params.put("photo", imageBase64);

        // Create and send the request using Volley
        StringRequest stringRequest = new StringRequest(Request.Method.POST, "https://luisianawaterworks.com/WaterWorks/Capstone/android/report_submit_consumer.php",
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            // Parse the JSON response
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            String message = jsonResponse.getString("message");

                            // Handle the server's response
                            if ("success".equals(status)) {
                                Toast.makeText(Report_Problem.this, message, Toast.LENGTH_SHORT).show();

                                dialog.dismiss(); // Close the dialog on success
                                fetchUpdatedReports(meterNumber, ""); // Update the report list
                            } else {
                                Toast.makeText(Report_Problem.this, message, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            Toast.makeText(Report_Problem.this, "Unexpected error occurred. Please try again", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = ""; // Initialize message as blank

                        // Handle specific VolleyError instances
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "An error occurred. Please try again."; // Fallback for any other error types
                        }

                        // Log the error response
                        Log.e("VolleyError", message);

                        // Display a Toast message based on the error type
                        Toast.makeText(Report_Problem.this, message, Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                return params;
            }
        };

        // Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }



    private void fetchUpdatedReports(String meterNumber, String query) {
        // Log the meter number
        Log.d("Report_Problem", "Fetching data for meter number: " + meterNumber);

        String url = URL;

        // Append meter number to URL if it exists
        if (meterNumber != null && !meterNumber.isEmpty()) {
            url += "?meter_number=" + Uri.encode(meterNumber);
        }

        // Append query to URL if it is not null or empty
        if (query != null && !query.isEmpty()) {
            url += (url.contains("?") ? "&" : "?") + "query=" + Uri.encode(query);
        }

        // Log the URL being requested
        Log.d("Report_Problem", "Requesting URL: " + url);

        // Create JSON request
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("Report_Problem", "Response received: " + response);

                        try {
                            // Parse the response as a JSON object
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");

                            if (status.equals("success")) {
                                // Extract the data array
                                JSONArray dataArray = jsonResponse.getJSONArray("data");
                                parseJsonResponse(dataArray);
                                Toast.makeText(Report_Problem.this, "Reports loaded successfully!", Toast.LENGTH_SHORT).show();
                                Toast.makeText(Report_Problem.this, "Tap the description to see the details.", Toast.LENGTH_LONG).show();
                                recyclerView.setVisibility(View.VISIBLE);
                                reports_logo.setVisibility(View.VISIBLE);
                                no_reports_logo.setVisibility(View.GONE);
                                linear_layout_details.setVisibility(View.VISIBLE);
                                searchView.setVisibility(View.VISIBLE);
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                reports_logo.setVisibility(View.GONE);
                                no_reports_logo.setVisibility(View.VISIBLE);
                                linear_layout_details.setVisibility(View.VISIBLE);
                                searchView.setVisibility(View.GONE);
                                Toast.makeText(Report_Problem.this, jsonResponse.optString("message", "No reports found"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(Report_Problem.this, "An error occurred. Please try again", Toast.LENGTH_SHORT).show();
                            recyclerView.setVisibility(View.GONE);
                            reports_logo.setVisibility(View.GONE);
                            no_reports_logo.setVisibility(View.VISIBLE);
                            linear_layout_details.setVisibility(View.GONE);
                            searchView.setVisibility(View.GONE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = "";

                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "Error occurred";
                        }

                        Toast.makeText(Report_Problem.this, message, Toast.LENGTH_SHORT).show();
                        recyclerView.setVisibility(View.GONE);
                        reports_logo.setVisibility(View.GONE);
                        no_reports_logo.setVisibility(View.VISIBLE);
                        linear_layout_details.setVisibility(View.GONE);
                        searchView.setVisibility(View.GONE);
                    }
                }
        );

        // Add request to request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

    }

    private void setupSearchListener(SearchView searchView) {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
                String meter_number = sharedPreferences.getString("meter_number", "");
                fetchDataFromServer(meter_number, query); // Fetch data based on the query
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.isEmpty()) {
                    SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
                    String meter_number = sharedPreferences.getString("meter_number", "");
                    fetchDataFromServer(meter_number, null); // Reset to default data when query is cleared
                }
                return true;
            }
        });
    }

    private void fetchDataFromServer(String meterNumber, String query) {
        // Log the meter number
        Log.d("Report_Problem", "Fetching data for meter number: " + meterNumber);

        String url = URL;

        // Append meter number to URL if it exists
        if (meterNumber != null && !meterNumber.isEmpty()) {
            url += "?meter_number=" + Uri.encode(meterNumber);
        }

        // Append query to URL if it is not null or empty
        if (query != null && !query.isEmpty()) {
            url += (url.contains("?") ? "&" : "?") + "query=" + Uri.encode(query);
        }

        // Log the URL being requested
        Log.d("Report_Problem", "Requesting URL: " + url);

        // Create JSON request
        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        Log.d("Report_Problem", "Response received: " + response);

                        try {
                            // Parse the response as a JSON object
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");

                            if (status.equals("success")) {
                                // Extract the data array
                                JSONArray dataArray = jsonResponse.getJSONArray("data");
                                parseJsonResponse(dataArray);
                                recyclerView.setVisibility(View.VISIBLE);
                                reports_logo.setVisibility(View.VISIBLE);
                                no_reports_logo.setVisibility(View.GONE);
                                linear_layout_details.setVisibility(View.VISIBLE);
                                searchView.setVisibility(View.VISIBLE);
                                Toast.makeText(Report_Problem.this, "Reports loaded successfully!", Toast.LENGTH_SHORT).show();
                                Toast.makeText(Report_Problem.this, "Tap the description to see the details.", Toast.LENGTH_LONG).show();
                            } else {
                                recyclerView.setVisibility(View.GONE);
                                reports_logo.setVisibility(View.GONE);
                                no_reports_logo.setVisibility(View.VISIBLE);
                                linear_layout_details.setVisibility(View.VISIBLE);
                                searchView.setVisibility(View.GONE);
                                Toast.makeText(Report_Problem.this, jsonResponse.optString("message", "No reports found"), Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(Report_Problem.this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
                            recyclerView.setVisibility(View.GONE);
                            reports_logo.setVisibility(View.GONE);
                            no_reports_logo.setVisibility(View.VISIBLE);
                            linear_layout_details.setVisibility(View.GONE);
                            searchView.setVisibility(View.GONE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = "";
                        Log.e("Report_Problem", "Error occurred: " + error.getMessage());

                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "Error occurred";
                        }

                        Toast.makeText(Report_Problem.this, message, Toast.LENGTH_SHORT).show();
                        recyclerView.setVisibility(View.GONE);
                        reports_logo.setVisibility(View.GONE);
                        no_reports_logo.setVisibility(View.VISIBLE);
                        linear_layout_details.setVisibility(View.GONE);
                        searchView.setVisibility(View.GONE);
                    }
                }
        );

        // Add request to request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);

        // Log after adding to request queue
        Log.d("Report_Problem", "Request added to the queue");
    }

    private void parseJsonResponse(JSONArray jsonArray) {
        try {
            Log.d("Report_Problem", "Parsing JSON Response: " + jsonArray.toString());

            // Ensure reportProblem Classes is initialized
            if (reportProblemClasses == null) {
                reportProblemClasses = new ArrayList<>();
            }

            reportProblemClasses.clear();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                Log.d("Report_Problem", "JSON Object: " + jsonObject.toString());

                // Decode the base64 image data
                String base64Image = jsonObject.optString("picture", "");
                Log.d("Report_Problem", "Base64 Image Data: " + base64Image);

                byte[] decodedString = Base64.decode(base64Image, Base64.DEFAULT);
                Bitmap bitmap = BitmapFactory.decodeByteArray(decodedString, 0, decodedString.length);

                if (bitmap == null) {
                    Log.e("Report_Problem", "Failed to decode image data.");
                } else {
                    Log.d("Report_Problem", "Image successfully decoded.");
                }

                // Create a Report_Problem_Class object with image
                Report_Problem_Class reportProblem = new Report_Problem_Class(
                        jsonObject.optString("report_id", ""),
                        jsonObject.optString("description", ""),
                        jsonObject.optString("gmail", ""),
                        jsonObject.optString("status", ""),
                        jsonObject.optString("report_time", ""),
                        jsonObject.optString("status_desc", ""),
                        jsonObject.optString("meter_num", ""),
                        jsonObject.optString("date_of_visit", ""),
                        bitmap // Add the bitmap to the reportProblem object
                );
                reportProblemClasses.add(reportProblem);
            }
            reportProblemAdapter.notifyDataSetChanged();

            if (reportProblemClasses.isEmpty()) {
                recyclerView.setVisibility(View.GONE);
                reports_logo.setVisibility(View.GONE);
                linear_layout_details.setVisibility(View.GONE);
                searchView.setVisibility(View.GONE);
                Toast.makeText(Report_Problem.this, "No reports available", Toast.LENGTH_SHORT).show();
            } else {
                recyclerView.setVisibility(View.VISIBLE);
                no_reports_logo.setVisibility(View.VISIBLE);
                linear_layout_details.setVisibility(View.VISIBLE);
                searchView.setVisibility(View.VISIBLE);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(Report_Problem.this, "An error occurred. Please try again later", Toast.LENGTH_SHORT).show();
            recyclerView.setVisibility(View.GONE);
            no_reports_logo.setVisibility(View.VISIBLE);
            linear_layout_details.setVisibility(View.GONE);
            searchView.setVisibility(View.GONE);
        }
    }


    private void logout() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                clearSessionData();
                Toast.makeText(Report_Problem.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

                Intent intent = new Intent(Report_Problem.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void clearSessionData() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.clear();
        editor.apply();
    }

    private boolean isUserLoggedIn() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        return sharedPreferences.getBoolean("isLoggedIn", false);
    }
}
