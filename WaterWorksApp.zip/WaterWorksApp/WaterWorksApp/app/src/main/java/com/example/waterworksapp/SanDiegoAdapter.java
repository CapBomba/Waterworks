package com.example.waterworksapp;

import android.content.Context;
import android.content.Intent;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.List;

    public class SanDiegoAdapter extends RecyclerView.Adapter<SanDiegoAdapter.UsersHolder> {

        Context context;
        List<SanDiego> usersList;

        public SanDiegoAdapter(Context context, List<SanDiego> usersList) {
            this.context = context;
            this.usersList = usersList;
        }

        @NonNull
        @Override
        public UsersHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View UserLayout = LayoutInflater.from(parent.getContext()).inflate(R.layout.card,parent,false);
            return new UsersHolder(UserLayout);
        }

        @Override
        public void onBindViewHolder(@NonNull UsersHolder holder, int position) {
            SanDiego user = usersList.get(position);

            String r_id = user.r_id();
            String fname = user.getFirstName();
            String lname = user.getLastName();
            String contact = user.getEmail();
            String suffix = user.getSuffix();
            String type_of_connection = user.type_of_connection();
            String meter_number = user.meter_number();
            String barangay = user.barangay();

            String bold = "<b>";
            String endBold = "</b>";
            String indent = "<br>"; // HTML entity for space repeated for indentation

            // Setting Full Name
            String fullname = fname + " " + lname + " " + suffix;
            holder.fullname_txt.setText(Html.fromHtml(bold + "Full Name" + endBold + indent + fullname));
            // Setting Email
            holder.emails_txt.setText(Html.fromHtml(bold + "Email" + endBold + indent + contact));
            // Setting Connection Type
            holder.connections_txt.setText(Html.fromHtml(bold + "Connection Type" + endBold + indent + type_of_connection));
            // Setting Meter Number
            holder.meters_txt.setText(Html.fromHtml(bold + "Meter Number" + endBold + indent + meter_number));

            // Set click listener for the "Reading" button
            holder.readingButton.setOnClickListener(new View.OnClickListener()
            { @Override public void onClick(View v) {
                // Fetch last data from the month
                String URL = "https://luisianawaterworks.com/WaterWorks/Capstone/android/fetch_date_last_month_android.php";

            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    // Handle the response
                    // Parse the response JSON or process the data as needed
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        String responseStatus = jsonResponse.optString("response"); // Rename variable to avoid conflict
                        if ("failure".equalsIgnoreCase(responseStatus)) {
                            // Failed to fetch data
                            Toast.makeText(context, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                        } else {
                            // Extract data from JSON response
                            String past = jsonResponse.getString("present");
                            String status = jsonResponse.getString("status");
                            String date = jsonResponse.getString("date");

                            // Handle button click event
                            Intent intent = new Intent(context, MeterReading.class);

                            // Attach data to the intent
                            intent.putExtra("r_id", r_id);
                            intent.putExtra("fname", fname);
                            intent.putExtra("lname", lname);
                            intent.putExtra("suffix", suffix);
                            intent.putExtra("contact", contact);
                            intent.putExtra("type_of_connection", type_of_connection);
                            intent.putExtra("meter_number", meter_number);
                            intent.putExtra("barangay", barangay);
                            // Pass the fetched data as extras in the intent
                            intent.putExtra("present", past);
                            intent.putExtra("status", status);
                            intent.putExtra("date", date);

                            // Start the activity
                            context.startActivity(intent);
                            notifyDataSetChanged();
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(context, "Error parsing JSON response", Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String message = ""; // Initialize message as blank

                    // Handle specific VolleyError instances
                    if (error instanceof TimeoutError) {
                        message = "Request timed out";
                    } else if (error instanceof NoConnectionError) {
                        message = "No internet connection";
                    } else if (error instanceof ServerError) {
                        message = "Server error";
                    } else if (error instanceof NetworkError) {
                        message = "Network error";
                    } else {
                        message = "Logout failed. Please try again."; // Fallback for any other error types
                    }

                    // Display Toast message based on the error response
                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("r_id", r_id);
                    return params;
                }
            };

            // Add the request to the RequestQueue
            RequestQueue requestQueue = Volley.newRequestQueue(context);
            requestQueue.add(stringRequest);
        }
    });
            }


        @Override
        public int getItemCount() {
            return usersList.size();
        }

        public class UsersHolder extends RecyclerView.ViewHolder {
            TextView fullname_txt, emails_txt, meters_txt, connections_txt;
            ConstraintLayout Layout;
            Button readingButton; // Add this line

            public UsersHolder(@NonNull View itemView) {
                super(itemView);
                fullname_txt = itemView.findViewById(R.id.fullname_txt);
                emails_txt = itemView.findViewById(R.id.emails_txt);
                meters_txt = itemView.findViewById(R.id.meters_txt);
                connections_txt = itemView.findViewById(R.id.connections_txt);
                Layout = itemView.findViewById(R.id.card);
                readingButton = itemView.findViewById(R.id.reading_button); // Initialize the button
            }
        }
    }