package com.example.waterworksapp;

public class Notification_History_Call{
    private String notif_id, content_title, content_text, date_time;

    public Notification_History_Call(String notif_id,String content_title, String content_text,String date_time) {
        this.notif_id = notif_id;
        this.content_title = content_title;
        this.content_text = content_text;
        this.date_time = date_time;
    }

    public String getNotif_id() {
        return notif_id;
    }
    public String getContent_title() {
        return content_title;
    }
    public String getContent_text() {
        return content_text;
    }
    public String getDate_time() {
        return date_time;
    }

}