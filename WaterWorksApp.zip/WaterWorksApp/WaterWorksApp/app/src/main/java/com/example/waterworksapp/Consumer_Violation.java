package com.example.waterworksapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Consumer_Violation extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private RecyclerView recyclerView;
    private Consumer_Violation_Adapter ConsumerViolationAdapter;

    private ImageView consumer_violation, no_consumer_violation;

    private LinearLayout violation_linear ,linear_recycler;

    private List<Consumer_Violation_Class> consumerViolationList = new ArrayList<Consumer_Violation_Class>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumer_violation);

        drawerLayout = findViewById(R.id.drawerLayout);
        navigationView = findViewById(R.id.navigationView);
        recyclerView = findViewById(R.id.recyclerView); // Ensure recyclerView is initialized
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        ConsumerViolationAdapter = new Consumer_Violation_Adapter(this, consumerViolationList);
        recyclerView.setAdapter(ConsumerViolationAdapter);

        consumer_violation = findViewById(R.id.consumer_violation);
        no_consumer_violation = findViewById(R.id.no_consumer_violation);
        violation_linear = findViewById(R.id.violation_linear);
        linear_recycler = findViewById(R.id.linear_recycler);

        findViewById(R.id.buttonDrawerToggle).setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(navigationView)) {
                drawerLayout.closeDrawer(navigationView);
            } else {
                drawerLayout.openDrawer(navigationView);
            }
        });


        navigationView.setNavigationItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.navHome) {
                startActivity(new Intent(Consumer_Violation.this, ConsumerHome.class));
            } else if (itemId == R.id.navProfile) {
                startActivity(new Intent(Consumer_Violation.this, Consumer_Profile.class));
            } else if (itemId == R.id.navHistory) {
                startActivity(new Intent(Consumer_Violation.this, Report_Problem.class));
            } else if (itemId == R.id.navViolation) {
                startActivity(new Intent(Consumer_Violation.this, Consumer_Violation.class));
            } else if (itemId == R.id.navLogout) {
                logout();
            }
            drawerLayout.closeDrawer(navigationView);
            return true;
        });

        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        int r_id = sharedPreferences.getInt("r_id", 0);

        // Call viewhistory with only the reader ID
        viewhistory(r_id);

        SwipeRefreshLayout swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Add the logic to refresh your RecyclerView data here

                // Simulate a network call or data update (use your actual data refresh logic)
                refreshRecyclerViewData();

                // Once the refresh is complete, stop the refreshing animation
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }
    private void refreshRecyclerViewData() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        int r_id = sharedPreferences.getInt("r_id", 0);
        viewhistory(r_id); // Reset to default data when query is cleared
    }

    private void viewhistory(int r_id) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/violation_bills.php?readers_id=" + r_id;
        Log.d("ConsumerViolationHistory", "Requesting history for Consumer ID: " + r_id);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    Log.d("ConsumerViolationHistory", "Response: " + response);
                    try {
                        JSONObject jsonResponse = new JSONObject(response);

                        if (jsonResponse.has("status")) {
                            String status = jsonResponse.getString("status");

                            if (status.equals("success")) {
                                Toast.makeText(Consumer_Violation.this, "Violation loaded successfully", Toast.LENGTH_SHORT).show();
                                Toast.makeText(Consumer_Violation.this, "Tap the white card to see the details", Toast.LENGTH_SHORT).show();
                                JSONArray jsonArray = jsonResponse.getJSONArray("data");
                                List<String> years = new ArrayList<>(); // To store unique years

                                consumerViolationList.clear(); // Clear previous data

                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    String r_id1 = jsonObject.getString("r_id");
                                    String past = jsonObject.getString("past");
                                    String present = jsonObject.getString("present");
                                    String m3 = jsonObject.getString("m3");
                                    String price = jsonObject.getString("price");
                                    String bill_status = jsonObject.getString("bill_status");
                                    String date = jsonObject.getString("date");
                                    String due_date = jsonObject.getString("due_date");
                                    String violation = jsonObject.getString("violation");
                                    String penalty = jsonObject.getString("penalty");
                                    String discount = jsonObject.getString("discount");
                                    String total_due = jsonObject.getString("total_due");
                                    String date_paid = jsonObject.getString("date_paid");
                                    String vio_history = jsonObject.getString("vio_history");

                                    // Add the bill to the list
                                    Consumer_Violation_Class billItem = new Consumer_Violation_Class(r_id1, past, present, m3, price, bill_status, date,
                                            due_date, violation, penalty, discount, total_due, date_paid, vio_history);
                                    consumerViolationList.add(billItem);

                                    Log.d("ViewHistory", "Added bill: " + billItem);
                                }
                                // Populate the spinner with years
                                populateYearSpinner();
                                ConsumerViolationAdapter.notifyDataSetChanged(); // Update adapter

                                consumer_violation.setVisibility(View.VISIBLE);
                                no_consumer_violation.setVisibility(View.GONE);
                                violation_linear.setVisibility(View.VISIBLE);
                                linear_recycler.setVisibility(View.VISIBLE);

                            } else if (status.equals("failure")) {
                                String message = jsonResponse.getString("message");
                                Toast.makeText(Consumer_Violation.this, "" + message, Toast.LENGTH_SHORT).show();
                                consumer_violation.setVisibility(View.GONE);
                                no_consumer_violation.setVisibility(View.VISIBLE);
                                violation_linear.setVisibility(View.GONE);
                                linear_recycler.setVisibility(View.GONE);
                            }
                        } else {
                            Toast.makeText(Consumer_Violation.this, "Unexpected error occurred. Please try again.", Toast.LENGTH_SHORT).show();
                            consumer_violation.setVisibility(View.GONE);
                            no_consumer_violation.setVisibility(View.VISIBLE);
                            violation_linear.setVisibility(View.GONE);
                            linear_recycler.setVisibility(View.GONE);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(Consumer_Violation.this, "Unexpected error occurred. Please try again.", Toast.LENGTH_SHORT).show();
                        consumer_violation.setVisibility(View.GONE);
                        no_consumer_violation.setVisibility(View.VISIBLE);
                        violation_linear.setVisibility(View.GONE);
                        linear_recycler.setVisibility(View.GONE);
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = ""; // Initialize message as blank

                        // Handle specific VolleyError instances
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "Request failed. Please try again."; // Fallback for any other error types
                        }

                        // Display Toast message based on the error response
                        Toast.makeText(Consumer_Violation.this, message, Toast.LENGTH_SHORT).show();
                        consumer_violation.setVisibility(View.GONE);
                        no_consumer_violation.setVisibility(View.VISIBLE);
                        violation_linear.setVisibility(View.GONE);
                        linear_recycler.setVisibility(View.GONE);
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }


    private void populateYearSpinner() {
        Set<String> years = new HashSet<>(); // Use a Set to avoid duplicate years

        // Extract years from billList
        for (Consumer_Violation_Class bill : consumerViolationList) {
            String dateString = bill.getDate(); // Assuming getDate() returns date in "YYYY-MM-DD" format
            Log.d("PopulateYearSpinner", "Date from bill: " + dateString); // Log the date string

            int year = getYearFromDate(dateString);
            if (year != -1) {
                years.add(String.valueOf(year));
            }
        }

        Log.d("PopulateYearSpinner", "Years extracted: " + years); // Log the extracted years

        // Convert Set to List and sort it in ascending order
        List<String> sortedYears = new ArrayList<>(years);
        Collections.sort(sortedYears); // Sort in ascending order

        // Find Spinner in layout and set up adapter
        Spinner yearSpinner = findViewById(R.id.get_year);

        if (yearSpinner != null) {
            ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, sortedYears);
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            yearSpinner.setAdapter(adapter);

            // Set default value to the current year
            String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
            if (sortedYears.contains(currentYear)) {
                // If the current year is in the list, select it
                yearSpinner.setSelection(sortedYears.indexOf(currentYear));
            } else if (!sortedYears.isEmpty()) {
                // If the current year is not in the list, select the first year
                yearSpinner.setSelection(0);
            }

            // Set spinner item selected listener
            yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    String selectedYear = (String) parent.getItemAtPosition(position);
                    Log.d("PopulateYearSpinner", "Selected year: " + selectedYear); // Log selected year

                    // Filter records based on selected year
                    filterRecordsByYear(selectedYear);
                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                    // Do nothing
                }
            });
        } else {
            Log.e("PopulateYearSpinner", "Spinner is null. Check layout inflation.");
        }
    }

    private int getYearFromDate(String dateString) {
        try {
            // Assuming date is in "YYYY-MM-DD" format
            String[] parts = dateString.split("-");
            return Integer.parseInt(parts[0]);
        } catch (Exception e) {
            e.printStackTrace();
            return -1; // Return -1 if parsing fails
        }
    }
    private void filterRecordsByYear(String year) {
        List<Consumer_Violation_Class> filteredList = new ArrayList<>();

        // Filter records based on the selected year
        for (Consumer_Violation_Class bill : consumerViolationList) {
            String dateString = bill.getDate(); // Assuming getDate() returns date in "YYYY-MM-DD" format
            int billYear = getYearFromDate(dateString);
            if (billYear != -1 && String.valueOf(billYear).equals(year)) {
                filteredList.add(bill);
            }
        }

        Log.d("FilterRecordsByYear", "Filtered records: " + filteredList.size()); // Log the number of filtered records

        // Update the UI with the filtered records
        updateUIWithFilteredRecords(filteredList);
        displayStatusCounts(filteredList);
    }

    private void updateUIWithFilteredRecords(List<Consumer_Violation_Class> filteredList) {
        if ( ConsumerViolationAdapter != null) {
            ConsumerViolationAdapter.updateData(filteredList); // Update the adapter with filtered data
        }
    }

    private void displayStatusCounts(List<Consumer_Violation_Class> records) {
        double totalPrice = 0.0; // Variable to hold the total price
        double totalPenalty = 0.0; // Variable to hold the total penalty

        // Calculate total price and total penalties from all records
        for (Consumer_Violation_Class record : records) {
            // Add the price of the current record to totalPrice
            double price = Double.parseDouble(record.getPrice());
            totalPrice += price;

            // Calculate months overdue from violation history
            int monthsOverdue = calculateMonthsOverdueFromHistory(record.getVio_history());

            // Determine penalty based on months overdue
            double penaltyRate;
            if (monthsOverdue >= 3) {
                penaltyRate = 0.30; // 30% for 3 months or more
            } else if (monthsOverdue == 2) {
                penaltyRate = 0.20; // 20% for 2 months
            } else if (monthsOverdue == 1) {
                penaltyRate = 0.10; // 10% for 1 month
            } else {
                penaltyRate = 0.0; // No penalty for less than 1 month
            }

            // Calculate penalty for this record and add it to totalPenalty
            totalPenalty += price * penaltyRate;
        }

        // Display the total price in the UI with HTML formatting
        String statusMessage = String.format("Total Bill Price: <b>%.2f Php</b>", totalPrice);
        TextView total_amount_w_violation = findViewById(R.id.total_amount_w_violation);
        total_amount_w_violation.setText(Html.fromHtml(statusMessage)); // Use Html.fromHtml to format the text

        // Display total penalty amount if needed
        String penaltyMessage = String.format("Total Penalty: <b>%.2f Php</b>", totalPenalty);
        TextView computation = findViewById(R.id.computation);
        computation.setText(Html.fromHtml(penaltyMessage)); // Use Html.fromHtml to format the text

        // Calculate the total computation sum
        double totalComputationSum = totalPrice + totalPenalty;

        // Display the total computation sum
        String totalComputationMessage = String.format("Total Amount: <b>%.2f Php</b>", totalComputationSum);
        TextView total_computation = findViewById(R.id.total_computation);
        total_computation.setText(Html.fromHtml(totalComputationMessage)); // Use Html.fromHtml to format the text
    }

    private int calculateMonthsOverdueFromHistory(String vioHistory) {
        // Example format: "2 months overdue"
        if (vioHistory == null || vioHistory.trim().isEmpty()) {
            return 0; // No history available
        }

        // Use a regular expression to extract the number of months from the string
        Pattern pattern = Pattern.compile("(\\d+)\\s*months?\\s*overdue", Pattern.CASE_INSENSITIVE);
        Matcher matcher = pattern.matcher(vioHistory);

        if (matcher.find()) {
            // Extract the number of months
            String monthsString = matcher.group(1);
            try {
                // Parse the extracted value to an integer
                return Integer.parseInt(monthsString);
            } catch (NumberFormatException e) {
                e.printStackTrace();
                return 0; // Return 0 if parsing fails
            }
        }

        // If the pattern doesn't match, return 0
        return 0;
    }

    private void logout() {
        // Create a confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Call PHP script for logout
                clearSessionData();
                Toast.makeText(Consumer_Violation.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

                // Redirect to MainActivity
                Intent intent = new Intent(Consumer_Violation.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear the back stack
                startActivity(intent);
                finish(); // Finish the current activity to prevent returning to it by pressing the back button
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Do nothing, simply dismiss the dialog
                dialogInterface.dismiss();
            }
        });

        // Display the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void clearSessionData() {
        // Clear user session data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.clear();
        editor.apply();
    }

}