package com.example.waterworksapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import org.json.JSONArray;
import org.json.JSONException;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.method.PasswordTransformationMethod;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.text.TextUtils;
import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.json.JSONObject;
import androidx.core.content.ContextCompat;
import androidx.work.Data;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;

import android.Manifest;
import android.content.pm.PackageManager;

public class MainActivity extends AppCompatActivity {

    private EditText eUsername, ePassword;
    private Button buttonLogin;
    private String URL = "https://luisianawaterworks.com/WaterWorks/Capstone/android/login_android.php";
    private boolean passwordVisible = false;
    private ImageView showPasswordImageView;
    List<String> violationsList = new ArrayList<>();
    List<String> dueDatesList = new ArrayList<>();
    List<String> statusList = new ArrayList<>();
    List<String> reportStatusList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eUsername = findViewById(R.id.eUsername);
        ePassword = findViewById(R.id.ePassword);
        buttonLogin = findViewById(R.id.buttonLogin);
        showPasswordImageView = findViewById(R.id.imageViewShowPassword);
        TextView forgotPasswordTextView = findViewById(R.id.forgotPasswordTextView);

        // Create a SpannableString with underline
        SpannableString content = new SpannableString("Forgot Password?");
        content.setSpan(new UnderlineSpan(), 0, content.length(), 0);

        // Set the SpannableString to the TextView
        forgotPasswordTextView.setText(content);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(getApplicationContext(),
                    Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 101);
            }
        }

        // Set onClickListener for the imageView to toggle password visibility
        showPasswordImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePasswordVisibility();
            }
        });

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                login();
            }
        });
        checkAndNavigateToHomeScreen();
        scheduleClearDataWorker();
        scheduleCacheAndDataClearing();
    }
    private void checkAndNavigateToHomeScreen() {
        // Check "user_session" first
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        boolean isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
        if (isLoggedIn) {
            // User is already logged in, navigate to the appropriate activity
            if (sharedPreferences.getString("role", "").equals("readers")) {
                Intent intent = new Intent(MainActivity.this, Success.class);
                startActivity(intent);
                finish();
            }
        } else {
            // Check "user_sessions"
            sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
            isLoggedIn = sharedPreferences.getBoolean("isLoggedIn", false);
            if (isLoggedIn) {
                // User is already logged in, navigate to the appropriate activity
                if (sharedPreferences.getString("role", "").equals("consumers")) {
                    // Retrieve user data and trigger notifications
                    retrieveUserDatas();

                    Intent intent = new Intent(MainActivity.this, ConsumerHome.class);
                    startActivity(intent);
                    finish();
                }
            } else {
                // User is not logged in, display the login screen
                // No additional code needed here
            }
        }
    }

    private void retrieveUserDatas() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        Log.d("RetrieveUserDatas", "retrieveUserDatas() method called");

        List<String> statusList = new ArrayList<>();
        List<String> violationsList = new ArrayList<>();
        List<String> dueDatesList = new ArrayList<>();
        List<String> reportsList = new ArrayList<>();

        // Retrieve status list
        String statusValues = sharedPreferences.getString("statusValues", "");
        if (!statusValues.isEmpty()) {
            statusList = Arrays.asList(statusValues.split(", "));
            for (String status : statusList) {
                Log.d("NotificationCheck", "Status value: " + status); // Log each status
            }
        }

        // Retrieve violations list
        String violations = sharedPreferences.getString("violations", "");
        if (!violations.isEmpty()) {
            violationsList = Arrays.asList(violations.split(", "));
            for (String violation : violationsList) {
                Log.d("NotificationCheck", "Violation value: " + violation); // Log each violation
            }
        }

        // Retrieve due dates list
        String dueDates = sharedPreferences.getString("dueDates", "");
        if (!dueDates.isEmpty()) {
            dueDatesList = Arrays.asList(dueDates.split(", "));
            for (String dueDate : dueDatesList) {
                Log.d("NotificationCheck", "Due Date value:" + dueDate); // Log each due date
            }
        }

        // Retrieve reports list
        String reports = sharedPreferences.getString("ReportsValues", "");
        if (!reports.isEmpty()) {
            reportsList = Arrays.asList(reports.split(", "));
            for (String report : reportsList) {
                Log.d("NotificationCheck", "Report value: " + report); // Log each report
            }
        }

        checkAndTriggerNotifications(statusList, violationsList, dueDatesList, reportsList);
    }


    private void checkAndTriggerNotifications(List<String> statusList, List<String> violationsList, List<String> dueDatesList, List<String> reportsList ){
        Log.d("checkAndTriggerNotifications", "checkAndTriggerNotifications() method called");
        boolean hasUnpaidStatus = false;
        boolean hasDeclinedReports = false;
        boolean hasAcceptedReports = false;
        boolean hasTakingActionReports = false;

        for (String status : statusList) {
            Log.d("NotificationCheck", "Status: " + status); // Log each status
            if (status.equalsIgnoreCase("unpaid")) {
                hasUnpaidStatus = true;
                break;
            }
        }

        // Trigger notifications if there are any unpaid statuses
        if (hasUnpaidStatus) {
            OneTimeWorkRequest notificationWork = new OneTimeWorkRequest.Builder(NotificationWorker.class).build();
            WorkManager.getInstance(this).enqueue(notificationWork);
        }

        for (String reports : reportsList){
            Log.d("NotificationCheck", "Report: "+ reports);
            if (reports.equalsIgnoreCase("Declined")){
                hasDeclinedReports = true;
            } else if (reports.equalsIgnoreCase("Accepted")){
                hasAcceptedReports = true;
            } else if (reports.equalsIgnoreCase("Taking Action")){
                hasTakingActionReports = true;
            }
        }
        // Check for report statuses
        for (String report : reportsList) {
            Log.d("NotificationCheck", "Report: " + report); // Log each report
            if (report.equalsIgnoreCase("Declined")) {
                hasDeclinedReports = true;
            } else if (report.equalsIgnoreCase("Accepted")) {
                hasAcceptedReports = true;
            } else if (report.equalsIgnoreCase("Taking Action")) {
                hasTakingActionReports = true;
            }
        }

        // Trigger notifications for report statuses
        if (hasDeclinedReports) {
            OneTimeWorkRequest notificationWork = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                    .setInputData(new Data.Builder().putString("notification_type", "declined_report_notification").build())
                    .build();
            WorkManager.getInstance(this).enqueue(notificationWork);
        }

        if (hasAcceptedReports) {
            OneTimeWorkRequest notificationWork = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                    .setInputData(new Data.Builder().putString("notification_type", "accepted_report_notification").build())
                    .build();
            WorkManager.getInstance(this).enqueue(notificationWork);
        }

        if (hasTakingActionReports) {
            OneTimeWorkRequest notificationWork = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                    .setInputData(new Data.Builder().putString("notification_type", "taking_action_report_notification").build())
                    .build();
            WorkManager.getInstance(this).enqueue(notificationWork);
        }

        // Process due dates
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        long threeMonthsInDays = 90;

        for (String dueDateStr : dueDatesList) {
            Log.d("NotificationCheck", "Due Date: " + dueDateStr); // Log each due date
            try {
                Date dueDate = dateFormat.parse(dueDateStr);
                if (dueDate != null) {
                    long currentTime = System.currentTimeMillis();
                    long dueDateTime = dueDate.getTime();
                    long diffInMillis = dueDateTime - currentTime;
                    long daysRemaining = TimeUnit.DAYS.convert(diffInMillis, TimeUnit.MILLISECONDS);
                    long overdueDays = (currentTime - dueDate.getTime()) / (1000 * 60 * 60 * 24);

                    Data inputData;
                    OneTimeWorkRequest workRequest;

                    if (overdueDays > threeMonthsInDays) {
                        inputData = new Data.Builder()
                                .putString("notification_type", "disconnection_notice")
                                .putLong("overdue_days", overdueDays)
                                .build();
                        workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                .setInputData(inputData)
                                .build();
                        WorkManager.getInstance(this).enqueue(workRequest);
                    } else if (overdueDays > 0) {
                        inputData = new Data.Builder()
                                .putString("notification_type", "violation_overdue")
                                .putLong("overdue_days", overdueDays)
                                .build();
                        workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                .setInputData(inputData)
                                .build();
                        WorkManager.getInstance(this).enqueue(workRequest);
                    }

                    if (daysRemaining == 0) {
                        inputData = new Data.Builder()
                                .putString("notification_type", "unpaid_bills_due_today")
                                .build();
                        workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                .setInputData(inputData)
                                .build();
                        WorkManager.getInstance(this).enqueue(workRequest);
                    } else if (daysRemaining > 0) {
                        inputData = new Data.Builder()
                                .putString("notification_type", "unpaid_bills_approaching")
                                .putLong("days_remaining", daysRemaining)
                                .build();
                        workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                .setInputData(inputData)
                                .build();
                        WorkManager.getInstance(this).enqueue(workRequest);
                    }
                }
            } catch (ParseException e) {
                e.printStackTrace();
                Log.e("NotificationCheck", "Error parsing due_date", e);
            }
        }
    }

    private void login() {
        String username = eUsername.getText().toString().trim();
        String password = ePassword.getText().toString().trim();

        // Validate username and password
        if (TextUtils.isEmpty(username)) {
            Toast.makeText(MainActivity.this, "Username cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            Toast.makeText(MainActivity.this, "Password cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                try {
                    JSONObject jsonResponse = new JSONObject(response);
                    Log.d("ServerResponse", "Response: " + response);
                    String status = jsonResponse.optString("status");

                    if ("success".equalsIgnoreCase(status)) {
                        String role = jsonResponse.optString("role");

                        if ("readers".equalsIgnoreCase(role)) {
                            int readers_id = jsonResponse.getInt("readers_id");
                            String firstname = jsonResponse.getString("firstname");
                            String lastname = jsonResponse.getString("lastname");
                            String suffix = jsonResponse.getString("suffix");
                            String contact = jsonResponse.getString("contact");
                            String email = jsonResponse.getString("email");
                            String login_info = jsonResponse.getString("login_info");
                            String username = jsonResponse.getString("username");
                            Log.d("LoginInfo", "Readers Login_Info value: " + login_info);

                            if (login_info.equalsIgnoreCase("new")) {
                                // Start Readers_First_Creation_Account activity if login_info is "new"
                                Intent intent = new Intent(MainActivity.this, Readers_First_Creation_Account.class);
                                intent.putExtra("readers_id", readers_id);
                                intent.putExtra("firstname", firstname);
                                intent.putExtra("lastname", lastname);
                                intent.putExtra("suffix", suffix);
                                intent.putExtra("contact", contact);
                                intent.putExtra("email", email);
                                intent.putExtra("username", username);
                                startActivity(intent);
                                finish(); // Close MainActivity
                            } else if (login_info.equalsIgnoreCase("old")) {
                                // Save user data and start Success activity if login_info is "old"
                                saveUserData(username, firstname, lastname, suffix, contact, email, readers_id);
                                Intent homeIntent = new Intent(MainActivity.this, Success.class);
                                startActivity(homeIntent);
                                finish(); // Close MainActivity
                            }
                        } else if ("consumers".equalsIgnoreCase(role)) {
                            int r_id = jsonResponse.getInt("r_id");
                            String firstname = jsonResponse.getString("firstname");
                            String username = jsonResponse.getString("username");
                            String lastname = jsonResponse.getString("lastname");
                            String suffix = jsonResponse.getString("suffix");
                            String contact = jsonResponse.getString("contact");
                            String barangay = jsonResponse.getString("barangay");
                            String email = jsonResponse.getString("email");
                            String login_info = jsonResponse.getString("login_info");
                            String meter_number = jsonResponse.getString("meter_number");
                            String type_of_connection = jsonResponse.getString("type_of_connection");
                            Log.d("LoginInfo", "Consumer Login_Info value: " + login_info);


                            boolean hasUnpaidStatus = false;

                            // Handle status values
                            JSONArray statusValuesArray = jsonResponse.getJSONArray("status_values");
                            for (int i = 0; i < statusValuesArray.length(); i++) {
                                String statusValue = statusValuesArray.getString(i);
                                Log.d("MyTag", "Status value: " + statusValue);
                                statusList.add(statusValue);

                                if (statusValue.equalsIgnoreCase("unpaid")) {
                                    hasUnpaidStatus = true;
                                }
                            }

                            // Trigger notifications if there are any unpaid statuses
                            if (hasUnpaidStatus) {
                                OneTimeWorkRequest notificationWork = new OneTimeWorkRequest.Builder(NotificationWorker.class).build();
                                WorkManager.getInstance(MainActivity.this).enqueue(notificationWork);
                            }

                            JSONArray probReportsArray = jsonResponse.getJSONArray("reports");

                            boolean hasDeclinedReports = false;
                            boolean hasAcceptedReports = false;
                            boolean hasTakingActionReports = false;


                            // Iterate through each report
                            for (int i = 0; i < probReportsArray.length(); i++) {
                                String report = probReportsArray.getString(i);// Make sure "status" matches your JSON key
                                Log.d("Report Tag", "Report status: " + report);
                                reportStatusList.add(report);

                                if (report.equalsIgnoreCase("Declined")) {
                                    hasDeclinedReports = true;
                                } else if (report.equalsIgnoreCase("Accepted")) {
                                    hasAcceptedReports = true;
                                } else if (report.equalsIgnoreCase("Taking Action")) {
                                    hasTakingActionReports = true;
                                }
                            }

                            // Trigger notifications based on the report status
                            if (hasDeclinedReports) {
                                triggerNotificationForReportStatus("declined_report_notification");
                            }

                            if (hasAcceptedReports) {
                                triggerNotificationForReportStatus("accepted_report_notification");
                            }

                            if (hasTakingActionReports) {
                                triggerNotificationForReportStatus("taking_action_report_notification");
                            }


                            // Handle violations
                            JSONArray violationsArray = jsonResponse.optJSONArray("violations");
                            if (violationsArray != null) {
                                for (int i = 0; i < violationsArray.length(); i++) {
                                    String violation = violationsArray.getString(i);
                                    Log.d("MyViolation", "Violation value: " + violation);
                                    violationsList.add(violation); // Add to the list

                                    if (violation.toLowerCase().contains("overdue")) {
                                        // If you only care about overdue violations, you can set a flag or break
                                        // hasViolations = true;
                                        break; // Exit loop if we found an "overdue" violation
                                    }
                                }
                            } else if (jsonResponse.has("violation")) {
                                // Handle single violation if it's not an array
                                String violation = jsonResponse.getString("violation");
                                Log.d("MyViolation", "Violation value: " + violation);
                                violationsList.add(violation); // Add to the list

                                if (violation.toLowerCase().contains("overdue")) {
                                    // If you only care about overdue violations, you can set a flag or break
                                    // hasViolations = true;
                                }
                            }

                            // Handle due_date
                            JSONArray dueDatesArray = jsonResponse.optJSONArray("due_dates");
                            if (dueDatesArray != null) {
                                for (int i = 0; i < dueDatesArray.length(); i++) {
                                    String dueDate = dueDatesArray.getString(i);
                                    Log.d("MyDuedate", "Due_date value: " + dueDate);
                                    dueDatesList.add(dueDate); // Add to the list

                                    // Process each due date
                                    try {
                                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                                        Date dueDateParsed = dateFormat.parse(dueDate);

                                        if (dueDateParsed != null) {
                                            long currentTime = System.currentTimeMillis();
                                            long dueDateTime = dueDateParsed.getTime();
                                            long diffInMillis = dueDateTime - currentTime;
                                            long daysRemaining = TimeUnit.DAYS.convert(diffInMillis, TimeUnit.MILLISECONDS);
                                            long overdueDays = (currentTime - dueDateParsed.getTime()) / (1000 * 60 * 60 * 24);
                                            long threeMonthsInDays = 90; // Approximate days in 3 months

                                            Log.d("NotificationCheck", "Days until due date: " + daysRemaining);
                                            Log.d("NotificationCheck", "Overdue days: " + overdueDays);

                                            Data inputData;
                                            OneTimeWorkRequest workRequest;

                                            if (overdueDays > threeMonthsInDays) {
                                                inputData = new Data.Builder()
                                                        .putString("notification_type", "disconnection_notice")
                                                        .putLong("overdue_days", overdueDays)
                                                        .build();
                                                workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                                        .setInputData(inputData)
                                                        .build();
                                                WorkManager.getInstance(MainActivity.this).enqueue(workRequest);
                                            } else if (overdueDays > 0) {
                                                inputData = new Data.Builder()
                                                        .putString("notification_type", "violation_overdue")
                                                        .putLong("overdue_days", overdueDays)
                                                        .build();
                                                workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                                        .setInputData(inputData)
                                                        .build();
                                                WorkManager.getInstance(MainActivity.this).enqueue(workRequest);
                                            }

                                            if (daysRemaining == 0) {
                                                inputData = new Data.Builder()
                                                        .putString("notification_type", "unpaid_bills_due_today")
                                                        .build();
                                                workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                                        .setInputData(inputData)
                                                        .build();
                                                WorkManager.getInstance(MainActivity.this).enqueue(workRequest);
                                            } else if (daysRemaining > 0) {
                                                inputData = new Data.Builder()
                                                        .putString("notification_type", "unpaid_bills_approaching")
                                                        .putLong("days_remaining", daysRemaining)
                                                        .build();
                                                workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                                        .setInputData(inputData)
                                                        .build();
                                                WorkManager.getInstance(MainActivity.this).enqueue(workRequest);
                                            }
                                        }
                                    } catch (ParseException e) {
                                        e.printStackTrace();
                                        Log.e("MyDuedate", "Error parsing due_date", e);
                                    }
                                }
                            } else if (jsonResponse.has("due_date")) {
                                // Handle single due date if it's not an array
                                String dueDate = jsonResponse.getString("due_date");
                                Log.d("MyDuedate", "Due_date value: " + dueDate);
                                dueDatesList.add(dueDate); // Add to the list

                                try {
                                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                                    Date dueDateParsed = dateFormat.parse(dueDate);

                                    if (dueDateParsed != null) {
                                        long currentTime = System.currentTimeMillis();
                                        long dueDateTime = dueDateParsed.getTime();
                                        long diffInMillis = dueDateTime - currentTime;
                                        long daysRemaining = TimeUnit.DAYS.convert(diffInMillis, TimeUnit.MILLISECONDS);
                                        long overdueDays = (currentTime - dueDateParsed.getTime()) / (1000 * 60 * 60 * 24);
                                        long threeMonthsInDays = 90; // Approximate days in 3 months

                                        Log.d("NotificationCheck", "Days until due date: " + daysRemaining);
                                        Log.d("NotificationCheck", "Overdue days: " + overdueDays);

                                        Data inputData;
                                        OneTimeWorkRequest workRequest;

                                        if (overdueDays > threeMonthsInDays) {
                                            inputData = new Data.Builder()
                                                    .putString("notification_type", "disconnection_notice")
                                                    .putLong("overdue_days", overdueDays)
                                                    .build();
                                            workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                                    .setInputData(inputData)
                                                    .build();
                                            WorkManager.getInstance(MainActivity.this).enqueue(workRequest);
                                        } else if (overdueDays > 0) {
                                            inputData = new Data.Builder()
                                                    .putString("notification_type", "violation_overdue")
                                                    .putLong("overdue_days", overdueDays)
                                                    .build();
                                            workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                                    .setInputData(inputData)
                                                    .build();
                                            WorkManager.getInstance(MainActivity.this).enqueue(workRequest);
                                        }

                                        if (daysRemaining == 0) {
                                            inputData = new Data.Builder()
                                                    .putString("notification_type", "unpaid_bills_due_today")
                                                    .build();
                                            workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                                    .setInputData(inputData)
                                                    .build();
                                            WorkManager.getInstance(MainActivity.this).enqueue(workRequest);
                                        } else if (daysRemaining > 0) {
                                            inputData = new Data.Builder()
                                                    .putString("notification_type", "unpaid_bills_approaching")
                                                    .putLong("days_remaining", daysRemaining)
                                                    .build();
                                            workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                                                    .setInputData(inputData)
                                                    .build();
                                            WorkManager.getInstance(MainActivity.this).enqueue(workRequest);
                                        }
                                    }
                                } catch (ParseException e) {
                                    e.printStackTrace();
                                    Log.e("MyDuedate", "Error parsing due_date", e);
                                }
                            }

                            if (login_info.equalsIgnoreCase("new")) {
                                // Start Consumers_First_Creation_Account activity if login_info is "new"
                                Intent intent = new Intent(MainActivity.this, Consumers_First_Creation_Account.class);
                                intent.putExtra("r_id", r_id);
                                intent.putExtra("firstname", firstname);
                                intent.putExtra("lastname", lastname);
                                intent.putExtra("suffix", suffix);
                                intent.putExtra("contact", contact);
                                intent.putExtra("email", email);
                                intent.putExtra("username", username);
                                intent.putExtra("barangay", barangay);
                                intent.putExtra("meter_number", meter_number);
                                intent.putExtra("type_of_connection", type_of_connection);
                                startActivity(intent);
                                finish(); // Finish MainActivity if you want to close it
                            } else if (login_info.equalsIgnoreCase("old")) {
                                // Start Success activity if login_info is "old"
                                Intent homeIntent = new Intent(MainActivity.this, ConsumerHome.class);
                                startActivity(homeIntent);
                                Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                                // Use the lists for further processing or saving
                                String violations = TextUtils.join(", ", violationsList);
                                String dueDates = TextUtils.join(", ", dueDatesList);
                                String statusValues = TextUtils.join(", ", statusList);
                                String reportValues = TextUtils.join(", ", reportStatusList);

                                saveUserDatas(username, firstname, lastname, suffix, contact, r_id, barangay, email ,meter_number, type_of_connection, Collections.singletonList(statusValues), Collections.singletonList(violations), Collections.singletonList(dueDates), Collections.singletonList(reportValues));

                                finish(); // Finish MainActivity if you want to close it
                            }

                            String violations = TextUtils.join(", ", violationsList);
                            String dueDates = TextUtils.join(", ", dueDatesList);
                            String statusValues = TextUtils.join(", ", statusList);
                            String reportValues = TextUtils.join(", ", reportStatusList);
                        }


                    } else if ("failure".equalsIgnoreCase(status)) {
                        Toast.makeText(MainActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
                    } else if ("archived".equalsIgnoreCase(status)) {
                        Toast.makeText(MainActivity.this, "Account has been disabled! Please contact the Admin", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                    Toast.makeText(MainActivity.this, "Login Failed! Please try again later", Toast.LENGTH_SHORT).show();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                String message = ""; // Initialize message as blank

                // Log the error and determine the message based on the error type
                if (error instanceof TimeoutError) {
                    message = "Request timed out";
                    Log.e("VolleyError", "TimeoutError: " + error.getMessage());
                } else if (error instanceof NoConnectionError) {
                    message = "No Internet connection";
                    Log.e("VolleyError", "NoConnectionError: " + error.getMessage());
                } else if (error instanceof ServerError) {
                    message = "Server error";
                    Log.e("VolleyError", "ServerError: " + error.getMessage());
                } else if (error instanceof NetworkError) {
                    message = "Network error";
                    Log.e("VolleyError", "NetworkError: " + error.getMessage());
                } else {
                    message = "Login failed. Please try again.";
                    Log.e("VolleyError", "UnknownError: " + error.getMessage());
                }

                Toast.makeText(MainActivity.this, message, Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> data = new HashMap<>();
                data.put("username", username);
                data.put("password", password);
                return data;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    // Method to save user data in SharedPreferences for readers
    private void saveUserData(String username, String firstname, String lastname, String suffix, String contact, String email ,int readers_id) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", username);
        editor.putString("firstname", firstname);
        editor.putString("lastname", lastname);
        editor.putString("suffix", suffix);
        editor.putString("contact", contact);
        editor.putString("email", email);
        editor.putInt("readers_id", readers_id);
        editor.putString("role", "readers");
        editor.putBoolean("isLoggedIn", true);
        editor.apply();
    }

    private void saveUserDatas(String username, String firstname, String lastname, String suffix, String contact,
                               int r_id, String barangay, String email, String meter_number, String type_of_connection,
                               List<String> statusList, List<String> violationsList, List<String> dueDatesList, List<String> reportStatusList) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", username);
        editor.putString("firstname", firstname);
        editor.putString("lastname", lastname);
        editor.putString("suffix", suffix);
        editor.putString("contact", contact);
        editor.putInt("r_id", r_id);
        editor.putString("barangay", barangay);
        editor.putString("email", email);
        editor.putString("meter_number", meter_number);
        editor.putString("type_of_connection", type_of_connection);

        // Convert lists to comma-separated strings
        String statusValues = TextUtils.join(", ", statusList);
        String violations = TextUtils.join(", ", violationsList);
        String dueDates = TextUtils.join(", ", dueDatesList);
        String Reports = TextUtils.join(", ", reportStatusList);

        editor.putString("statusValues", statusValues);
        editor.putString("violations", violations);
        editor.putString("dueDates", dueDates);
        editor.putString("ReportsValues", Reports);

        editor.putString("role", "consumers");
        editor.putBoolean("isLoggedIn", true);

        // Save the current timestamp
        long currentTime = System.currentTimeMillis();
        editor.putLong("timestamp", currentTime);

        editor.apply();
    }

    private void scheduleClearDataWorker() {
        // Schedule the worker to run periodically (e.g., every 1 day)
        PeriodicWorkRequest clearDataWorkRequest = new PeriodicWorkRequest.Builder(ClearDataWorker.class, 1, TimeUnit.DAYS)
                .build();

        WorkManager.getInstance(this).enqueue(clearDataWorkRequest);
    }
    public void scheduleCacheAndDataClearing() {
        // Create a PeriodicWorkRequest with a 1-day interval
        PeriodicWorkRequest cacheClearRequest =
                new PeriodicWorkRequest.Builder(CacheClearWorker.class, 1, TimeUnit.DAYS)
                        .build();

        // Enqueue the periodic work request
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
                "CacheAndDataClearWork",
                ExistingPeriodicWorkPolicy.REPLACE,
                cacheClearRequest
        );
    }
    // Method to trigger notification with specific data
    private void triggerNotificationForReportStatus(String notificationType) {
        Data inputData = new Data.Builder()
                .putString("notification_type", notificationType)
                .build();

        OneTimeWorkRequest workRequest = new OneTimeWorkRequest.Builder(NotificationWorker.class)
                .setInputData(inputData)
                .build();

        WorkManager.getInstance(MainActivity.this).enqueue(workRequest);
    }

    private void togglePasswordVisibility() {
        if (passwordVisible) {
            // Hide the password
            ePassword.setTransformationMethod(new PasswordTransformationMethod());
            showPasswordImageView.setImageResource(R.drawable.showpassclose); // Update to the icon showing password is hidden
            passwordVisible = false;
        } else {
            // Show the password
            ePassword.setTransformationMethod(null);
            showPasswordImageView.setImageResource(R.drawable.showpass); // Update to the icon showing password is visible
            passwordVisible = true;
        }
    }

    public void update(View view) {
        // Navigate to the update activity or perform desired actions
        Intent intent = new Intent(MainActivity.this, Update.class);
        startActivity(intent);
        finish();
    }

}
