package com.example.waterworksapp;

public class SanDiego {
    private String r_id, firstName, lastName,suffix, email ,type_of_connection,meter_number,barangay,contact;

    public SanDiego(String r_id,String firstName, String lastName,String suffix, String email,
                    String type_of_connection,String meter_number,String barangay,String contact) {
        this.r_id = r_id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.suffix = suffix;
        this.email = email;
        this.type_of_connection = type_of_connection;
        this.meter_number = meter_number;
        this.barangay = barangay;
        this.contact = contact;
    }

    public String getFirstName() {
        return firstName;
    }


    public String getLastName() {
        return lastName;
    }

    public String getEmail() {
        return email;
    }

    public String getSuffix() {
        return suffix;
    }

    public String type_of_connection() {
        return type_of_connection;
    }

    public String meter_number() {
        return meter_number;
    }

    public String r_id() {
        return r_id;
    }


    public String barangay(){
        return barangay;
    }
    public String get_Contact(){
        return contact;
    }
}