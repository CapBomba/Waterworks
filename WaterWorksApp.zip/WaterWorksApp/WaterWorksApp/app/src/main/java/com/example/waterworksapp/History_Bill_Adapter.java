package com.example.waterworksapp;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class History_Bill_Adapter extends RecyclerView.Adapter<History_Bill_Adapter.UsersHolder> {

    private Context context; // Updated: Added context variable
    private List<History_Bill_Call> usersList;
    // Inside History_Bill_Adapter class
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private SimpleDateFormat displayDateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()); // Adjust format as needed

    public History_Bill_Adapter(Context context, List<History_Bill_Call> usersList) {
        this.context = context;
        this.usersList = usersList;

        // Sort bills
        sortBills();
    }

    private void sortBills() {
        Collections.sort(this.usersList, new Comparator<History_Bill_Call>() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd"); // Adjust format as needed
            Date currentDate = new Date(); // Current date

            @Override
            public int compare(History_Bill_Call o1, History_Bill_Call o2) {
                try {
                    Date date1 = sdf.parse(o1.getDueDate());
                    Date date2 = sdf.parse(o2.getDueDate());

                    boolean isO1Unpaid = "unpaid".equalsIgnoreCase(o1.getStatus());
                    boolean isO2Unpaid = "unpaid".equalsIgnoreCase(o2.getStatus());

                    // If o1 is unpaid and o2 is not, o1 should come first
                    if (isO1Unpaid && !isO2Unpaid) return -1;
                    // If o2 is unpaid and o1 is not, o2 should come first
                    if (!isO1Unpaid && isO2Unpaid) return 1;

                    // If both are unpaid or both are not unpaid, sort by closest date to current date
                    if (isO1Unpaid && isO2Unpaid) {
                        // Sort unpaid bills by due date
                        return date1.compareTo(date2);
                    } else {
                        // For non-unpaid bills, sort by proximity to current date
                        long diff1 = Math.abs(date1.getTime() - currentDate.getTime());
                        long diff2 = Math.abs(date2.getTime() - currentDate.getTime());
                        return Long.compare(diff1, diff2);
                    }

                } catch (ParseException e) {
                    e.printStackTrace();
                    return 0;
                }
            }
        });
    }

    @NonNull
    @Override
    public UsersHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View UserLayout = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_bill, parent, false);
        return new UsersHolder(UserLayout);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersHolder holder, int position) {
        History_Bill_Call user = usersList.get(position);

        String m3 = user.getM3();
        String price = user.getPrice();
        String status = user.getStatus();
        String date = user.getDate();
        String due_date = user.getDueDate();

        String bold = "<b>";
        String endBold = "</b>";
        String indent = "<br>"; // HTML entity for space repeated for indentation

        try {
            Date billDate = dateFormat.parse(date);
            Date dueDate = dateFormat.parse(due_date);

            // Apply HTML formatting for other details
            holder.cubicTextView.setText(Html.fromHtml(bold + "Consumption" + endBold + indent + m3 + " m³"));
            holder.priceTextView.setText(Html.fromHtml(bold + "Price" + endBold + indent + price + ".00 Php"));
            holder.dateTextView.setText(Html.fromHtml(bold + "Reading Date" + endBold + indent + displayDateFormat.format(billDate)));
            holder.due_date_txt.setText(Html.fromHtml(bold + "Due Date" + endBold + indent + displayDateFormat.format(dueDate)));

            // Capitalize and style the status
            String statusText = "Status";
            String statusValue = status.toLowerCase(); // Convert to lowercase for manipulation
            statusValue = statusValue.substring(0, 1).toUpperCase() + statusValue.substring(1); // Capitalize first letter

            SpannableStringBuilder spannableStatus = new SpannableStringBuilder();

            // Add "Status:" with bold style
            SpannableString boldStatusText = new SpannableString(statusText);
            boldStatusText.setSpan(new StyleSpan(Typeface.BOLD), 0, boldStatusText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            spannableStatus.append(boldStatusText);

            // Add a line break after "Status:"
            spannableStatus.append("\n");

            // Apply italic style and color to the status value
            SpannableString statusSpan = new SpannableString(statusValue);
            statusSpan.setSpan(new StyleSpan(Typeface.ITALIC), 0, statusValue.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            if ("Unpaid".equals(statusValue)) {
                statusSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#c30010")), 0, statusValue.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else if ("Paid".equals(statusValue)) {
                statusSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#0B6623")), 0, statusValue.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }

            spannableStatus.append(statusSpan);
            holder.status_txt.setText(spannableStatus);

        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return usersList.size();
    }

    public class UsersHolder extends RecyclerView.ViewHolder {
        TextView cubicTextView, priceTextView, dateTextView, due_date_txt, status_txt;
        ConstraintLayout layout;

        public UsersHolder(@NonNull View itemView) {
            super(itemView);
            cubicTextView = itemView.findViewById(R.id.cubic_txt);
            priceTextView = itemView.findViewById(R.id.price_txt);
            dateTextView = itemView.findViewById(R.id.date_txt);
            due_date_txt = itemView.findViewById(R.id.due_date_txt);
            status_txt = itemView.findViewById(R.id.status_txt);
            layout = itemView.findViewById(R.id.item_bill_card);
        }
    }
}
