package com.example.waterworksapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Success extends AppCompatActivity {
    DrawerLayout drawerLayout;
    ImageButton buttonDrawerToggle;
    ImageView no_announcement_logo, announcement_logo;
    NavigationView navigationView;
    private String URL = "https://luisianawaterworks.com/WaterWorks/Capstone/android/announcements.php";
    private RecyclerView recyclerView;

    private Announcements_Adapter announcementsAdapter;
    private List<Announcements_Call> announcementsList = new ArrayList<>();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        String successMessage = getIntent().getStringExtra("success_message");

        if (successMessage != null) {
            Toast.makeText(this, successMessage, Toast.LENGTH_SHORT).show();
        }

        drawerLayout = findViewById(R.id.drawerLayout);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView);
        recyclerView = findViewById(R.id.recyclerView);
        no_announcement_logo = findViewById(R.id.no_announcement_logo);
        announcement_logo= findViewById(R.id.announcement_logo);
        // Initialize RecyclerView and set layout manager
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Initialize announcementsAdapter with correct context
        announcementsAdapter = new Announcements_Adapter(this, announcementsList);
        recyclerView.setAdapter(announcementsAdapter);

        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.open();
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.navHome) {
                    // Handle navigation item click for Home
                    startActivity(new Intent(Success.this, Success.class));
                } else if (itemId == R.id.navProfile) {
                    // Handle navigation item click for Profile
                    startActivity(new Intent(Success.this, Profile.class));
                } else if (itemId == R.id.navReading) {
                    // Handle navigation item click for Reading
                    startActivity(new Intent(Success.this, Reading.class));
                } else if (itemId == R.id.navLogout) {
                    logout();
                }
                drawerLayout.close();
                return true;
            }
        });
        fetchDataFromServer();

        SwipeRefreshLayout swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Add the logic to refresh your RecyclerView data here

                // Simulate a network call or data update (use your actual data refresh logic)
                refreshRecyclerViewData();

                // Once the refresh is complete, stop the refreshing animation
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }

    private void fetchDataFromServer() {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Check if the JSON array is empty
                        if (response.length() == 0) {
                            // No records found
                            Toast.makeText(Success.this, "No announcements found", Toast.LENGTH_SHORT).show();
                            no_announcement_logo.setVisibility(View.VISIBLE);
                            announcement_logo.setVisibility(View.GONE);
                            recyclerView.setVisibility(View.GONE);
                        } else {
                            // Parse JSON response
                            parseJsonResponse(response);
                            // Show success message if necessary
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = ""; // Initialize message as blank

                        // Handle specific VolleyError instances
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "Announcement failed to load. Please try again."; // Fallback for any other error types
                        }

                        // Display Toast message based on the error response
                        Toast.makeText(Success.this, message, Toast.LENGTH_SHORT).show();
                        no_announcement_logo.setVisibility(View.VISIBLE);
                        announcement_logo.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.GONE);
                    }
                });

        // Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }

    private void parseJsonResponse(JSONArray jsonArray) {
        try {
            // Clear existing data in the list
            announcementsList.clear();

            // Iterate through the JSON array and add data to the list
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String announcement_id = jsonObject.optString("announcement_id");
                String title = jsonObject.optString("title");
                String content = jsonObject.optString("content");
                String created_at = jsonObject.optString("created_at");

                Announcements_Call announcementsCall = new Announcements_Call(announcement_id, title, content, created_at);
                announcementsList.add(announcementsCall);
            }

            // Notify the adapter about the data change
            announcementsAdapter.notifyDataSetChanged();

            // Show toast indicating successful loading of data
            Toast.makeText(Success.this, "Announcements loaded successfully", Toast.LENGTH_SHORT).show();
            recyclerView.setVisibility(View.VISIBLE);
            announcement_logo.setVisibility(View.VISIBLE);
            no_announcement_logo.setVisibility(View.GONE);
            Toast.makeText(Success.this, "Tap the title to see the details", Toast.LENGTH_LONG).show();

        } catch (JSONException e) {
            e.printStackTrace();
            // Error handling for JSON parsing
            Toast.makeText(Success.this, "An error has occurred. Please try again", Toast.LENGTH_SHORT).show();
            recyclerView.setVisibility(View.GONE);
            announcement_logo.setVisibility(View.GONE);
        }
    }

    private void logout() {
        // Create a confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Call PHP script for logout
                callLogoutPhp();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Do nothing, simply dismiss the dialog
                dialogInterface.dismiss();
            }
        });
        // Display the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void callLogoutPhp() { String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/offline_android.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle response from PHP script
                        if (response.trim().equals("success")) {
                            // Handle success (user logged out successfully)
                            // Clear user session data from SharedPreferences
                            clearSessionData();
                            Toast.makeText(Success.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

                            // Redirect to MainActivity
                            Intent intent = new Intent(Success.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear the back stack
                            startActivity(intent);
                            finish(); // Finish the current activity to prevent returning to it by pressing the back button
                        } else if (response.trim().equals("failure")) {
                            // Handle failure (logout failed)
                            Toast.makeText(Success.this, "Logout failed. Please try again.", Toast.LENGTH_SHORT).show();
                        } else {
                            // Handle other cases (invalid request or unexpected response)
                            Toast.makeText(Success.this, "Unexpected error occurred. Please try again", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                String message = ""; // Initialize message as blank

                // Handle specific VolleyError instances
                if (error instanceof TimeoutError) {
                    message = "Request timed out";
                } else if (error instanceof NoConnectionError) {
                    message = "No internet connection";
                } else if (error instanceof ServerError) {
                    message = "Server error";
                } else if (error instanceof NetworkError) {
                    message = "Network error";
                } else {
                    message = "Logout failed. Please try again."; // Fallback for any other error types
                }

                // Display Toast message based on the error response
                Toast.makeText(Success.this, message, Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Pass user ID instead of username and password
                Map<String, String> data = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
                int userId = sharedPreferences.getInt("readers_id", -1); // -1 or any default value if not found
                data.put("user_id", String.valueOf(userId));
                return data;
            }
        };

// Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void clearSessionData() {
        // Clear user session data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }
    private void refreshRecyclerViewData() {
        fetchDataFromServer();
    }
}
