package com.example.waterworksapp;

import android.content.Context;
import android.content.SharedPreferences;
import androidx.annotation.NonNull;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class ClearDataWorker extends Worker {

    public ClearDataWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        clearDataIfTimePassed();
        return Result.success();
    }

    private void clearDataIfTimePassed() {
        SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences("user_sessions", Context.MODE_PRIVATE);
        long savedTimestamp = sharedPreferences.getLong("timestamp", -1);
        long currentTime = System.currentTimeMillis();

        // Check if more than 1 day has passed
        if (savedTimestamp != -1 && (currentTime - savedTimestamp) > 24 * 60 * 60 * 1000) { // 1 day in milliseconds
            // Clear SharedPreferences
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.clear();
            editor.apply();
        }
    }
}
