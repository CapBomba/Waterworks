package com.example.waterworksapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.method.PasswordTransformationMethod;
import android.text.style.UnderlineSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class Consumers_First_Creation_Account extends AppCompatActivity {
    private EditText eConfirmPassword, ePassword;
    private Button update_pass;
    private String URL = "https://luisianawaterworks.com/WaterWorks/Capstone/android/new_account_consumers_update.php";
    private boolean passwordVisible = false;
    private ImageView showPasswordImageView;
    private String username, firstname, lastname, suffix, contact, email, meter_number, barangay,type_of_connection;
    private int r_id;
    private boolean hasError = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumers_first_creation_account);

        ePassword = findViewById(R.id.ePassword);
        eConfirmPassword = findViewById(R.id.eConfirmPassword);
        update_pass = findViewById(R.id.update_pass);
        showPasswordImageView = findViewById(R.id.imageViewShowPassword);

        // Retrieve data from Intent
        Intent intent = getIntent();
        if (intent != null) {
            username = intent.getStringExtra("username");
            firstname = intent.getStringExtra("firstname");
            lastname = intent.getStringExtra("lastname");
            suffix = intent.getStringExtra("suffix");
            contact = intent.getStringExtra("contact");
            email = intent.getStringExtra("email");
            meter_number = intent.getStringExtra("meter_number");
            barangay = intent.getStringExtra("barangay");
            type_of_connection = intent.getStringExtra("type_of_connection");
            r_id = intent.getIntExtra("r_id", -1);
        }

        // Set up listeners and other logic
        showPasswordImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePasswordVisibility();
            }
        });

        update_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                update_password(); // Now the username and other fields are accessible
            }
        });
    }

    private void togglePasswordVisibility() {
        if (passwordVisible) {
            ePassword.setTransformationMethod(new PasswordTransformationMethod());
            eConfirmPassword.setTransformationMethod(new PasswordTransformationMethod());
            showPasswordImageView.setImageResource(R.drawable.showpassclose);

            // Reset cursor position
            ePassword.setSelection(ePassword.getText().length());
            eConfirmPassword.setSelection(eConfirmPassword.getText().length());

            passwordVisible = false;
        } else {
            ePassword.setTransformationMethod(null);
            eConfirmPassword.setTransformationMethod(null);
            showPasswordImageView.setImageResource(R.drawable.showpass);

            // Reset cursor position
            ePassword.setSelection(ePassword.getText().length());
            eConfirmPassword.setSelection(eConfirmPassword.getText().length());

            passwordVisible = true;
        }

        // Force re-draw
        ePassword.postInvalidate();
        eConfirmPassword.postInvalidate();
    }

    public void update_password() {
        hasError = false;
        String confirmpassword = eConfirmPassword.getText().toString().trim();
        String password = ePassword.getText().toString().trim();

        // Password validation logic
        if (password.isEmpty()) {
            Toast.makeText(Consumers_First_Creation_Account.this, "Password cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }
        if (confirmpassword.isEmpty()) {
            Toast.makeText(Consumers_First_Creation_Account.this, "Confirm password cannot be empty", Toast.LENGTH_SHORT).show();
            return;
        }
        if (password.length() < 8) {
            Toast.makeText(Consumers_First_Creation_Account.this, "Password must be at least 8 characters long", Toast.LENGTH_SHORT).show();
            hasError = true;
        }
        if (!password.equals(confirmpassword)) {
            Toast.makeText(Consumers_First_Creation_Account.this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            hasError = true;
        }
        // Check if password contains special characters
        Pattern specialCharPattern = Pattern.compile("[^a-zA-Z0-9]");
        Matcher matcher = specialCharPattern.matcher(password);
        if (matcher.find()) {
            Toast.makeText(Consumers_First_Creation_Account.this, "Password cannot contain special characters", Toast.LENGTH_SHORT).show();
            hasError = true; // Set error flag
        }
        if (hasError) {
            return;
        }

        // Volley request to update the password
        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.optString("status");

                            if ("success".equalsIgnoreCase(status)) {
                                Toast.makeText(Consumers_First_Creation_Account.this, "Password updated successfully", Toast.LENGTH_SHORT).show();
                                saveUserDatas(username, firstname, lastname, suffix, contact, r_id, barangay, email ,meter_number, type_of_connection);

                                Intent intent = new Intent(Consumers_First_Creation_Account.this, ConsumerHome.class);
                                startActivity(intent);
                                finish();
                            } else {
                                Toast.makeText(Consumers_First_Creation_Account.this, "Failed to update password", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Failed to update password. Please try again later", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = "Password update failed. Please try again.";
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        }
                        Toast.makeText(Consumers_First_Creation_Account.this, message, Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("password", password);
                params.put("username", username); // Use the class-level username variable
                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void saveUserDatas(String username, String firstname, String lastname, String suffix, String contact,
                               int r_id, String barangay, String email, String meter_number, String type_of_connection) {
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("username", username);
        editor.putString("firstname", firstname);
        editor.putString("lastname", lastname);
        editor.putString("suffix", suffix);
        editor.putString("contact", contact);
        editor.putInt("r_id", r_id);
        editor.putString("barangay", barangay);
        editor.putString("email", email);
        editor.putString("meter_number", meter_number);
        editor.putString("type_of_connection", type_of_connection);

        editor.putString("role", "consumers");
        editor.putBoolean("isLoggedIn", true);

        // Save the current timestamp
        long currentTime = System.currentTimeMillis();
        editor.putLong("timestamp", currentTime);

        editor.apply();
    }

}
