package com.example.waterworksapp;

import android.graphics.Bitmap;

public class Report_Problem_Class{
    private String report_id, description, gmail, status,report_time,status_desc,meter_num, dateOfVisit;
    private Bitmap picture;

    public Report_Problem_Class(String report_id, String description, String gmail, String status, String report_time, String status_desc, String meter_num, String dateOfVisit, Bitmap picture) {
        this.report_id = report_id;
        this.description = description;
        this.gmail = gmail;
        this.status = status;
        this.report_time = report_time;
        this.status_desc = status_desc;
        this.meter_num = meter_num;
        this.dateOfVisit = dateOfVisit;
        this.picture = picture;

    }


    public String getDescription() {
        return description;
    }

    public String getGmail() {
        return gmail;
    }

    public String getReport_time() {
        return report_time;
    }

    public String getStatus_desc() {
        return status_desc;
    }

    public String getMeter_num() {
        return meter_num;
    }

    public String getDateOfVisit() {
        return dateOfVisit;
    }


    public String getStatus() {
        return status;
    }

    public String getReport_id() {
        return report_id;
    }

    public Bitmap getPicture() {
        return picture;
    }


}