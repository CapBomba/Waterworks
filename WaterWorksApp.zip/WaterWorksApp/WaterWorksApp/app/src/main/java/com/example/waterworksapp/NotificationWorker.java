package com.example.waterworksapp;

import static android.content.Context.MODE_PRIVATE;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class NotificationWorker extends Worker {

    private static final String CHANNEL_ID_DUE_DATE = "CHANNEL_ID_DUE_DATE";
    private static final String CHANNEL_ID_VIOLATION = "CHANNEL_ID_VIOLATION";
    private static final String CHANNEL_ID_UNPAID_BILLS = "CHANNEL_ID_UNPAID_BILLS";
    private static final String CHANNEL_ID_REPORT_STATUS = "CHANNEL_ID_REPORT_STATUS";

    public NotificationWorker(@NonNull Context context, @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {
        // Retrieve the notification type from input data
        String notificationType = getInputData().getString("notification_type");
        Log.d("NotificationWorker", "Notification type: " + notificationType);

        if ("disconnection_notice".equals(notificationType)) {
            long overdueDays = getInputData().getLong("overdue_days", -1);
            makeViolationNotification(overdueDays,getApplicationContext());
        }
        if ("violation_overdue".equals(notificationType)) {
            long overdueDays = getInputData().getLong("overdue_days", -1);
            makeViolationOverdueNotification(overdueDays,getApplicationContext());
        }
        if ("unpaid_bills_approaching".equals(notificationType)) {
            long daysRemaining = getInputData().getLong("days_remaining", -1);
            makeUnpaidBillsApproachingNotification(daysRemaining,getApplicationContext());
        }
        if ("unpaid_bills_due_today".equals(notificationType)) {
            makeUnpaidBillsDueTodayNotification(getApplicationContext());
        }
        if ("unpaid_bills_overdue".equals(notificationType)) {
            long daysOverdue = getInputData().getLong("days_overdue", -1);
            makeUnpaidBillsOverdueNotification(daysOverdue,getApplicationContext());
        }
        if ("declined_report_notification".equals(notificationType)) {
            makeDeclinedReportNotification(getApplicationContext());
        }
        if ("accepted_report_notification".equals(notificationType)) {
            makeAcceptedReportNotification(getApplicationContext());
        }
        if ("taking_action_report_notification".equals(notificationType)) {
            makeTakingActionReportNotification(getApplicationContext());
        }
        return Result.success();
    }

    private void makeUnpaidBillsApproachingNotification(long daysRemaining,Context context) {
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);

        Intent intent = new Intent(this.getApplicationContext(), ConsumerHome.class); // Replace with your target activity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        String contentTitle = "Unpaid Bills Reminder";
        // Prepare the notification content based on remaining days
        String contentText = daysRemaining > 0 ?
                "You have " + daysRemaining + " days left before your unpaid bills are due." :
                "Your unpaid bills are due today! Please proceed to the office to settle it immediately.";


        // Wrap the Intent in a PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this.getApplicationContext(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // Adjust flags based on API levels
        );

        // Create NotificationChannel if the OS version is Oreo or higher
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID_UNPAID_BILLS,
                    "Unpaid Bills Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Unpaid Bills Notification Channel");
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            channel.enableVibration(true);
            notificationManager.createNotificationChannel(channel);
        }

        // Retrieve meter_number from SharedPreferences using the passed context
        SharedPreferences sharedPreferences = context.getSharedPreferences("user_sessions", Context.MODE_PRIVATE);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // If meter_number is available, send the request and pass contentTitle and contentText
        if (meter_number != null && !meter_number.isEmpty()) {
            sendMeterNumberRequestUnpaidApproaching(meter_number, contentTitle, contentText); // Pass title and text as parameters
        }
        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_REPORT_STATUS)
                .setSmallIcon(R.drawable.mainlogo)
                .setContentTitle(contentTitle) // Use the saved title
                .setContentText(contentText)  // Use the saved text
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent); // Set the pending intent to handle notification clicks

        notificationManager.notify(1, builder.build());
    }
    private void sendMeterNumberRequestUnpaidApproaching(String meterNumber, String contentTitle, String contentText) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/notif_unpaid_approaching.php"; // Your actual API URL
        // Create the request payload with the parameters to be sent
        Map<String, String> params = new HashMap<>();
        params.put("meter_number", meterNumber);
        params.put("content_title", contentTitle);  // Include the content title
        params.put("content_text", contentText);   // Include the content text

        // Create a new Volley request (StringRequest)
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Log.d("Volley Response Overdue", response);

                        // You may want to parse the response to check for success
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            if ("success".equals(status)) {
                                Log.d("Notification", "Notification successfully saved!");
                            } else {
                                Log.e("Notification", "Error: " + jsonResponse.getString("message"));
                            }
                        } catch (JSONException e) {
                            Log.e("Volley Response", "Error parsing response: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle errors
                        Log.e("Volley Error", error.toString());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params; // Pass the request parameters
            }
        };

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void makeUnpaidBillsDueTodayNotification(Context context) {
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);

        Intent intent = new Intent(this.getApplicationContext(), ConsumerHome.class); // Replace with your target activity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        String contentTitle = "Unpaid Bills Due Today";
        String contentText = "Your unpaid bills are due today! Please proceed to the office to settle it immediately.";


        // Wrap the Intent in a PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this.getApplicationContext(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // Adjust flags based on API levels
        );

        // Create NotificationChannel if the OS version is Oreo or higher
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID_UNPAID_BILLS,
                    "Unpaid Bills Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Unpaid Bills Notification Channel");
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            channel.enableVibration(true);
            notificationManager.createNotificationChannel(channel);
        }

        // Retrieve meter_number from SharedPreferences using the passed context
        SharedPreferences sharedPreferences = context.getSharedPreferences("user_sessions", Context.MODE_PRIVATE);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // If meter_number is available, send the request and pass contentTitle and contentText
        if (meter_number != null && !meter_number.isEmpty()) {
            sendMeterNumberRequestUnpaidToday(meter_number, contentTitle, contentText); // Pass title and text as parameters
        }
        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_REPORT_STATUS)
                .setSmallIcon(R.drawable.mainlogo)
                .setContentTitle(contentTitle) // Use the saved title
                .setContentText(contentText)  // Use the saved text
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent); // Set the pending intent to handle notification clicks

        notificationManager.notify(2, builder.build());
    }
    private void sendMeterNumberRequestUnpaidToday(String meterNumber, String contentTitle, String contentText) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/notif_unpaid_today.php"; // Your actual API URL
        // Create the request payload with the parameters to be sent
        Map<String, String> params = new HashMap<>();
        params.put("meter_number", meterNumber);
        params.put("content_title", contentTitle);  // Include the content title
        params.put("content_text", contentText);   // Include the content text

        // Create a new Volley request (StringRequest)
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Log.d("Volley Response Overdue", response);

                        // You may want to parse the response to check for success
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            if ("success".equals(status)) {
                                Log.d("Notification", "Notification successfully saved!");
                            } else {
                                Log.e("Notification", "Error: " + jsonResponse.getString("message"));
                            }
                        } catch (JSONException e) {
                            Log.e("Volley Response", "Error parsing response: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle errors
                        Log.e("Volley Error", error.toString());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params; // Pass the request parameters
            }
        };

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void makeViolationNotification(long overdueDays, Context context) {
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);

        Intent intent = new Intent(this.getApplicationContext(), Consumer_Violation.class); // Replace with your target activity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        String contentTitle = "Disconnection Notice";
        String contentText = "Your bill is overdue by " + overdueDays + " days. Please pay now to avoid disconnection.";

        // Wrap the Intent in a PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this.getApplicationContext(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // Adjust flags based on API levels
        );

        // Create notification channel for Android O and above
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID_VIOLATION, "Violation Notifications", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Violation Notification Channel");
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            channel.enableVibration(true);
            notificationManager.createNotificationChannel(channel);
        }

        // Retrieve meter_number from SharedPreferences using the passed context
        SharedPreferences sharedPreferences = context.getSharedPreferences("user_sessions", Context.MODE_PRIVATE);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // If meter_number is available, send the request and pass contentTitle and contentText
        if (meter_number != null && !meter_number.isEmpty()) {
            sendMeterNumberRequestDisconnection(meter_number, contentTitle, contentText); // Pass title and text as parameters
        }
        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_REPORT_STATUS)
                .setSmallIcon(R.drawable.mainlogo)
                .setContentTitle(contentTitle) // Use the saved title
                .setContentText(contentText)  // Use the saved text
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent); // Set the pending intent to handle notification clicks

        notificationManager.notify(2, builder.build());
    }

    private void sendMeterNumberRequestDisconnection(String meterNumber, String contentTitle, String contentText) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/notif_disconnection.php"; // Your actual API URL
        // Create the request payload with the parameters to be sent
        Map<String, String> params = new HashMap<>();
        params.put("meter_number", meterNumber);
        params.put("content_title", contentTitle);  // Include the content title
        params.put("content_text", contentText);   // Include the content text

        // Create a new Volley request (StringRequest)
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Log.d("Volley Response Overdue", response);

                        // You may want to parse the response to check for success
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            if ("success".equals(status)) {
                                Log.d("Notification", "Notification successfully saved!");
                            } else {
                                Log.e("Notification", "Error: " + jsonResponse.getString("message"));
                            }
                        } catch (JSONException e) {
                            Log.e("Volley Response", "Error parsing response: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle errors
                        Log.e("Volley Error", error.toString());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params; // Pass the request parameters
            }
        };

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }


    private void makeViolationOverdueNotification(long overdueDays, Context context) {
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
        // Save notification content into variables
        String contentTitle = "Unpaid Bills Overdue";
        String contentText = "Your unpaid bills are overdue by " + overdueDays + " days. Please settle it immediately.";

        Intent intent = new Intent(this.getApplicationContext(), Consumer_Violation.class); // Replace with your target activity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        // Wrap the Intent in a PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this.getApplicationContext(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // Adjust flags based on API levels
        );

        // Create notification channel for Android O and above
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID_VIOLATION, "Violation Notifications", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Violation Notification Channel");
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            channel.enableVibration(true);
            notificationManager.createNotificationChannel(channel);
        }
        // Retrieve meter_number from SharedPreferences using the passed context
        SharedPreferences sharedPreferences = context.getSharedPreferences("user_sessions", Context.MODE_PRIVATE);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // If meter_number is available, send the request and pass contentTitle and contentText
        if (meter_number != null && !meter_number.isEmpty()) {
            sendMeterNumberRequestOverDue(meter_number, contentTitle, contentText); // Pass title and text as parameters
        }
        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_REPORT_STATUS)
                .setSmallIcon(R.drawable.mainlogo)
                .setContentTitle(contentTitle) // Use the saved title
                .setContentText(contentText)  // Use the saved text
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent); // Set the pending intent to handle notification clicks

        notificationManager.notify(3, builder.build());
    }

    private void makeUnpaidBillsOverdueNotification(long daysOverdue,Context context) {
        NotificationManager notificationManager = (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);

        // Save notification content into variables
        String contentTitle = "Unpaid Bills Overdue";
        String contentText = "Your unpaid bills are overdue by " + daysOverdue + " days. Please settle it immediately.";

        Intent intent = new Intent(this.getApplicationContext(), Consumer_Violation.class); // Replace with your target activity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        // Wrap the Intent in a PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this.getApplicationContext(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // Adjust flags based on API levels
        );

        // Create NotificationChannel if the OS version is Oreo or higher
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID_UNPAID_BILLS,
                    "Unpaid Bills Notifications",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channel.setDescription("Unpaid Bills Notification Channel");
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            channel.enableVibration(true);
            notificationManager.createNotificationChannel(channel);
        }
        // Retrieve meter_number from SharedPreferences using the passed context
        SharedPreferences sharedPreferences = context.getSharedPreferences("user_sessions", Context.MODE_PRIVATE);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // If meter_number is available, send the request and pass contentTitle and contentText
        if (meter_number != null && !meter_number.isEmpty()) {
            sendMeterNumberRequestOverDue(meter_number, contentTitle, contentText); // Pass title and text as parameters
        }

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_REPORT_STATUS)
                .setSmallIcon(R.drawable.mainlogo)
                .setContentTitle(contentTitle) // Use the saved title
                .setContentText(contentText)  // Use the saved text
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent); // Set the pending intent to handle notification clicks

        notificationManager.notify(4, builder.build());
    }
    private void sendMeterNumberRequestOverDue(String meterNumber, String contentTitle, String contentText) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/notif_overdue.php"; // Your actual API URL
        // Create the request payload with the parameters to be sent
        Map<String, String> params = new HashMap<>();
        params.put("meter_number", meterNumber);
        params.put("content_title", contentTitle);  // Include the content title
        params.put("content_text", contentText);   // Include the content text

        // Create a new Volley request (StringRequest)
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Log.d("Volley Response Overdue", response);

                        // You may want to parse the response to check for success
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            if ("success".equals(status)) {
                                Log.d("Notification", "Notification successfully saved!");
                            } else {
                                Log.e("Notification", "Error: " + jsonResponse.getString("message"));
                            }
                        } catch (JSONException e) {
                            Log.e("Volley Response", "Error parsing response: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle errors
                        Log.e("Volley Error", error.toString());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params; // Pass the request parameters
            }
        };

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
    private void makeDeclinedReportNotification(Context context) {
        createNotificationChannel(CHANNEL_ID_REPORT_STATUS, "Report Status Notifications");

        // Save notification content into variables
        String contentTitle = "Report Declined";
        String contentText = "Your report has been declined. Please check for further details.";

        Intent intent = new Intent(this.getApplicationContext(), Report_Problem.class); // Replace with your target activity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        // Wrap the Intent in a PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this.getApplicationContext(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // Adjust flags based on API levels
        );
        // Retrieve meter_number from SharedPreferences using the passed context
        SharedPreferences sharedPreferences = context.getSharedPreferences("user_sessions", Context.MODE_PRIVATE);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // If meter_number is available, send the request and pass contentTitle and contentText
        if (meter_number != null && !meter_number.isEmpty()) {
            sendMeterNumberRequestDeclined(meter_number, contentTitle, contentText); // Pass title and text as parameters
        }

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_REPORT_STATUS)
                .setSmallIcon(R.drawable.mainlogo)
                .setContentTitle(contentTitle) // Use the saved title
                .setContentText(contentText)  // Use the saved text
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent); // Set the pending intent to handle notification clicks

        // Show the notification
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(5, builder.build());
    }
    private void sendMeterNumberRequestDeclined(String meterNumber, String contentTitle, String contentText) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/notif_declined.php"; // Your actual API URL
        // Create the request payload with the parameters to be sent
        Map<String, String> params = new HashMap<>();
        params.put("meter_number", meterNumber);
        params.put("content_title", contentTitle);  // Include the content title
        params.put("content_text", contentText);   // Include the content text

        // Create a new Volley request (StringRequest)
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Log.d("Volley Response Declined", response);

                        // You may want to parse the response to check for success
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            if ("success".equals(status)) {
                                Log.d("Notification", "Notification successfully saved!");
                            } else {
                                Log.e("Notification", "Error: " + jsonResponse.getString("message"));
                            }
                        } catch (JSONException e) {
                            Log.e("Volley Response", "Error parsing response: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle errors
                        Log.e("Volley Error", error.toString());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params; // Pass the request parameters
            }
        };

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void createNotificationChannel(String channelId, String channelName) {
        NotificationManager notificationManager = getNotificationManager();
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription(channelName);
            channel.enableLights(true);
            channel.setLightColor(Color.RED);
            channel.enableVibration(true);
            notificationManager.createNotificationChannel(channel);
        }
    }

    private NotificationManager getNotificationManager() {
        return (NotificationManager) getApplicationContext().getSystemService(Context.NOTIFICATION_SERVICE);
    }

    private void makeAcceptedReportNotification(Context context) {
        createNotificationChannel(CHANNEL_ID_REPORT_STATUS, "Report Status Notifications");

        // Save notification content into variables
        String contentTitle = "Report Accepted";
        String contentText = "Your report has been accepted. Please stand by we are working on it.";

        Intent intent = new Intent(this.getApplicationContext(), Report_Problem.class); // Replace with your target activity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        // Wrap the Intent in a PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(
                this.getApplicationContext(),
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // Adjust flags based on API levels
        );
        // Retrieve meter_number from SharedPreferences using the passed context
        SharedPreferences sharedPreferences = context.getSharedPreferences("user_sessions", Context.MODE_PRIVATE);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // If meter_number is available, send the request and pass contentTitle and contentText
        if (meter_number != null && !meter_number.isEmpty()) {
            sendMeterNumberRequestAccepted(meter_number, contentTitle, contentText); // Pass title and text as parameters
        }

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_REPORT_STATUS)
                .setSmallIcon(R.drawable.mainlogo)
                .setContentTitle(contentTitle) // Use the saved title
                .setContentText(contentText)  // Use the saved text
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent); // Set the pending intent to handle notification clicks

        // Show the notification
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(6, builder.build());
    }
    // Method to make a Volley request using meter_number and notification data
    private void sendMeterNumberRequestAccepted(String meterNumber, String contentTitle, String contentText) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/notif_accepted.php"; // Your actual API URL
        // Create the request payload with the parameters to be sent
        Map<String, String> params = new HashMap<>();
        params.put("meter_number", meterNumber);
        params.put("content_title", contentTitle);  // Include the content title
        params.put("content_text", contentText);   // Include the content text

        // Create a new Volley request (StringRequest)
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Log.d("Volley Response Accepted", response);

                        // You may want to parse the response to check for success
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            if ("success".equals(status)) {
                                Log.d("Notification", "Notification successfully saved!");
                            } else {
                                Log.e("Notification", "Error: " + jsonResponse.getString("message"));
                            }
                        } catch (JSONException e) {
                            Log.e("Volley Response", "Error parsing response: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle errors
                        Log.e("Volley Error", error.toString());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params; // Pass the request parameters
            }
        };

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
    private void makeTakingActionReportNotification(Context context) {
        // Create notification channel
        createNotificationChannel(CHANNEL_ID_REPORT_STATUS, "Report Status Notifications");

        // Save notification content into variables
        String contentTitle = "Report Action Being Taken";
        String contentText = "Action is being taken on your report. Please stand by, we are sending our team.";

        // Create an Intent to open the desired activity
        Intent intent = new Intent(context, Report_Problem.class); // Replace with your target activity
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);

        // Wrap the Intent in a PendingIntent
        PendingIntent pendingIntent = PendingIntent.getActivity(
                context,
                0,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE // Adjust flags based on API levels
        );

        // Retrieve meter_number from SharedPreferences using the passed context
        SharedPreferences sharedPreferences = context.getSharedPreferences("user_sessions", Context.MODE_PRIVATE);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // If meter_number is available, send the request and pass contentTitle and contentText
        if (meter_number != null && !meter_number.isEmpty()) {
            sendMeterNumberRequestTakingAction(meter_number, contentTitle, contentText); // Pass title and text as parameters
        }

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID_REPORT_STATUS)
                .setSmallIcon(R.drawable.mainlogo)
                .setContentTitle(contentTitle) // Use the saved title
                .setContentText(contentText)  // Use the saved text
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent); // Set the pending intent to handle notification clicks

        // Show the notification
        NotificationManager notificationManager = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.notify(7, builder.build());
    }

    // Method to make a Volley request using meter_number and notification data
    private void sendMeterNumberRequestTakingAction(String meterNumber, String contentTitle, String contentText) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/notif_taking_action.php"; // Your actual API URL

        // Create the request payload with the parameters to be sent
        Map<String, String> params = new HashMap<>();
        params.put("meter_number", meterNumber);
        params.put("content_title", contentTitle);  // Include the content title
        params.put("content_text", contentText);   // Include the content text

        // Create a new Volley request (StringRequest)
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the server
                        Log.d("Volley Response Taking Action", response);

                        // You may want to parse the response to check for success
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");
                            if ("success".equals(status)) {
                                Log.d("Notification", "Notification successfully saved!");
                            } else {
                                Log.e("Notification", "Error: " + jsonResponse.getString("message"));
                            }
                        } catch (JSONException e) {
                            Log.e("Volley Response", "Error parsing response: " + e.getMessage());
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        // Handle errors
                        Log.e("Volley Error", error.toString());
                    }
                }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                return params; // Pass the request parameters
            }
        };

        // Add the request to the Volley request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
}
