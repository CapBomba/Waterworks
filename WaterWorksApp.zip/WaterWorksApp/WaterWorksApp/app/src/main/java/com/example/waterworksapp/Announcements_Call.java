package com.example.waterworksapp;

public class Announcements_Call{
    private String announce_id, title, content, created_at;

    public Announcements_Call(String announce_id,String title, String content,String created_at) {
        this.announce_id = announce_id;
        this.title = title;
        this.content = content;
        this.created_at = created_at;

    }

    public String gettitle() {
        return title;
    }
    public String getcontent() {
        return content;
    }

    public String getcreated_at() {
        return created_at;
    }

    public String announce_id() {
        return announce_id;
    }

}