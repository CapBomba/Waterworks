package com.example.waterworksapp;

import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.TranslateAnimation;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import lecho.lib.hellocharts.gesture.ZoomType;
import lecho.lib.hellocharts.listener.ColumnChartOnValueSelectListener;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Column;
import lecho.lib.hellocharts.model.ColumnChartData;
import lecho.lib.hellocharts.model.SubcolumnValue;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.view.ColumnChartView;
import android.widget.ProgressBar;

public class
ConsumerHome extends AppCompatActivity {
    private String URL = "https://luisianawaterworks.com/WaterWorks/Capstone/android/announcements.php";
    private DrawerLayout drawerLayout;
    private RecyclerView recyclerView;
    private TextView hello_details;
    private ImageView imageView_water ,speedometerProgressBar;

    private boolean isAnimationStarted = false;
    private Announcements_Adapter announcementsAdapter;
    private List<Announcements_Call> announcementsList = new ArrayList<>();

    private ColumnChartView columnChartView;
    private TextView select_year_id, chartDetailsLabel, reading_details, due_date_details,status_details,consumption_details,price_details;
    private List<History_Bill_Call> billList = new ArrayList<>();

    private List<Notification_History_Call> notifList = new ArrayList<>();
    private Spinner yearSpinner;
    private LinearLayout view_all_bills;

    private History_Bill_Adapter History_Bill_Adapter;
    private ImageView no_announcement_logo, announcement_logo, notif_history,profile_icon;
    private ProgressBar meterProgressBar;
    private TextView averageText;
    private FrameLayout speedometerLayout;
    private LinearLayout linear_layout_dark_blue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_announcements);

        drawerLayout = findViewById(R.id.drawerLayout);
        hello_details = findViewById(R.id.hello_details);
        NavigationView navigationView = findViewById(R.id.navigationView);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        announcementsAdapter = new Announcements_Adapter(this, announcementsList);
        recyclerView.setAdapter(announcementsAdapter);

        columnChartView = findViewById(R.id.chart);  // Use ColumnChartView instead
        yearSpinner = findViewById(R.id.yearSpinner);
        reading_details = findViewById(R.id.reading_details);
        due_date_details = findViewById(R.id.due_date_details);
        status_details = findViewById(R.id.status_details);
        consumption_details = findViewById(R.id.consumption_details);
        price_details = findViewById(R.id.price_details);
        view_all_bills = findViewById(R.id.view_all_bills);
        notif_history = findViewById(R.id.notif_history);
        imageView_water = findViewById(R.id.imageView_water);

        averageText  = findViewById(R.id.averageText);
        speedometerLayout = findViewById(R.id.speedometerLayout);
        linear_layout_dark_blue = findViewById(R.id.linear_layout_dark_blue);

        no_announcement_logo = findViewById(R.id.no_announcement_logo);
        announcement_logo= findViewById(R.id.announcement_logo);
        select_year_id = findViewById(R.id.select_year_id);

        speedometerProgressBar = findViewById(R.id.speedometerProgressBar);

        profile_icon  = findViewById(R.id.profile_icon);
        hello_details = findViewById(R.id.hello_details);

        SwipeRefreshLayout swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Add the logic to refresh your RecyclerView data here

                // Simulate a network call or data update (use your actual data refresh logic)
                refreshRecyclerViewData();

                // Once the refresh is complete, stop the refreshing animation
                swipeRefreshLayout.setRefreshing(false);
            }
        });

        view_all_bills.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inflate the dialog layout
                LayoutInflater inflater = LayoutInflater.from(ConsumerHome.this);
                View dialogView = inflater.inflate(R.layout.dialog_form_with_recyclerview, null);

                // Create the AlertDialog
                AlertDialog.Builder builder = new AlertDialog.Builder(ConsumerHome.this);
                builder.setView(dialogView);
                builder.setTitle("View All Bills");

                // Initialize RecyclerView
                RecyclerView recyclerView = dialogView.findViewById(R.id.recyclerView);
                recyclerView.setLayoutManager(new LinearLayoutManager(ConsumerHome.this));

                // Provide data to adapter
                History_Bill_Adapter adapter = new History_Bill_Adapter(ConsumerHome.this, billList);
                recyclerView.setAdapter(adapter);

                // Set the negative button for closing the dialog
                builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss(); // Close the dialog
                    }
                });

                // Show the dialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        notif_history.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inflate the dialog layout
                LayoutInflater inflater = LayoutInflater.from(ConsumerHome.this);
                View dialogView = inflater.inflate(R.layout.dialog_form_with_notif_history_recyclerview, null);

                // Create the AlertDialog
                AlertDialog.Builder builder = new AlertDialog.Builder(ConsumerHome.this);
                builder.setView(dialogView);
                builder.setTitle("Notification History");

                // Initialize RecyclerView
                RecyclerView recyclerView = dialogView.findViewById(R.id.recyclerView);
                recyclerView.setLayoutManager(new LinearLayoutManager(ConsumerHome.this));

                // Provide data to adapter
                Notification_History_Adapter adapter = new Notification_History_Adapter(ConsumerHome.this, notifList);
                recyclerView.setAdapter(adapter);

                // Set the negative button for closing the dialog
                builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss(); // Close the dialog
                    }
                });

                // Show the dialog
                AlertDialog dialog = builder.create();
                dialog.show();
            }
        });

        findViewById(R.id.buttonDrawerToggle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(navigationView)) {
                    drawerLayout.closeDrawer(navigationView);
                } else {
                    drawerLayout.openDrawer(navigationView);
                }
            }
        });

        // Check if the user is already logged in
        if (isUserLoggedIn()) {
            fetchDataFromServer();
            Hello_User();
        } else {
            // Redirect to the login screen
            startActivity(new Intent(ConsumerHome.this, MainActivity.class));
            finish();
        }

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.navHome) {
                    // Handle navigation item click for Home
                    startActivity(new Intent(ConsumerHome.this, ConsumerHome.class));
                } else if (itemId == R.id.navProfile) {
                    startActivity(new Intent(ConsumerHome.this, Consumer_Profile.class));
                } else if (itemId == R.id.navHistory) {
                    // Handle navigation item click for History
                    startActivity(new Intent(ConsumerHome.this, Report_Problem.class));
                } else if (itemId == R.id.navViolation) {
                    // Handle navigation item click for History
                    startActivity(new Intent(ConsumerHome.this, Consumer_Violation.class));
                } else if (itemId == R.id.navLogout) {
                    logout();
                }
                drawerLayout.closeDrawer(navigationView);
                return true;
            }
        });

        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        int readers_id = sharedPreferences.getInt("r_id", 0);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // Get the current year
        String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));

        // Call viewhistory with both the reader ID and current year
            viewhistory(readers_id, currentYear);
        notif_history(meter_number);
    }
    private void displayCurrentMonthBills() {
        List<History_Bill_Call> unpaidBills = new ArrayList<>();
        List<History_Bill_Call> currentMonthBills = new ArrayList<>();
        List<History_Bill_Call> closestMonthBills = new ArrayList<>();

        // Get the current month and year
        Calendar calendar = Calendar.getInstance();
        int currentMonth = calendar.get(Calendar.MONTH); // 0-based (January = 0)
        int currentYear = calendar.get(Calendar.YEAR);

        // Date format without the time portion (only "yyyy-MM-dd")
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        SimpleDateFormat displayDateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault()); // User-friendly format

        // Filter bills and match the current month and year
        for (History_Bill_Call bill : billList) {
            try {
                Date billDate = dateFormat.parse(bill.getDate());
                Calendar billCalendar = Calendar.getInstance();
                billCalendar.setTime(billDate);

                int billMonth = billCalendar.get(Calendar.MONTH);
                int billYear = billCalendar.get(Calendar.YEAR);

                // Check if the bill's month and year match the current month and year
                if (billMonth == currentMonth && billYear == currentYear) {
                    if ("unpaid".equalsIgnoreCase(bill.getStatus())) {
                        unpaidBills.add(bill);
                    } else {
                        currentMonthBills.add(bill);
                    }
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        List<History_Bill_Call> displayBills = unpaidBills.isEmpty() ? currentMonthBills : unpaidBills;

        // If no unpaid bills and no bills found for the current month, search for the closest previous month
        if (displayBills.isEmpty() && currentMonthBills.isEmpty()) {
            for (int i = currentMonth - 1; i >= 0 || currentYear > 0; i--) {
                int monthToCheck = i;
                int yearToCheck = currentYear;

                if (monthToCheck < 0) {
                    monthToCheck = 11; // Go to December of the previous year
                    yearToCheck--;
                }

                // Filter bills for this previous month
                for (History_Bill_Call bill : billList) {
                    try {
                        Date billDate = dateFormat.parse(bill.getDate());
                        Calendar billCalendar = Calendar.getInstance();
                        billCalendar.setTime(billDate);

                        int billMonth = billCalendar.get(Calendar.MONTH);
                        int billYear = billCalendar.get(Calendar.YEAR);

                        // Check if the bill's month and year match the month we are checking
                        if (billMonth == monthToCheck && billYear == yearToCheck) {
                            closestMonthBills.add(bill);
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }

                if (!closestMonthBills.isEmpty()) {
                    displayBills = closestMonthBills;
                    break; // Exit the loop once we find a previous month with bills
                }
            }
        }

        // Sort the bills by date in descending order
        Collections.sort(displayBills, (b1, b2) -> {
            try {
                Date date1 = dateFormat.parse(b1.getDueDate());
                Date date2 = dateFormat.parse(b2.getDueDate());
                return date2.compareTo(date1); // Descending order
            } catch (ParseException e) {
                e.printStackTrace();
                return 0;
            }
        });

        if (!displayBills.isEmpty()) {
            // Display the latest bill's details
            History_Bill_Call latestBill = displayBills.get(0);
            try {
                Date billDate = dateFormat.parse(latestBill.getDate());
                Date dueDate = dateFormat.parse(latestBill.getDueDate());

                String bold = "<b>";
                String endBold = "</b>";
                String indent = "<br>"; // HTML line break for indentation

                reading_details.setText(Html.fromHtml(bold + "Reading Date: " + displayDateFormat.format(billDate) + endBold));
                due_date_details.setText(Html.fromHtml(bold + "Due Date: " + displayDateFormat.format(dueDate) + endBold));
                consumption_details.setText(Html.fromHtml(bold + "Consumption: " + latestBill.getM3() + " m³" + endBold));
                price_details.setText(Html.fromHtml(bold + "Price: " + latestBill.getPrice() + ".00 Php" + endBold));

                // Create a SpannableStringBuilder for the status
                String statusText = "Status: ";
                String statusValue = latestBill.getStatus().toLowerCase();

// Capitalize the first letter of the status value
                statusValue = statusValue.substring(0, 1).toUpperCase() + statusValue.substring(1);

                SpannableStringBuilder spannableStatus = new SpannableStringBuilder();

// Add the bold "Status:" part without color
                SpannableString boldStatusText = new SpannableString(statusText);
                boldStatusText.setSpan(new StyleSpan(Typeface.BOLD), 0, statusText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                spannableStatus.append(boldStatusText);

// Add the status value ("Paid" or "Unpaid") with color
                SpannableString statusSpan = new SpannableString(statusValue);

// Apply color only to the status value
                if ("Unpaid".equalsIgnoreCase(statusValue)) {
                    statusSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#FF4C4C")), 0, statusValue.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); // Red
                } else if ("Paid".equalsIgnoreCase(statusValue)) {
                    statusSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#4CAF50")), 0, statusValue.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); // Green
                }

// Apply italic style to the status value
                statusSpan.setSpan(new StyleSpan(Typeface.ITALIC), 0, statusValue.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

// Append the styled status value to the SpannableStringBuilder
                spannableStatus.append(statusSpan);

// Set the final SpannableStringBuilder to the TextView
                status_details.setText(spannableStatus);

            } catch (ParseException e) {
                e.printStackTrace();
            }
        } else {
            // Clear the fields if no bills are found
            reading_details.setText("No bills found.");
            due_date_details.setText("");
            consumption_details.setText("");
            price_details.setText("");
            status_details.setText("");
        }

    }

    private void viewhistory(int readers_id, String year) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/view_bills.php?readers_id=" + readers_id + "&year=" + year;
        Log.d("ViewHistory", "Requesting history for reader ID: " + readers_id + " and year: " + year);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            if (jsonResponse.has("success")) {
                                JSONArray jsonArray = jsonResponse.getJSONArray("success");

                                billList.clear(); // Clear previous data

                                // Iterate through JSON Array and add bills to billList
                                for (int i = 0; i < jsonArray.length(); i++) {
                                    JSONObject jsonObject = jsonArray.getJSONObject(i);
                                    String readingId = jsonObject.getString("reading_id");
                                    String past = jsonObject.getString("past");
                                    String present = jsonObject.getString("present");
                                    String m3 = jsonObject.getString("m3");
                                    String price = jsonObject.getString("price");
                                    String status = jsonObject.getString("status");
                                    String date = jsonObject.getString("date");
                                    String due_date = jsonObject.getString("due_date");

                                    History_Bill_Call billItem = new History_Bill_Call(readingId, past, present, m3, price, status, date, due_date);
                                    billList.add(billItem);

                                    Log.d("ViewHistory", "Added bill: " + billItem);
                                }
                                populateYearSpinner();
                                // Update the ColumnChartView with the new data
                                updateColumnChart(year);
                                displayCurrentMonthBills();
                                yearSpinner.setVisibility(View.VISIBLE);
                                reading_details.setVisibility(View.VISIBLE);
                                notif_history.setVisibility(View.VISIBLE);
                                due_date_details.setVisibility(View.VISIBLE);
                                consumption_details.setVisibility(View.VISIBLE);
                                profile_icon.setVisibility(View.VISIBLE);
                                hello_details.setVisibility(View.VISIBLE);
                                price_details.setVisibility(View.VISIBLE);
                                status_details.setVisibility(View.VISIBLE);
                                view_all_bills.setVisibility(View.VISIBLE);
                                select_year_id.setVisibility(View.VISIBLE);
                                linear_layout_dark_blue.setVisibility(View.VISIBLE);

                            } else {
                                Toast.makeText(ConsumerHome.this, "No bills found", Toast.LENGTH_SHORT).show();
                                reading_details.setVisibility(View.GONE);
                                due_date_details.setVisibility(View.GONE);
                                consumption_details.setVisibility(View.GONE);
                                price_details.setVisibility(View.GONE);
                                profile_icon.setVisibility(View.GONE);
                                hello_details.setVisibility(View.GONE);
                                status_details.setVisibility(View.GONE);
                                view_all_bills.setVisibility(View.GONE);
                                select_year_id.setVisibility(View.GONE);
                                yearSpinner.setVisibility(View.GONE);
                                linear_layout_dark_blue.setVisibility(View.GONE);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(ConsumerHome.this, "No bills found", Toast.LENGTH_SHORT).show();
                            reading_details.setVisibility(View.GONE);
                            due_date_details.setVisibility(View.GONE);
                            consumption_details.setVisibility(View.GONE);
                            price_details.setVisibility(View.GONE);
                            profile_icon.setVisibility(View.GONE);
                            hello_details.setVisibility(View.GONE);
                            status_details.setVisibility(View.GONE);
                            notif_history.setVisibility(View.GONE);
                            view_all_bills.setVisibility(View.GONE);
                            select_year_id.setVisibility(View.GONE);
                            yearSpinner.setVisibility(View.GONE);
                            linear_layout_dark_blue.setVisibility(View.GONE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = ""; // Initialize message as blank

                        // Handle specific VolleyError instances
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "An error occurred! Please try again."; // Fallback for any other error types
                        }

                        // Display appropriate Toast message
                        Toast.makeText(ConsumerHome.this, message, Toast.LENGTH_SHORT).show();
                        reading_details.setVisibility(View.GONE);
                        due_date_details.setVisibility(View.GONE);
                        consumption_details.setVisibility(View.GONE);
                        price_details.setVisibility(View.GONE);
                        status_details.setVisibility(View.GONE);
                        profile_icon.setVisibility(View.GONE);
                        hello_details.setVisibility(View.GONE);
                        notif_history.setVisibility(View.GONE);
                        view_all_bills.setVisibility(View.GONE);
                        select_year_id.setVisibility(View.GONE);
                        yearSpinner.setVisibility(View.GONE);
                        linear_layout_dark_blue.setVisibility(View.GONE);
                        // Log the error for debugging purposes
                        Log.e("VolleyError", message);
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void notif_history(String meter_number) {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/fetching_announcements.php?meter_number=" + meter_number;
        Log.d("ViewHistory", "Requesting notif_history for meter_number: " + meter_number);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            // Parse the response as a JSON Array directly
                            JSONArray jsonArray = new JSONArray(response);

                            notifList.clear(); // Clear previous data

                            // Iterate through JSON Array and add items to notifList
                            for (int i = 0; i < jsonArray.length(); i++) {
                                JSONObject jsonObject = jsonArray.getJSONObject(i);

                                String notif_id = jsonObject.getString("notif_id");
                                String content_title = jsonObject.getString("content_title");
                                String content_text = jsonObject.getString("content_text");
                                String date_time = jsonObject.getString("date_time");

                                // Log all the data for debugging
                                Log.d("NotifData", "Notification " + i + ": " +
                                        "notif_id=" + notif_id + ", " +
                                        "content_title=" + content_title + ", " +
                                        "content_text=" + content_text + ", " +
                                        "date_time=" + date_time);

                                // Create a new instance of Notification_History_Call
                                Notification_History_Call notification = new Notification_History_Call(notif_id, content_title, content_text, date_time);

                                // Add the notification object to the list
                                notifList.add(notification);
                            }

                            // Update UI visibility
                            yearSpinner.setVisibility(View.VISIBLE);
                            reading_details.setVisibility(View.VISIBLE);
                            due_date_details.setVisibility(View.VISIBLE);
                            consumption_details.setVisibility(View.VISIBLE);
                            profile_icon.setVisibility(View.VISIBLE);
                            hello_details.setVisibility(View.VISIBLE);
                            price_details.setVisibility(View.VISIBLE);
                            status_details.setVisibility(View.VISIBLE);
                            view_all_bills.setVisibility(View.VISIBLE);
                            notif_history.setVisibility(View.VISIBLE);
                            select_year_id.setVisibility(View.VISIBLE);
                            linear_layout_dark_blue.setVisibility(View.VISIBLE);

                        } catch (JSONException e) {
                            e.printStackTrace();
                            hideNotificationDetails();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = getErrorMessage(error);

                        // Hide UI elements in case of error
                        hideNotificationDetails();

                        // Log the error for debugging purposes
                        Log.e("VolleyError", message);
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void hideNotificationDetails() {
        reading_details.setVisibility(View.GONE);
        due_date_details.setVisibility(View.GONE);
        consumption_details.setVisibility(View.GONE);
        price_details.setVisibility(View.GONE);
        status_details.setVisibility(View.GONE);
        notif_history.setVisibility(View.GONE);
        profile_icon.setVisibility(View.GONE);
        hello_details.setVisibility(View.GONE);
        view_all_bills.setVisibility(View.GONE);
        select_year_id.setVisibility(View.GONE);
        yearSpinner.setVisibility(View.GONE);
        linear_layout_dark_blue.setVisibility(View.GONE);
    }

    private String getErrorMessage(VolleyError error) {
        if (error instanceof TimeoutError) {
            return "Request timed out";
        } else if (error instanceof NoConnectionError) {
            return "No internet connection";
        } else if (error instanceof ServerError) {
            return "Server error";
        } else if (error instanceof NetworkError) {
            return "Network error";
        } else {
            return "An error occurred! Please try again.";
        }
    }


    /// Method to populate the spinner with years
    private void populateYearSpinner() {
        Set<String> years = new HashSet<>(); // Use a Set to avoid duplicate years

        // Extract years from billList
        for (History_Bill_Call bill : billList) {
            String dateString = bill.getDate();
            Log.d("PopulateYearSpinner", "Date from bill: " + dateString); // Log the date string

            int year = getYearFromDate(dateString);
            if (year != -1) {
                years.add(String.valueOf(year));
            }
        }

        Log.d("PopulateYearSpinner", "Years extracted: " + years); // Log the extracted years

        // Convert Set to List and sort it
        List<String> sortedYears = new ArrayList<>(years);
        Collections.sort(sortedYears);

// Find Spinner in layout and set up adapter
        Spinner yearSpinner = findViewById(R.id.yearSpinner);

// Use the correct custom layout for the ArrayAdapter
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, R.layout.spinner_item, sortedYears);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        yearSpinner.setAdapter(adapter);


        // Set default value to the current year
        String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        int defaultPosition = sortedYears.indexOf(currentYear);
        if (defaultPosition != -1) {
            yearSpinner.setSelection(defaultPosition);
        } else if (!sortedYears.isEmpty()) {
            // If the current year is not in the list, select the first year
            yearSpinner.setSelection(0);
        }

        // Set spinner item selected listener
        yearSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedYear = (String) parent.getItemAtPosition(position);
                Log.d("PopulateYearSpinner", "Selected year: " + selectedYear); // Log selected year
                updateColumnChart(selectedYear); // Call with String argument
                AverageSpinner(selectedYear);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });
    }
    private void AverageSpinner(String selectedYear) {
        // Initialize variables for calculating the total sum and average
        float totalM3 = 0; // Total sum of all M³ values for the selected year
        int totalRecords = 0; // Total count of records for the selected year

        // Loop through the bill data to calculate the total M³ for the selected year
        for (History_Bill_Call bill : billList) {
            String dateString = bill.getDate();
            int year = getYearFromDate(dateString); // Extract the year from the date

            if (String.valueOf(year).equals(selectedYear)) { // Filter by selected year
                try {
                    float value = Float.parseFloat(bill.getM3());
                    totalM3 += value; // Add the M³ value to the total
                    totalRecords++; // Increment the count of records
                    Log.d("UpdateColumnChart", "Adding M3 value: " + value + " for year: " + selectedYear);
                } catch (NumberFormatException e) {
                    Log.e("UpdateColumnChart", "Invalid M3 value: " + bill.getM3());
                }
            }
        }

        // Calculate the average M³ by dividing the total by 12 (12 months in a year)
        float totalAverageM3 = totalM3 / 12; // Evenly distribute across 12 months

        // Log the total sum and average for debugging
        Log.d("UpdateColumnChart", "Total M3 for selected year: " + totalM3);
        Log.d("UpdateColumnChart", "Average M3 (distributed across 12 months): " + totalAverageM3);

        // Update the average TextView to show the total average M³
        TextView averageText = findViewById(R.id.averageText);
        averageText.setText("Average m³ : " + String.format("%.2f", totalAverageM3));
    }

    private void updateColumnChart(String selectedYear) {
        // Reset the animation flag whenever the chart is updated
        isAnimationStarted = false;

        List<Column> columns = new ArrayList<>();
        List<AxisValue> axisValues = new ArrayList<>(); // List to hold months for X-axis labels
        float[] m3ValuesPerMonth = new float[12]; // Array to store summed M3 values per month

        // Initialize X-axis with abbreviated month names (Jan, Feb, Mar, etc.)
        String[] months = new String[]{"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};

        // Directly add each AxisValue manually for months
        for (int i = 0; i < months.length; i++) {
            axisValues.add(new AxisValue(i).setLabel(months[i]));
        }

        // Map the bill data to the corresponding month
        for (History_Bill_Call bill : billList) {
            String dateString = bill.getDate();
            int monthIndex = getMonthIndex(dateString); // Get the index of the month from the date
            int year = getYearFromDate(dateString); // Extract the year from the date

            if (String.valueOf(year).equals(selectedYear)) { // Filter by selected year
                if (monthIndex >= 0 && monthIndex < 12) {
                    float value = Float.parseFloat(bill.getM3());
                    m3ValuesPerMonth[monthIndex] += value; // Sum up values if multiple entries for the same month
                    Log.d("UpdateColumnChart", "Adding M3 value: " + value + " to month " + months[monthIndex]);
                }
            }
        }

        // Log the summed M3 values per month
        for (int i = 0; i < 12; i++) {
            Log.d("UpdateColumnChart", "Total M3 for " + months[i] + ": " + m3ValuesPerMonth[i]);
        }

        // Create columns for each month
        for (int i = 0; i < 12; i++) {
            // Format the M3 value to one decimal place
            float formattedValue = (float) (Math.round(m3ValuesPerMonth[i] * 10.0) / 10.0);

            List<SubcolumnValue> subcolumnValues = new ArrayList<>();
            SubcolumnValue subcolumnValue = new SubcolumnValue(formattedValue, Color.parseColor("#41B8D5"));

            // Apply gradient effect
            subcolumnValue.setColor(Color.parseColor("#41B8D5")); // Set the starting color
            subcolumnValues.add(subcolumnValue);

            // Create Column object and add the subcolumn values
            Column column = new Column(subcolumnValues);
            column.setHasLabelsOnlyForSelected(false); // Optional: Adjust if you want labels only on selected columns
            column.setHasLabels(true); // Show labels on columns

            columns.add(column);
        }

        // Create ColumnChartData object
        ColumnChartData data = new ColumnChartData(columns);

        // Customize the X-axis (Abbreviated Months as labels)
        Axis axisX = new Axis();
        axisX.setName("Month"); // Label for the X-axis
        axisX.setTextColor(Color.parseColor("#E6E1E1"));
        axisX.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        axisX.setValues(axisValues); // Set custom axis values (months)
        axisX.setHasLines(false); // Remove grid lines for the X-axis (Month)
        axisX.setTextSize(11); // Adjust text size for better fit
        axisX.setMaxLabelChars(2); // Limit label characters to avoid overlap

        // Customize the Y-axis (M3)
        Axis axisY = new Axis();
        axisY.setName("M3"); // Label for the Y-axis
        axisY.setTextColor(Color.parseColor("#E6E1E1"));
        axisY.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        axisY.setHasLines(true); // Enable grid lines for the Y-axis (M3)

        // Find the maximum value manually
        float maxYValue = 0;
        for (float value : m3ValuesPerMonth) {
            if (value > maxYValue) {
                maxYValue = value;
            }
        }

        // Round up to the next whole number
        int roundedMaxYValue = (int) Math.ceil(maxYValue);

        // Set step size to ensure whole number labels
        int step = 1; // Step size for whole numbers

        // Add labels manually for integer values
        List<AxisValue> yAxisValues = new ArrayList<>();
        for (int i = 0; i <= roundedMaxYValue; i++) {
            yAxisValues.add(new AxisValue(i).setLabel(String.valueOf(i)));
        }
        axisY.setValues(yAxisValues);

        // Adjust Y-axis to fit the full range of data
        Viewport viewport = new Viewport(columnChartView.getMaximumViewport());
        viewport.top = roundedMaxYValue + 1; // Add some padding above the max value
        viewport.bottom = 0;
        columnChartView.setMaximumViewport(viewport);
        columnChartView.setCurrentViewport(viewport);

        axisY.setHasLines(true); // Keep grid lines for the Y-axis
        axisY.setTextSize(12); // Adjust text size for better fit

        data.setAxisYLeft(axisY); // Set Y-axis position
        data.setAxisXBottom(axisX); // Set X-axis position

        // Apply the ColumnChartData to your ColumnChartView
        columnChartView.setColumnChartData(data);
        columnChartView.setInteractive(true);

        // Create a TranslateAnimation to animate the chart upwards only once
        if (!isAnimationStarted) {  // Check the animation flag
            TranslateAnimation animation = new TranslateAnimation(0, 0, columnChartView.getHeight(), 0);
            animation.setDuration(1000); // Duration of the animation in milliseconds
            animation.setInterpolator(new AccelerateDecelerateInterpolator()); // Smooth acceleration and deceleration

            // Start the animation
            columnChartView.startAnimation(animation);
            isAnimationStarted = true; // Set the flag to true after the animation starts
        }

        // Configure zooming and scrolling behavior
        columnChartView.setZoomLevel(0, 0, 0); // Set initial zoom level
        columnChartView.setZoomEnabled(true); // Allow zooming
        columnChartView.setScrollEnabled(true); // Allow panning (horizontal scrolling)
        columnChartView.setZoomType(ZoomType.HORIZONTAL); // Only horizontal zoom enabled

        // Ensure that the labels are visible and spaced properly
        columnChartView.setViewportCalculationEnabled(false); // Prevent auto-scaling of labels
        columnChartView.setCurrentViewport(viewport); // Set viewport to match chart data

        Log.d("UpdateColumnChart", "Chart updated");

        columnChartView.setOnValueTouchListener(new ColumnChartOnValueSelectListener() {
            @Override
            public void onValueSelected(int columnIndex, int subcolumnIndex, SubcolumnValue value) {
                // Get the value for the clicked column (using value.getValue() for M3 value)
                float m3Value = value.getValue();  // Use the SubcolumnValue to get the value
                String month = months[columnIndex];

                // Find the corresponding bills for the selected month (assuming you have a billList)
                List<History_Bill_Call> selectedBills = new ArrayList<>();
                float totalM3ForMonth = 0; // Track the total M3 for this month

                // Loop through the bill list to find all bills for the selected month
                for (History_Bill_Call bill : billList) {
                    // Match the month to the bill (you might need to customize this matching logic)
                    int billMonthIndex = getMonthIndexFromBillDate(bill.getDate());  // Implement this helper method
                    if (billMonthIndex == columnIndex) {
                        float billM3Value = Float.parseFloat(bill.getM3());
                        totalM3ForMonth += billM3Value; // Sum M3 values for the same month
                        selectedBills.add(bill); // Add bill to the list for this month
                    }
                }

                // If matching bills are found, show the dialog with the total M3 value for that month
                if (!selectedBills.isEmpty()) {
                    // Pass selectedYear along with the other arguments
                    showColumnDetailsDialog(totalM3ForMonth, selectedBills, Integer.parseInt(selectedYear));  // Pass the selectedYear here
                } else {
                    // Handle the case when no matching bills are found (optional)
                    showColumnDetailsDialog(totalM3ForMonth, selectedBills, Integer.parseInt(selectedYear));
                }
            }

            @Override
            public void onValueDeselected() {
                // Handle deselection if needed
            }
        });
    }

    private void showColumnDetailsDialog(float totalM3Value, List<History_Bill_Call> bills, int selectedYear) {
        // Log the selected year and the total M3 value
        Log.d("ColumnDetails", "Selected year: " + selectedYear);
        Log.d("ColumnDetails", "Total M3 for the year: " + totalM3Value);

        // Initialize a dialog builder
        AlertDialog.Builder builder = new AlertDialog.Builder(this);

        // Inflate the custom layout using LayoutInflater
        View dialogView = LayoutInflater.from(this).inflate(R.layout.inflater_column_bill_details, null);

        // Find views in the inflated layout
        TextView present_reading = dialogView.findViewById(R.id.present_reading);
        TextView past_reading = dialogView.findViewById(R.id.past_reading);
        TextView price_reading = dialogView.findViewById(R.id.price_reading);
        TextView status_txt = dialogView.findViewById(R.id.status_txt);
        TextView bill_date = dialogView.findViewById(R.id.bill_date);
        TextView bill_due_date = dialogView.findViewById(R.id.bill_due_date);

        // Sum M3 values for the dialog details
        float dialogTotalM3 = 0;
        if (!bills.isEmpty()) {
            History_Bill_Call bill = bills.get(0); // Assuming single-bill details for simplicity
            dialogTotalM3 += Float.parseFloat(bill.getM3());

            // Log details
            Log.d("ColumnDetails", "Bill ID: " + bill.getReadingId() + " M3 Value: " + dialogTotalM3);

            // Format values and set text for the fields
            String formattedPrice = "₱ " + String.format("%.2f", Double.parseDouble(bill.getPrice()));
            String formattedPastReading = bill.getPast();
            String formattedPresentReading = bill.getPresent();
            String formattedBillDate = formatDateToWords(bill.getDate());
            String formattedDueDate = formatDateToWords(bill.getDueDate());

            // Use HTML for bold formatting and line breaks
            String bold = "<b>";
            String endBold = "</b>";
            String indent = "<br>";

            past_reading.setText(Html.fromHtml(bold + "Past Reading" + endBold + indent + formattedPastReading + " m³"));
            present_reading.setText(Html.fromHtml(bold + "Present Reading" + endBold + indent + formattedPresentReading + " m³"));
            price_reading.setText(Html.fromHtml(bold + "Amount" + endBold + indent + formattedPrice));

            // Set the formatted status with color based on its value
            String status = bill.getStatus(); // Get the status
            String statusText = "Status"; // Static part "Status"
            String statusValue = status.toLowerCase(); // Convert to lowercase for manipulation
            statusValue = statusValue.substring(0, 1).toUpperCase() + statusValue.substring(1); // Capitalize first letter

            SpannableStringBuilder spannableStatus = new SpannableStringBuilder();

            // Add "Status:" with bold style
            SpannableString boldStatusText = new SpannableString(statusText);
            boldStatusText.setSpan(new StyleSpan(Typeface.BOLD), 0, boldStatusText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            spannableStatus.append(boldStatusText);

            // Add a line break after "Status:"
            spannableStatus.append("\n");

            // Apply italic style and color to the status value
            SpannableString statusSpan = new SpannableString(statusValue);
            statusSpan.setSpan(new StyleSpan(Typeface.ITALIC), 0, statusValue.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            if ("Unpaid".equals(statusValue)) {
                statusSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#c30010")), 0, statusValue.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); // Red for Unpaid
            } else if ("Paid".equals(statusValue)) {
                statusSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#0B6623")), 0, statusValue.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE); // Green for Paid
            }

            // Append the styled status value to the SpannableStringBuilder
            spannableStatus.append(statusSpan);
            status_txt.setText(spannableStatus);

            bill_date.setText(Html.fromHtml(bold + "Bill Date" + endBold + indent + formattedBillDate));
            bill_due_date.setText(Html.fromHtml(bold + "Due Date" + endBold + indent + formattedDueDate));
        } else {
            Log.d("ColumnDetails", "No bills available to display.");
        }

        // Build and show the dialog with the inflated view
        builder.setTitle("Bill Column Details")
                .setView(dialogView)
                .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                .show();
    }

    // Helper method to format date in "Month Day, Year" format
        private String formatDateToWords(String date) {
            try {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                Date parsedDate = sdf.parse(date);
                SimpleDateFormat newFormat = new SimpleDateFormat("MMMM dd, yyyy");  // Full month name, day, and year
                return newFormat.format(parsedDate);
            } catch (ParseException e) {
                e.printStackTrace();
                return date;  // In case of error, return the original date
            }
        }

        private int getMonthIndexFromBillDate(String date) {
        // Assuming the date format is "YYYY-MM-DD"
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date billDate = sdf.parse(date);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(billDate);
            return calendar.get(Calendar.MONTH);  // This returns the month index (0 for January, 1 for February, etc.)
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return -1;  // Return -1 if there's an error
    }


    // Helper method to get the year from a date string
    private int getYearFromDate(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date date;
        try {
            date = sdf.parse(dateString);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            return calendar.get(Calendar.YEAR); // Returns the year
        } catch (ParseException e) {
            e.printStackTrace();
            return -1; // Return -1 if parsing fails
        }
    }

    // Helper method to get the month index from a date string
    private int getMonthIndex(String dateString) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        Date date;
        try {
            date = sdf.parse(dateString);
            Calendar calendar = Calendar.getInstance();
            calendar.setTime(date);
            return calendar.get(Calendar.MONTH); // Returns the month (0-11)
        } catch (ParseException e) {
            e.printStackTrace();
            return -1; // Return -1 if parsing fails
        }
    }

    private void Hello_User(){
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        String firstname = sharedPreferences.getString("firstname", "");
        String lastname = sharedPreferences.getString("lastname", "");

        String bold = "<b>";
        String endBold = "</b>";
        String indent = "<br>";
        hello_details.setText(Html.fromHtml(bold + "Hello, " + indent + firstname + " "+ lastname +"!"+ endBold));
    }

    private void fetchDataFromServer() {
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, URL, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        // Check if the JSON array is empty
                        if (response.length() == 0) {
                            // No records found
                            Toast.makeText(ConsumerHome.this, "No announcements found", Toast.LENGTH_SHORT).show();
                            no_announcement_logo.setVisibility(View.VISIBLE);
                            announcement_logo.setVisibility(View.GONE);
                            recyclerView.setVisibility(View.GONE);
                        } else {
                            // Parse JSON response
                            parseJsonResponse(response);
                            // Show success message if necessary
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = ""; // Initialize message as blank

                        // Handle specific VolleyError instances
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "No announcements were discovered"; // Fallback for other error types
                        }

                        // Display appropriate Toast message
                        Toast.makeText(ConsumerHome.this, message, Toast.LENGTH_SHORT).show();
                        no_announcement_logo.setVisibility(View.VISIBLE);
                        announcement_logo.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.GONE);
                        reading_details.setVisibility(View.GONE);
                        due_date_details.setVisibility(View.GONE);
                        consumption_details.setVisibility(View.GONE);
                        price_details.setVisibility(View.GONE);
                        status_details.setVisibility(View.GONE);
                        view_all_bills.setVisibility(View.GONE);
                        select_year_id.setVisibility(View.GONE);
                        profile_icon.setVisibility(View.GONE);
                        hello_details.setVisibility(View.GONE);
                        imageView_water.setVisibility(View.GONE);
                        columnChartView.setVisibility(View.GONE);
                        yearSpinner.setVisibility(View.GONE);
                        speedometerProgressBar.setVisibility(View.GONE);
                        averageText.setVisibility(View.GONE);
                        speedometerLayout.setVisibility(View.GONE);
                        notif_history.setVisibility(View.GONE);
                        linear_layout_dark_blue.setVisibility(View.GONE);
                        // Log the error for debugging purposes
                        Log.e("VolleyError", message);
                    }
                });

        // Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }

    private void parseJsonResponse(JSONArray jsonArray) {
        try {
            // Clear existing data in the list
            announcementsList.clear();

            // Iterate through the JSON array and add data to the list
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                String announcement_id = jsonObject.optString("announcement_id");
                String title = jsonObject.optString("title");
                String content = jsonObject.optString("content");
                String created_at = jsonObject.optString("created_at");

                Announcements_Call announcementsCall = new Announcements_Call(announcement_id, title, content, created_at);
                announcementsList.add(announcementsCall);
            }

            // Notify the adapter about the data change
            announcementsAdapter.notifyDataSetChanged();

            // Show toast indicating successful loading of data
            Toast.makeText(ConsumerHome.this, "Announcements loaded successfully", Toast.LENGTH_SHORT).show();
            recyclerView.setVisibility(View.VISIBLE);
            announcement_logo.setVisibility(View.VISIBLE);
            announcement_logo.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
            reading_details.setVisibility(View.VISIBLE);
            due_date_details.setVisibility(View.VISIBLE);
            consumption_details.setVisibility(View.VISIBLE);
            price_details.setVisibility(View.VISIBLE);
            status_details.setVisibility(View.VISIBLE);
            view_all_bills.setVisibility(View.VISIBLE);
            select_year_id.setVisibility(View.VISIBLE);
            imageView_water.setVisibility(View.VISIBLE);
            columnChartView.setVisibility(View.VISIBLE);
            profile_icon.setVisibility(View.VISIBLE);
            hello_details.setVisibility(View.VISIBLE);
            yearSpinner.setVisibility(View.VISIBLE);
            speedometerProgressBar.setVisibility(View.VISIBLE);
            averageText.setVisibility(View.VISIBLE);
            notif_history.setVisibility(View.VISIBLE);
            speedometerLayout.setVisibility(View.VISIBLE);
            linear_layout_dark_blue.setVisibility(View.VISIBLE);
            no_announcement_logo.setVisibility(View.GONE);
            Toast.makeText(ConsumerHome.this, "Tap the title to see the details", Toast.LENGTH_LONG).show();

        } catch (JSONException e) {
            e.printStackTrace();
            // Error handling for JSON parsing
            Toast.makeText(ConsumerHome.this, "An error has occurred. Please try again", Toast.LENGTH_SHORT).show();
            announcement_logo.setVisibility(View.GONE);
            recyclerView.setVisibility(View.GONE);
            reading_details.setVisibility(View.GONE);
            due_date_details.setVisibility(View.GONE);
            consumption_details.setVisibility(View.GONE);
            price_details.setVisibility(View.GONE);
            status_details.setVisibility(View.GONE);
            view_all_bills.setVisibility(View.GONE);
            select_year_id.setVisibility(View.GONE);
            imageView_water.setVisibility(View.GONE);
            profile_icon.setVisibility(View.GONE);
            hello_details.setVisibility(View.GONE);
            columnChartView.setVisibility(View.GONE);
            yearSpinner.setVisibility(View.GONE);
            notif_history.setVisibility(View.GONE);
            speedometerProgressBar.setVisibility(View.GONE);
            averageText.setVisibility(View.GONE);
            linear_layout_dark_blue.setVisibility(View.GONE);
            speedometerLayout.setVisibility(View.GONE);
        }
    }


    private void logout() {
        // Create a confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Call PHP script for logout
                clearSessionData();
                Toast.makeText(ConsumerHome.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

                // Redirect to MainActivity
                Intent intent = new Intent(ConsumerHome.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear the back stack
                startActivity(intent);
                finish(); // Finish the current activity to prevent returning to it by pressing the back button
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Do nothing, simply dismiss the dialog
                dialogInterface.dismiss();
            }
        });

        // Display the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void clearSessionData() {
        // Clear user session data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.clear();
        editor.apply();
    }

    private boolean isUserLoggedIn() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        return sharedPreferences.getBoolean("isLoggedIn", false);
    }
    private void refreshRecyclerViewData() {
        fetchDataFromServer();
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        int readers_id = sharedPreferences.getInt("r_id", 0);
        String meter_number = sharedPreferences.getString("meter_number", "");

        // Get the current year
        String currentYear = String.valueOf(Calendar.getInstance().get(Calendar.YEAR));
        viewhistory(readers_id, currentYear);
        notif_history(meter_number);
    }
}