package com.example.waterworksapp;

public class Consumer_Violation_Class {
    private String readingId;
    private String past;
    private String present;
    private String m3;
    private String price;
    private String status;
    private String date;
    private String dueDate;
    private String violation;
    private String penalty;
    private String discount;
    private String total_due;
    private String date_paid;
    private String vio_history;


    public Consumer_Violation_Class(String readingId, String past, String present, String m3, String price, String status,
                                    String date,String dueDate, String violation, String penalty, String discount, String total_due, String date_paid, String vio_history ) {
        this.readingId = readingId;
        this.past = past;
        this.present = present;
        this.m3 = m3;
        this.price = price;
        this.status = status;
        this.date = date;
        this.dueDate = dueDate;
        this.violation = violation;
        this.penalty = penalty;
        this.discount = discount;
        this.total_due = total_due;
        this.date_paid = date_paid;
        this.vio_history = vio_history;
    }

    public String getReadingId() {
        return readingId;
    }

    public String getPast() {
        return past;
    }

    public String getPresent() {
        return present;
    }

    public String getM3() {
        return m3;
    }

    public String getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }

    public String getDate() {
        return date;
    }

    public String getDueDate() {
        return dueDate;
    }

    public String getViolation() {
        return violation;
    }
    public String getPenalty() {
        return penalty;
    }
    public String getDiscount() {
        return discount;
    }
    public String getTotal_due() {
        return total_due;
    }
    public String getDate_paid() {
        return date_paid;
    }
    public String getVio_history() {
        return vio_history;
    }

}
