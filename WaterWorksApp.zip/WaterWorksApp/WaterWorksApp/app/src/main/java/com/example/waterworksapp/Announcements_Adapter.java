package com.example.waterworksapp;

import android.content.Context;

import android.content.DialogInterface;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Announcements_Adapter extends RecyclerView.Adapter<Announcements_Adapter.UsersHolder> {

    Context context;
    List<Announcements_Call> usersList;

    public Announcements_Adapter(Context context, List<Announcements_Call> usersList) {
        this.context = context;
        this.usersList = usersList;
    }

    @NonNull
    @Override
    public UsersHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View UserLayout = LayoutInflater.from(parent.getContext()).inflate(R.layout.card_announcement,parent,false);
        return new UsersHolder(UserLayout);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersHolder holder, int position) {
        Announcements_Call user = usersList.get(position);

        String announce_id = user.announce_id();
        String title = user.gettitle();
        String created_at = user.getcreated_at();
        String content = user.getcontent();

        String bold = "<b>";
        String endBold = "</b>";
        String indent = "<br>"; // HTML entity for space repeated for indentation

        holder.titleTextView.setText(Html.fromHtml(bold + "Title" + endBold + indent + title));
        holder.titleTextView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Inflate the custom dialog layout
                View dialogView = LayoutInflater.from(context).inflate(R.layout.announcement_details, null);

                // Create a dialog
                android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(context);
                builder.setView(dialogView);

                // Set the title for the dialog
                builder.setTitle("Announcement Details");

                // Set the announcement details in the dialog
                TextView dialogContent = dialogView.findViewById(R.id.dialog_content);
                TextView date_time = dialogView.findViewById(R.id.date_time);

                // Define HTML formatting strings
                String bold = "<b>";
                String endBold = "</b>";
                String indent = "<br>"; // HTML entity for line break or space for indentation

                // Set formatted text to the dialog's TextViews
                dialogContent.setText(Html.fromHtml(bold + "Content" + endBold + indent + content)); // Format and set content
                date_time.setText(Html.fromHtml(bold + "Date & Time" + endBold + indent + created_at)); // Format and set date and time

                // Add a "Close" button that dismisses the dialog
                builder.setNegativeButton("Close", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss(); // Close the dialog
                    }
                });

                // Show the dialog
                android.app.AlertDialog dialog = builder.create();
                dialog.show();
            }
        });
    }
        @Override
    public int getItemCount() {
        return usersList.size();
    }

    public class UsersHolder extends RecyclerView.ViewHolder {
        TextView titleTextView;
        ConstraintLayout Layout;


        public UsersHolder(@NonNull View itemView) {
            super(itemView);
            titleTextView = itemView.findViewById(R.id.title_txt);
            Layout = itemView.findViewById(R.id.card_announcement);
        }
    }
}