package com.example.waterworksapp;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Html;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.SpannableStringBuilder;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Consumer_Violation_Adapter extends RecyclerView.Adapter<Consumer_Violation_Adapter.UsersHolder> {
    private List<Consumer_Violation_Class> items;
    private Context context;
    private SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
    private SimpleDateFormat displayDateFormat = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());

    public Consumer_Violation_Adapter(Context context, List<Consumer_Violation_Class> items) {
        this.context = context;
        this.items = items;
        sortBills(); // Sort bills on initialization
    }

    // Method to update the data and notify the adapter
    public void updateData(List<Consumer_Violation_Class> newItems) {
        this.items = newItems;
        sortBills(); // Ensure bills are sorted after update
        notifyDataSetChanged(); // Notify the adapter of the data change
    }

    private void sortBills() {
        Collections.sort(this.items, new Comparator<Consumer_Violation_Class>() {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            Date currentDate = new Date();

            @Override
            public int compare(Consumer_Violation_Class o1, Consumer_Violation_Class o2) {
                try {
                    Date date1 = sdf.parse(o1.getDueDate());
                    Date date2 = sdf.parse(o2.getDueDate());

                    boolean isO1Unpaid = "unpaid".equalsIgnoreCase(o1.getStatus());
                    boolean isO2Unpaid = "unpaid".equalsIgnoreCase(o2.getStatus());

                    if (isO1Unpaid && !isO2Unpaid) return -1;
                    if (!isO1Unpaid && isO2Unpaid) return 1;

                    if (isO1Unpaid && isO2Unpaid) {
                        return date1.compareTo(date2);
                    } else {
                        long diff1 = Math.abs(date1.getTime() - currentDate.getTime());
                        long diff2 = Math.abs(date2.getTime() - currentDate.getTime());
                        return Long.compare(diff1, diff2);
                    }

                } catch (ParseException e) {
                    e.printStackTrace();
                    return 0;
                }
            }
        });
    }

    @NonNull
    @Override
    public UsersHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.violation_card, parent, false);
        return new UsersHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersHolder holder, int position) {
        Consumer_Violation_Class item = items.get(position);
        holder.violationItem = item;
        String m3 = item.getM3();
        String price = item.getPrice();
        String status = item.getStatus();
        String date = item.getDate();
        String dueDate = item.getDueDate();
        String violation = item.getViolation();
        String penalty = item.getPenalty();
        String datePaid = item.getDate_paid();
        String discount = item.getDiscount();
        String totalDue = item.getTotal_due();
        String vio_history = item.getVio_history();

        try {
            Date billDate = dateFormat.parse(date);
            Date dueDateParsed = dateFormat.parse(dueDate);

            holder.dateTextView.setText(Html.fromHtml("<b>Reading Date</b><br>" + displayDateFormat.format(billDate)));
            holder.due_date_txt.setText(Html.fromHtml("<b>Due Date</b><br>" + displayDateFormat.format(dueDateParsed)));

            SpannableStringBuilder spannableStatus = new SpannableStringBuilder();

            SpannableString boldStatusText = new SpannableString("Status ");
            boldStatusText.setSpan(new StyleSpan(Typeface.BOLD), 0, boldStatusText.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            spannableStatus.append(boldStatusText);

            spannableStatus.append("\n");

            // Capitalize the first letter of the status
            String displayStatus = "Unpaid".equalsIgnoreCase(status) ? "Unpaid" : status;
            if (displayStatus.length() > 0) {
                displayStatus = displayStatus.substring(0, 1).toUpperCase() + displayStatus.substring(1).toLowerCase();
            }

            SpannableString statusSpan = new SpannableString(displayStatus);
            statusSpan.setSpan(new StyleSpan(Typeface.ITALIC), 0, displayStatus.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

            // Set the color based on the status
            if ("Unpaid".equalsIgnoreCase(displayStatus)) {
                statusSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#c30010")), 0, displayStatus.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            } else {
                statusSpan.setSpan(new ForegroundColorSpan(Color.parseColor("#0B6623")), 0, displayStatus.length(), Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
            }

            spannableStatus.append(statusSpan);
            holder.status_txt.setText(spannableStatus);

        } catch (ParseException e) {
            e.printStackTrace();
        }

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    public class UsersHolder extends RecyclerView.ViewHolder {
        TextView cubicTextView, priceTextView, dateTextView, due_date_txt, status_txt;
        ConstraintLayout layout;
        CardView cardView;
        Consumer_Violation_Class violationItem;

        public UsersHolder(@NonNull View itemView) {
            super(itemView);
            cubicTextView = itemView.findViewById(R.id.cubic_txt);
            priceTextView = itemView.findViewById(R.id.price_txt);
            dateTextView = itemView.findViewById(R.id.date_txt);
            due_date_txt = itemView.findViewById(R.id.due_date_txt);
            status_txt = itemView.findViewById(R.id.status_txt);
            layout = itemView.findViewById(R.id.violation_card);
            cardView = itemView.findViewById(R.id.cardView);

            cardView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (violationItem != null) {
                        showDetailDialog(violationItem);
                    } else {
                        // Handle the case where violationItem is null
                    }
                }
            });

        }

        private void showDetailDialog(Consumer_Violation_Class item) {
            if (item == null) {
                // Handle the case where the item is null
                return;
            }

            // Inflate the dialog layout
            LayoutInflater inflater = LayoutInflater.from(itemView.getContext());
            View dialogView = inflater.inflate(R.layout.dialog_violation_detail, null);

            // Find views in the dialog layout
            TextView m3_price = dialogView.findViewById(R.id.m3_price);
            TextView past = dialogView.findViewById(R.id.past);
            TextView present = dialogView.findViewById(R.id.present);
            TextView m3_consumed = dialogView.findViewById(R.id.m3_consumed);
            TextView date_paid = dialogView.findViewById(R.id.date_paid);
            TextView discount = dialogView.findViewById(R.id.discount);
            TextView vio_his = dialogView.findViewById(R.id.vio_his);
            TextView label_note = dialogView.findViewById(R.id.label_note);

            // Set the text with HTML formatting
            label_note.setText(Html.fromHtml("<b>Note:</b> Every 1 month overdue <b>10%</b> of price will be added as penalty"));

            // Format and set text for each TextView with the item's details
            String priceFormatted = String.format("%.2f Php", Double.parseDouble(item.getPrice()));
            m3_price.setText(Html.fromHtml("<b>Price</b><br>" + priceFormatted));

            present.setText(Html.fromHtml("<b>Present Reading</b><br>" + item.getPresent() + " m<sup>3</sup>"));
            past.setText(Html.fromHtml("<b>Past Reading</b><br>" + item.getPast() + " m<sup>3</sup>"));
            m3_consumed.setText(Html.fromHtml("<b>Consumed M<sup>3</sup></b><br>" + item.getM3() + " m<sup>3</sup>"));

            String datePaidFormatted = item.getDate_paid().equals("0000-00-00") ? "N/A" : item.getDate_paid();
            date_paid.setText(Html.fromHtml("<b>Date of Payment</b><br>" + datePaidFormatted));

            String discountFormatted = String.format("%.2f Php", Double.parseDouble(item.getDiscount()));
            discount.setText(Html.fromHtml("<b>Discount</b><br>" + discountFormatted));


            String vioHistoryFormatted = item.getVio_history();
            vio_his.setText(Html.fromHtml("<b>Violation</b><br>" + vioHistoryFormatted));

            // Check the violation status and adjust visibility
            if ("handled".equalsIgnoreCase(item.getViolation())) {
                // Show all TextViews except total_penalty_price
                discount.setVisibility(View.VISIBLE);
                date_paid.setVisibility(View.VISIBLE);
            } else {
                // Hide the fields that aren't needed
                discount.setVisibility(View.GONE);
                date_paid.setVisibility(View.GONE);
            }

            // Create and show the AlertDialog
            new AlertDialog.Builder(itemView.getContext())
                    .setTitle("Violation Details")
                    .setView(dialogView)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create()
                    .show();
        }

    }
}
