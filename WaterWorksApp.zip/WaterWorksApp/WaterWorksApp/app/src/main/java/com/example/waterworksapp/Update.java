package com.example.waterworksapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.text.InputType;
import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import android.widget.ImageView;
import org.json.JSONException;
import org.json.JSONObject;

public class Update extends AppCompatActivity {

    private EditText usernameEditText, passwordEditText, confirmPasswordEditText, emailEditText,otpEditText;
    private Button submitButton , emailOTP;
    private TextView usernameErrorTextView, passwordErrorTextView, contactErrorTextView, otpErrorTextView;
    private String URL = "https://luisianawaterworks.com/WaterWorks/Capstone/android/update_android.php";
    private String otp, otp_email;;
    private boolean hasError = false;
    private ImageView showPasswordImageView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        usernameEditText = findViewById(R.id.usernameEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        confirmPasswordEditText = findViewById(R.id.confirmPasswordEditText);
        emailEditText = findViewById(R.id.emailEditText);
        submitButton = findViewById(R.id.submitButton);
        usernameErrorTextView = findViewById(R.id.usernameErrorTextView);
        passwordErrorTextView = findViewById(R.id.passwordErrorTextView);
        contactErrorTextView = findViewById(R.id.contactErrorTextView);
        otpErrorTextView = findViewById(R.id.otpErrorTextView);
        otpEditText = findViewById(R.id.otpEditText);
        emailOTP = findViewById(R.id.emailOTP);
        showPasswordImageView = findViewById(R.id.imageViewShowPassword);

        ImageView backImageView = findViewById(R.id.backImageView);
        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Navigate back to the main activity
                Intent intent = new Intent(Update.this, MainActivity.class);
                startActivity(intent);
                finish(); // Optional, if you want to finish the current activity
            }
        });


        emailOTP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SendingOTP();
            }
        });
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Call forgotpass() with entered email and OTP
                String email_text = emailEditText.getText().toString().trim();
                String otp_text = otpEditText.getText().toString().trim();
                forgotpass(email_text,otp_text);

            }
        });

        ImageView showPasswordImageView = findViewById(R.id.imageViewShowPassword);
        showPasswordImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                togglePasswordVisibility();
            }
        });

    }


    private void SendingOTP() {
        hasError = false;
        String email = emailEditText.getText().toString().trim();

        // Validate email
        if (email.isEmpty()) {
            contactErrorTextView.setVisibility(View.VISIBLE);
            contactErrorTextView.setText("Email cannot be empty");
            hasError = true;
        }else if (!isValidEmail(email)) {
            contactErrorTextView.setVisibility(View.VISIBLE);
            contactErrorTextView.setText("Invalid email address");
            hasError = true;
        }  else {
            // Email is valid
            contactErrorTextView.setVisibility(View.GONE);
        }

        if (hasError) {
            // If there are validation errors, return without making the network request
            return;
        }

        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/sending_otp_android.php";

        // Create a StringRequest to make a POST request to the PHP script
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.optString("status");

                            if ("failure".equalsIgnoreCase(status)) {
                                // OTP sending failed, show error message
                                Toast.makeText(Update.this, "Failed to send OTP", Toast.LENGTH_SHORT).show();
                            } if ("error_consumer".equalsIgnoreCase(status)) {
                                // OTP sending failed, show error message
                                Toast.makeText(Update.this, "The email for this consumer account is disabled. OTP cannot be sent.", Toast.LENGTH_SHORT).show();
                            } if ("error_readers".equalsIgnoreCase(status)) {
                                // OTP sending failed, show error message
                                Toast.makeText(Update.this, "The email for this readers account is disabled. OTP cannot be sent.", Toast.LENGTH_SHORT).show();
                            }   else {
                                // OTP sent successfully, extract OTP
                                otp = jsonResponse.getString("otp");
                                otp_email = jsonResponse.getString("otp_email");
                                Log.d("OTP received", "OTP: " + otp);
                                Log.d("OTP email received", "OTP Email: " + otp_email);
                                // Display OTP or do something with it
                                Toast.makeText(Update.this, "OTP sent successfully: " + email, Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            // JSON exception
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "An error occurred. Please try again", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = ""; // Initialize message as blank

                        // Handle specific VolleyError instances
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "OTP sending failed. Please try again."; // Fallback for any other error types
                        }

                        // Display Toast message based on the error response
                        Toast.makeText(Update.this, message, Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                // Parameters to send to the PHP script (email in this case)
                Map<String, String> params = new HashMap<>();
                params.put("email", email);
                return params;
            }
        };

        // Add the request to the RequestQueue
        Volley.newRequestQueue(this).add(stringRequest);
    }

    private boolean isValidEmail(String email) {
        // Updated pattern to allow any domain
        String emailPattern = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}";

        // Validate email using the regex pattern
        return email.matches(emailPattern);
    }
    private void forgotpass(String email_text, String otp_text) {
        // Get text from EditText fields
        String username = usernameEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();
        String password2 = confirmPasswordEditText.getText().toString().trim();
        String email = emailEditText.getText().toString().trim();

        // Reset error flags
        hasError = false;

        // Validate username
        if (username.isEmpty()) {
            usernameErrorTextView.setVisibility(View.VISIBLE);
            usernameErrorTextView.setText("Username cannot be empty");
            hasError = true;
        } else {
            usernameErrorTextView.setVisibility(View.GONE);
        }

        // Validate entered OTP
        if (otp_text.isEmpty()) {
            otpErrorTextView.setVisibility(View.VISIBLE);
            otpErrorTextView.setText("OTP cannot be empty");
            hasError = true;
        } else if (!otp_text.equals(otp)) { // receivedOTP is the OTP received from sendingOTP() method
            otpErrorTextView.setVisibility(View.VISIBLE);
            otpErrorTextView.setText("OTP is incorrect/invalid");
            hasError = true;
        } else {
            otpErrorTextView.setVisibility(View.GONE);
        }

        // Validate password
        if (password.isEmpty() || password2.isEmpty()) {
            // Check if password or confirm password is empty
            passwordErrorTextView.setVisibility(View.VISIBLE);
            passwordErrorTextView.setText("Password and Confirm Password cannot be empty");
            hasError = true;
        } else if (password.length() < 8 || password2.length() < 8) {
            // Check if password or confirm password is less than 8 characters
            passwordErrorTextView.setVisibility(View.VISIBLE);
            passwordErrorTextView.setText("Password and Confirm Password must be at least 8 characters long");
            hasError = true;
        }  else if (!password.equals(password2)) {
            // Check if password and confirm password match
            passwordErrorTextView.setVisibility(View.VISIBLE);
            passwordErrorTextView.setText("Passwords do not match");
            hasError = true;
        } else if (!password.matches("[a-zA-Z0-9]*") || !password2.matches("[a-zA-Z0-9]*")) {
            // Check if password or confirm password contains special characters
            passwordErrorTextView.setVisibility(View.VISIBLE);
            passwordErrorTextView.setText("Password and Confirm Password cannot contain special characters");
            hasError = true;
        } else {
            // If all validations pass, hide the error message
            passwordErrorTextView.setVisibility(View.GONE);
        }

        // Validate email
        if (email.isEmpty()) {
            contactErrorTextView.setVisibility(View.VISIBLE);
            contactErrorTextView.setText("Email cannot be empty");
            hasError = true;
        } else if (!isValidEmail(email)) {
            contactErrorTextView.setVisibility(View.VISIBLE);
            contactErrorTextView.setText("Invalid email address");
            hasError = true;
        } else if(!email_text.equals(otp_email)) {
            contactErrorTextView.setVisibility(View.VISIBLE);
            contactErrorTextView.setText("Email does not match the one used for OTP");
            hasError = true;
        } else {
            // Email is valid
            contactErrorTextView.setVisibility(View.GONE);
        }

        // Check if there are any validation errors
        if (hasError) {
            // If there are validation errors, return without making the network request
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        if ("success".equalsIgnoreCase(response)) {
                            Toast.makeText(Update.this, "Updated successfully", Toast.LENGTH_SHORT).show();
                            clearFields();
                            clearErrors();
                            Intent intent = new Intent(Update.this, MainActivity.class);
                            startActivity(intent);
                            finish();
                        } else if ("failure".equalsIgnoreCase(response)) {
                            Toast.makeText(Update.this, "Update Failed! Please try again", Toast.LENGTH_SHORT).show();
                        } else if ("usernotfound".equalsIgnoreCase(response)) {
                            usernameErrorTextView.setText("Username not found!");
                            usernameErrorTextView.setVisibility(View.VISIBLE);
                            contactErrorTextView.setVisibility(View.GONE);
                        } else if ("emailmismatchreaders".equalsIgnoreCase(response)) {
                            contactErrorTextView.setText("Email mismatch with your username!");
                            contactErrorTextView.setVisibility(View.VISIBLE);
                        }else if ("emailmismatchreading".equalsIgnoreCase(response)) {
                            contactErrorTextView.setText("Email mismatch with your username!");
                            contactErrorTextView.setVisibility(View.VISIBLE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = ""; // Initialize message as blank

                        // Handle specific VolleyError instances
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "Resetting password failed. Please try again."; // Fallback for any other error types
                        }

                        // Display Toast message based on the error response
                        Toast.makeText(Update.this, message, Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Add parameters to the request
                Map<String, String> params = new HashMap<>();
                params.put("username", username);
                params.put("password", password);
                params.put("email", email);
                return params;
            }
        };

        // Add request to the request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void togglePasswordVisibility() {
        int passwordVisibility = passwordEditText.getInputType();
        int newPasswordVisibility;

        if (passwordVisibility == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
            newPasswordVisibility = InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD;
            showPasswordImageView.setImageResource(R.drawable.showpassclose); // Set icon for hidden password
        } else {
            newPasswordVisibility = InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD;
            showPasswordImageView.setImageResource(R.drawable.showpass); // Set icon for visible password
        }

        // Set the new input type for passwordEditText
        passwordEditText.setInputType(newPasswordVisibility);

        // Set the cursor position to the end of the text
        passwordEditText.setSelection(passwordEditText.getText().length());

        // Set the same input type for confirmPasswordEditText
        confirmPasswordEditText.setInputType(newPasswordVisibility);

        // Set the cursor position to the end of the text
        confirmPasswordEditText.setSelection(confirmPasswordEditText.getText().length());
    }

    private void clearFields() {
        usernameEditText.setText("");
        passwordEditText.setText("");
        emailEditText.setText("");
        confirmPasswordEditText.setText("");
        otpEditText.setText("");
    }
    private void clearErrors() {
        usernameErrorTextView.setVisibility(View.GONE);
        passwordErrorTextView.setVisibility(View.GONE);
        contactErrorTextView.setVisibility(View.GONE);
        otpErrorTextView.setVisibility(View.GONE);
    }

}
