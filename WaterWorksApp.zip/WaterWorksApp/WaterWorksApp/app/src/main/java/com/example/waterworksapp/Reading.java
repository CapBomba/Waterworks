package com.example.waterworksapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.style.AbsoluteSizeSpan;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;

import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.SearchView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.ParseError;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.google.android.material.navigation.NavigationView;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Reading extends AppCompatActivity {
    private String BASE_URL= "https://luisianawaterworks.com/WaterWorks/Capstone/android/sandiego.php";
    private DrawerLayout drawerLayout;
    private ImageButton buttonDrawerToggle;
    private NavigationView navigationView;
    private RecyclerView recyclerView;
    private SanDiegoAdapter adapter;
    private List<SanDiego> sanDiegoList = new ArrayList<>();
    private SearchView searchView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adding);

        drawerLayout = findViewById(R.id.drawerLayout);
        buttonDrawerToggle = findViewById(R.id.buttonDrawerToggle);
        navigationView = findViewById(R.id.navigationView);

        // Initialize RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new SanDiegoAdapter(this, sanDiegoList);
        recyclerView.setAdapter(adapter);

        // Initialize SearchView correctly
        searchView = findViewById(R.id.search_view);
        // Set a Spannable for the query hint to adjust text size
        SpannableString hint = new SpannableString("Meter No: (Example:0###)");
        hint.setSpan(new AbsoluteSizeSpan(14, true), 0, hint.length(), Spannable.SPAN_INCLUSIVE_INCLUSIVE); // Adjust size (14sp here)

        searchView.setQueryHint(hint);
        // Set up search listener
        setupSearchListener(searchView);

        fetchDataFromServer(null); // Fetch all data initially

        // Set click listener for drawer toggle button
        buttonDrawerToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.open();
            }
        });

        // Set item selected listener for navigation view
        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.navHome) {
                    startActivity(new Intent(Reading.this, Success.class));
                } else if (itemId == R.id.navProfile) {
                    startActivity(new Intent(Reading.this, Profile.class));
                }else if (itemId == R.id.navReading) {
                    // Handle navigation item click for Reading
                    startActivity(new Intent(Reading.this, Reading.class));
                } else if (itemId == R.id.navLogout) {
                    logout();
                }
                drawerLayout.close();
                return true;
            }
        });
        SwipeRefreshLayout swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                // Add the logic to refresh your RecyclerView data here

                // Simulate a network call or data update (use your actual data refresh logic)
                refreshRecyclerViewData();

                // Once the refresh is complete, stop the refreshing animation
                swipeRefreshLayout.setRefreshing(false);
            }
        });
    }
    private void refreshRecyclerViewData() {
        fetchDataFromServer("");
    }
    private void setupSearchListener(SearchView searchView) {
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                fetchDataFromServer(query);
                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                if (newText.isEmpty()) {
                    fetchDataFromServer(null);
                }
                return true;
            }
        });
    }

    private void fetchDataFromServer(String query) {
        String url = BASE_URL;
        if (query != null && !query.isEmpty()) {
            // Check if the query matches the expected formats
            if (!query.matches("\\d{4}")) {
                // Show error toast and return
                Toast.makeText(Reading.this, "Invalid meter number format", Toast.LENGTH_SHORT).show();
                return;
            }

            // Adjust URL with encoded meter number parameter
            url += "?meter_number=" + Uri.encode(query);
        }

        // Create JSON request
        JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONArray>() {
                    @Override
                    public void onResponse(JSONArray response) {
                        Log.d("Server Response", response.toString());
                        if (response.length() > 0) {
                            // Records found handling
                            parseJsonResponse(response);
                            recyclerView.setVisibility(View.VISIBLE);
                            Toast.makeText(Reading.this, "Consumers list loaded successfully!", Toast.LENGTH_SHORT).show();
                        } else {
                            // No records found handling
                            recyclerView.setVisibility(View.GONE);
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = ""; // Initialize message as blank

                        // Handle specific VolleyError instances
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "No records found for this meter number"; // Fallback for any other error types
                        }

                        // Display Toast message based on the error response
                        Toast.makeText(Reading.this, message, Toast.LENGTH_SHORT).show();
                        recyclerView.setVisibility(View.GONE);
                    }
                });

        // Add request to request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(jsonArrayRequest);
    }




    // Method to parse JSON response
    private void parseJsonResponse(JSONArray jsonArray) {
        try {
            sanDiegoList.clear();
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                SanDiego reading = new SanDiego(
                        jsonObject.getString("r_id"),
                        jsonObject.getString("firstname"),
                        jsonObject.getString("lastname"),
                        jsonObject.getString("suffix"),
                        jsonObject.getString("email"),
                        jsonObject.getString("type_of_connection"),
                        jsonObject.getString("meter_number"),
                        jsonObject.getString("barangay"),
                        jsonObject.getString("contact")
                );
                sanDiegoList.add(reading);
                // Log each JSON object
            }
            adapter.notifyDataSetChanged();
            if (sanDiegoList.isEmpty()) {
                recyclerView.setVisibility(View.GONE);
            } else {
                recyclerView.setVisibility(View.VISIBLE);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(Reading.this, "Error parsing JSON", Toast.LENGTH_SHORT).show();
            recyclerView.setVisibility(View.GONE);
        }
    }


    private void logout() {
        // Create a confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Call PHP script for logout
                callLogoutPhp();
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Do nothing, simply dismiss the dialog
                dialogInterface.dismiss();
            }
        });
        // Display the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void callLogoutPhp() { String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/offline_android.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle response from PHP script
                        if (response.trim().equals("success")) {
                            // Handle success (user logged out successfully)
                            // Clear user session data from SharedPreferences
                            clearSessionData();
                            Toast.makeText(Reading.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

                            // Redirect to MainActivity
                            Intent intent = new Intent(Reading.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear the back stack
                            startActivity(intent);
                            finish(); // Finish the current activity to prevent returning to it by pressing the back button
                        } else if (response.trim().equals("failure")) {
                            // Handle failure (logout failed)
                            Toast.makeText(Reading.this, "Logout failed. Please try again.", Toast.LENGTH_SHORT).show();
                        } else {
                            // Handle other cases (invalid request or unexpected response)
                            Toast.makeText(Reading.this, "Unexpected response from server", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                String message = ""; // Initialize message as blank

                // Handle specific VolleyError instances
                if (error instanceof TimeoutError) {
                    message = "Request timed out";
                } else if (error instanceof NoConnectionError) {
                    message = "No internet connection";
                } else if (error instanceof ServerError) {
                    message = "Server error";
                } else if (error instanceof NetworkError) {
                    message = "Network error";
                } else {
                    message = "Logout failed. Please try again."; // Fallback for any other error types
                }

                // Display Toast message based on the error response
                Toast.makeText(Reading.this, message, Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Pass user ID instead of username and password
                Map<String, String> data = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
                int userId = sharedPreferences.getInt("readers_id", -1); // -1 or any default value if not found
                data.put("user_id", String.valueOf(userId));
                return data;
            }
        };

// Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void clearSessionData() {
        // Clear user session data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
    }

}

