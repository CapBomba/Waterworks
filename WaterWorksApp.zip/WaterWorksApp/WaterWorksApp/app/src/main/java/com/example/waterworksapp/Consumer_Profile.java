package com.example.waterworksapp;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.text.Html;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.google.android.material.navigation.NavigationView;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class Consumer_Profile extends AppCompatActivity {
    private DrawerLayout drawerLayout;
    // Declare TextViews
    private TextView textViewProfilePage;
    private AlertDialog profileDialog;
    private TextView textViewFirstname;
    private TextView textViewLastname;
    private TextView textViewSuffix;
    private TextView textViewUsername;
    private TextView textViewEmail;
    private TextView textViewMeter;
    private TextView textViewTypeofConnect;
    private TextView textViewContact;
    private TextView textViewbarangay;
    private Button update_profile;
    private boolean hasError = false;
    private EditText dialogEmail,dialogContact,dialogOTP, dialogUsername; // Declare globally if you need it across methods
    private TextView error_email, error_contact, error_otp, error_username, error_otp_timer;
    private String otp,otp_email;
    private Button updateButton,button_otp;
    private String URL = "https://luisianawaterworks.com/WaterWorks/Capstone/android/update_profile_consumers.php";


    private static final String PREFS_NAME = "user_sessions";
    private static final String KEY_OTP = "otp";
    private static final String KEY_OTP_EMAIL = "otp_email";
    private static final String KEY_OTP_EXPIRATION = "otp_expiration";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consumer_profile);

        drawerLayout = findViewById(R.id.drawerLayout);
        NavigationView navigationView = findViewById(R.id.navigationView);

        // Initialize TextViews
        textViewProfilePage = findViewById(R.id.textViewProfilePage);
        textViewFirstname = findViewById(R.id.textViewFirstname);
        textViewLastname = findViewById(R.id.textViewLastname);
        textViewSuffix = findViewById(R.id.textViewSuffix);
        textViewUsername = findViewById(R.id.textViewUsername);
        textViewEmail = findViewById(R.id.textViewEmail);
        textViewMeter = findViewById(R.id.textViewMeter);
        textViewTypeofConnect = findViewById(R.id.textViewtypeofConnect);
        textViewContact = findViewById(R.id.textViewContact);
        textViewbarangay = findViewById(R.id.textViewbarangay);
        update_profile = findViewById(R.id.update_profile);

        Intent intent = getIntent();
        if (intent != null) {
            // Retrieve user information from SharedPreferences
            SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
            String username = sharedPreferences.getString("username", "");
            String userFirstname = sharedPreferences.getString("firstname", "");
            String userLastname = sharedPreferences.getString("lastname", "");
            String suffix = sharedPreferences.getString("suffix", "");
            String contact = sharedPreferences.getString("contact", "");
            String barangay = sharedPreferences.getString("barangay", "");
            String email = sharedPreferences.getString("email", "");
            String meter_number = sharedPreferences.getString("meter_number", "");
            String type_of_connection = sharedPreferences.getString("type_of_connection", "");
            int r_id = sharedPreferences.getInt("r_id", 0);

            String bold = "<b>";
            String endBold = "</b>";
            String indent = "<br>";

            textViewUsername.setText(Html.fromHtml(bold + "Username" + endBold + indent + username));
            textViewFirstname.setText(Html.fromHtml(bold + "First Name" + endBold + indent + userFirstname));
            textViewLastname.setText(Html.fromHtml(bold + "Last Name" + endBold + indent + userLastname));
            textViewSuffix.setText(Html.fromHtml(bold + "Suffix" + endBold + indent + suffix));
            textViewContact.setText(Html.fromHtml(bold + "Contact" + endBold + indent + contact));
            textViewEmail.setText(Html.fromHtml(bold + "Email" + endBold + indent + email));
            textViewMeter.setText(Html.fromHtml(bold + "Meter Number" + endBold + indent + meter_number));
            textViewTypeofConnect.setText(Html.fromHtml(bold + "Type of Connection" + endBold + indent + type_of_connection));
            textViewbarangay.setText(Html.fromHtml(bold + "Barangay" + endBold + indent + barangay));
        } else {
            // Handle the case where intent is null
            Toast.makeText(this, "Intent is null", Toast.LENGTH_SHORT).show();
        }

        findViewById(R.id.buttonDrawerToggle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerOpen(navigationView)) {
                    drawerLayout.closeDrawer(navigationView);
                } else {
                    drawerLayout.openDrawer(navigationView);
                }
            }
        });
        update_profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                check_change_pass_limit();
            }
        });

        navigationView.setNavigationItemSelectedListener(new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem item) {
                int itemId = item.getItemId();
                if (itemId == R.id.navHome) {
                    // Handle navigation item click for Home
                    startActivity(new Intent(Consumer_Profile.this, ConsumerHome.class));
                } else if (itemId == R.id.navProfile) {
                    // Handle navigation item click for Profile
                    startActivity(new Intent(Consumer_Profile.this, Consumer_Profile.class));
                } else if (itemId == R.id.navHistory) {
                    // Handle navigation item click for History
                    startActivity(new Intent(Consumer_Profile.this, Report_Problem.class));
                } else if (itemId == R.id.navViolation) {
                    // Handle navigation item click for History
                    startActivity(new Intent(Consumer_Profile.this, Consumer_Violation.class));
                }   else if (itemId == R.id.navLogout) {
                    // Handle navigation item click for Logout
                    logout();
                }
                drawerLayout.closeDrawer(navigationView);
                return true;
            }
        });
    }
    private void check_change_pass_limit() {
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/check_change_pass_limit_consumer.php";

        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            // Parse the JSON response
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.getString("status");

                            if (status.equals("success")) {
                                // Extract user data from JSON response
                                String change_pass = jsonResponse.getString("change_pass");
                                Log.d("Date", "Date Value: " + change_pass);

                                // Parse change_pass to Date
                                SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                                Date changePassDate = dateFormat.parse(change_pass);

                                // Get current date
                                Calendar currentCal = Calendar.getInstance();

                                // Compare dates
                                if (changePassDate != null) {
                                    Calendar changePassCal = Calendar.getInstance();
                                    changePassCal.setTime(changePassDate);

                                    if (changePassCal.getTimeInMillis() <= currentCal.getTimeInMillis()) {
                                        Log.d("DateComparison", "change_pass is today or a future date.");
                                        // Proceed with updating profile
                                        Update_Profile();
                                    } else {

                                        long diffInMillis = changePassCal.getTimeInMillis() - currentCal.getTimeInMillis();
                                        long remainingDays = TimeUnit.MILLISECONDS.toDays(diffInMillis);
                                        if (remainingDays == 0) {
                                            long remainingHours = TimeUnit.MILLISECONDS.toHours(diffInMillis) % 24;
                                            if (remainingHours > 0) {
                                                Toast.makeText(Consumer_Profile.this, "You can update your information in " + remainingHours + " hours.", Toast.LENGTH_SHORT).show();
                                            }
                                        } else if (remainingDays == 1){
                                            Toast.makeText(Consumer_Profile.this, "You can update your information tomorrow.", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Toast.makeText(Consumer_Profile.this, "You can update your information in " + remainingDays + " days.", Toast.LENGTH_SHORT).show();
                                        }
                                    }

                                } else {
                                    Log.d("DateComparison", "changePassDate is null.");
                                }
                            } else if (status.equals("error")) {
                                // Handle failure (error in fetching data)
                                Toast.makeText(Consumer_Profile.this, "Unexpected error occurred! Please try again later" , Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                            Toast.makeText(Consumer_Profile.this, "Unexpected error occurred! Please try again later", Toast.LENGTH_SHORT).show();
                        } catch (ParseException e) {
                            e.printStackTrace();
                            Toast.makeText(Consumer_Profile.this, "Unexpected error occurred! Please try again later", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                String message = ""; // Initialize message as blank

                // Handle specific VolleyError instances
                if (error instanceof TimeoutError) {
                    message = "Request timed out";
                } else if (error instanceof NoConnectionError) {
                    message = "No internet connection";
                } else if (error instanceof ServerError) {
                    message = "Server error";
                } else if (error instanceof NetworkError) {
                    message = "Network error";
                } else {
                    message = "Request failed. Please try again."; // Fallback for any other error types
                }

                // Display Toast message based on the error response
                Toast.makeText(Consumer_Profile.this, message, Toast.LENGTH_SHORT).show();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Pass user ID instead of username and password
                Map<String, String> data = new HashMap<>();
                SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
                int userId = sharedPreferences.getInt("r_id", -1); // -1 or any default value if not found
                data.put("user_id", String.valueOf(userId));
                return data;
            }
        };

        // Add the request to the RequestQueue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }
    private void Update_Profile() {
        String bold = "<b>";
        String endBold = "</b>";
        String indent = "<br>";

        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        String username = sharedPreferences.getString("username", "");
        String firstname = sharedPreferences.getString("firstname", "");
        String lastname = sharedPreferences.getString("lastname", "");
        String suffix = sharedPreferences.getString("suffix", "");
        String contact = sharedPreferences.getString("contact", "");
        String email = sharedPreferences.getString("email", "");

        // Create a builder to show user details
        AlertDialog.Builder builder = new AlertDialog.Builder(Consumer_Profile.this);
        builder.setTitle("Consumer Profile Details");

        // Inflate the layout with user details
        View customLayout = getLayoutInflater().inflate(R.layout.update_profile_consumer_inflater, null);
        builder.setView(customLayout);

        // Populate the layout with user details
        TextView dialogFirstname = customLayout.findViewById(R.id.dialogFirstname);
        TextView dialogLastname = customLayout.findViewById(R.id.dialogLastname);
        TextView dialogSuffix = customLayout.findViewById(R.id.dialogSuffix);
         dialogUsername = customLayout.findViewById(R.id.dialogUsername);
         dialogContact = customLayout.findViewById(R.id.dialogContact);
         dialogEmail = customLayout.findViewById(R.id.dialogEmail);
         dialogOTP = customLayout.findViewById(R.id.dialogOTP);

         error_email = customLayout.findViewById(R.id.error_email);
         error_contact = customLayout.findViewById(R.id.error_contact);
         error_otp = customLayout.findViewById(R.id.error_otp);
         error_username = customLayout.findViewById(R.id.error_username);
         error_otp_timer = customLayout.findViewById(R.id.error_otp_timer);

         updateButton = customLayout.findViewById(R.id.update);
         button_otp = customLayout.findViewById(R.id.otp);

        // Set text in dialog fields
        dialogFirstname.setText(Html.fromHtml(bold + "Firstname " + indent + endBold + firstname + indent));
        dialogLastname.setText(Html.fromHtml(bold + "Lastname " + indent + endBold + lastname + indent));
        dialogSuffix.setText(Html.fromHtml(bold + "Suffix " + indent + endBold + suffix + indent));
        dialogContact.setText(Html.fromHtml(bold + indent + endBold + contact ));
        dialogEmail.setText(Html.fromHtml(bold + endBold + email ));

        // Delay clearing the text fields after 5 seconds
        new Handler().postDelayed(() -> {
            dialogContact.setText("");
            dialogEmail.setText("");
        }, 1000); // 1000 milliseconds = 1 second

        // Set up the buttons
        updateButton.setOnClickListener(v -> {
            // Retrieve updated values from EditText fields
            String contact_update = dialogContact.getText().toString().trim();
            String email_update = dialogEmail.getText().toString().trim();
            String username_update = dialogUsername.getText().toString().trim();
            String otp = dialogOTP.getText().toString().trim();

            // Call a function to initiate the update process
            performUpdate(otp, contact_update, email_update, username_update);
        });

        button_otp.setOnClickListener(v -> SendingOTP());

        // Delay clearing the text fields after 5 seconds
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Clear the text fields
                dialogContact.setText("");
                dialogEmail.setText("");
            }
        }, 1000); // 1000 milliseconds = 1 second

        // Set up the dialog properties to make it non-cancellable and disable back press
        builder.setCancelable(false); // Disable back press and close button

        // Create and show the dialog, storing the reference
        profileDialog = builder.create();
        profileDialog.show();

    }

    private void SendingOTP() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String storedEmail = sharedPreferences.getString("email", "");
        hasError = false;
        String get_email = dialogEmail.getText().toString().trim();
        boolean isValidEmail = isValidEmail(get_email);

        if (get_email.isEmpty()) {
            error_email.setVisibility(View.VISIBLE);
            error_email.setText("Email cannot be empty.");
            return; // Stop execution here
        } else if (!isValidEmail) {
            error_email.setVisibility(View.VISIBLE);
            error_email.setText("Invalid email address.");
            return; // Stop execution here
        } else if (storedEmail.equals(get_email)) {
            // Display an error message
            error_email.setVisibility(View.VISIBLE);
            error_email.setText("You cannot use the previous email address.");
            return; // Stop execution here
        }

        // Email is valid, hide error message if previously shown
        error_email.setVisibility(View.GONE);

        // Perform OTP sending logic here
        String url = "https://luisianawaterworks.com/WaterWorks/Capstone/android/consumers_profile_update_otp.php";

        // Create a StringRequest to make a POST request to the PHP script
        StringRequest stringRequest = new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonResponse = new JSONObject(response);
                            String status = jsonResponse.optString("status");

                            if ("failure".equalsIgnoreCase(status)) {
                                Toast.makeText(Consumer_Profile.this, "Failed to send OTP", Toast.LENGTH_SHORT).show();
                            } else {
                                otp = jsonResponse.getString("otp");
                                otp_email = jsonResponse.getString("otp_email");
                                long otpExpiration = jsonResponse.getLong("otp_expiration");

                                // Save OTP, email, and expiration time in SharedPreferences
                                SharedPreferences.Editor editor = sharedPreferences.edit();
                                editor.putString(KEY_OTP, otp);
                                editor.putString(KEY_OTP_EMAIL, otp_email);
                                editor.putLong(KEY_OTP_EXPIRATION, otpExpiration);
                                editor.apply();

                                // Calculate time remaining and display
                                long currentTime = System.currentTimeMillis() / 1000;  // Current time in seconds
                                long timeRemaining = otpExpiration - currentTime;  // Time remaining in seconds

                                Log.d("OTP received", "OTP: " + otp);
                                Log.d("OTP email received", "OTP Email: " + otp_email);
                                Log.d("OTP Expiration", "Expires in " + timeRemaining + " seconds");

                                if (timeRemaining > 0) {
                                    // Convert timeRemaining to minutes and seconds
                                    long minutesRemaining = timeRemaining / 60;
                                    long secondsRemaining = timeRemaining % 60;

                                    // Format the time in mm:ss format
                                    String timeFormatted = String.format("%02d:%02d", minutesRemaining, secondsRemaining);

                                    // Show the formatted time in the Toast message
                                    Toast.makeText(Consumer_Profile.this, "OTP will expire in: " + timeFormatted, Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(Consumer_Profile.this, "OTP has expired, please request a new one.", Toast.LENGTH_SHORT).show();
                                }
                                updateButton.setVisibility(View.VISIBLE);
                                loadOtpDetails();
                            }
                        } catch (JSONException e) {
                            // JSON exception
                            e.printStackTrace();
                            Toast.makeText(getApplicationContext(), "Unexpected error while sending otp occurred! Please try again later", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = ""; // Initialize message as blank

                        // Handle specific VolleyError instances
                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "OTP request failed. Please try again."; // Fallback for any other error types
                        }

                        // Display Toast message based on the error response
                        Toast.makeText(Consumer_Profile.this, message, Toast.LENGTH_SHORT).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                // Parameters to send to the PHP script (email in this case)
                Map<String, String> params = new HashMap<>();
                params.put("email", get_email);
                return params;
            }
        };

        // Add request to the request queue
        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void loadOtpDetails() {
        SharedPreferences sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        otp = sharedPreferences.getString(KEY_OTP, null);
        otp_email = sharedPreferences.getString(KEY_OTP_EMAIL, null);
        long otpExpiration = sharedPreferences.getLong(KEY_OTP_EXPIRATION, 0);
        long currentTime = System.currentTimeMillis() / 1000; // Current time in seconds

        // Ensure the TextView is visible
        error_otp_timer.setVisibility(View.VISIBLE);

        // Disable the OTP button initially
        button_otp.setEnabled(false);

        if (otp != null && otpExpiration > currentTime) {
            long timeRemaining = otpExpiration - currentTime;

            // Set up a CountDownTimer to display the remaining time in the TextView
            new CountDownTimer(timeRemaining * 1000, 1000) {
                public void onTick(long millisUntilFinished) {
                    long secondsRemaining = millisUntilFinished / 1000;
                    long minutes = secondsRemaining / 60;
                    long seconds = secondsRemaining % 60;

                    // Format the time in minutes:seconds format
                    String timeFormatted = String.format("%02d:%02d", minutes, seconds);
                    error_otp_timer.setText("OTP expires in: " + timeFormatted);
                }

                public void onFinish() {
                    // Enable the OTP button after the timer finishes
                    button_otp.setEnabled(true);
                    error_otp_timer.setText("OTP has expired, please request a new one.");
                }
            }.start();
        } else {
            // Enable the OTP button if no valid OTP or expired OTP
            button_otp.setEnabled(true);
            error_otp_timer.setText("No valid OTP found or OTP has expired.");
        }
    }
    private boolean isValidEmail(String email) {
        // Updated pattern to allow any domain
        String emailPattern = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}";

        // Validate email using the regex pattern
        return email.matches(emailPattern);
    }
    // Function to perform the update operation
    private void performUpdate(String Entered_OTP, String contact_update, String email_update, String username_update) {

        hasError = false;
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        String stored_contact = sharedPreferences.getString("contact", "");
        String stored_username = sharedPreferences.getString("username", "");
        int r_id = sharedPreferences.getInt("r_id", 0);
        String r_idString = String.valueOf(r_id);

        Log.d("PerformUpdate", "OTP: " + Entered_OTP);
        Log.d("PerformUpdate", "Contact: " + contact_update);
        Log.d("PerformUpdate", "Email: " + email_update);
        Log.d("PerformUpdate", "Username: " + username_update);

        if (Entered_OTP.isEmpty()) {
            error_otp.setVisibility(View.VISIBLE);
            error_otp.setText("OTP cannot be empty.");
            hasError = true;
        } else if (!Entered_OTP.equals(otp)) { // receivedOTP is the OTP received from sendingOTP() method
            error_otp.setVisibility(View.VISIBLE);
            error_otp.setText("OTP is incorrect/invalid.");
            hasError = true;
        } else {
            error_otp.setVisibility(View.GONE);
        }

        // Validate email
        if (email_update.isEmpty()) {
            error_email.setVisibility(View.VISIBLE);
            error_email.setText("Email cannot be empty.");
            hasError = true;
        } else if (!isValidEmail(email_update)) {
            error_email.setVisibility(View.VISIBLE);
            error_email.setText("Invalid email address.");
            hasError = true;
        } else if (!email_update.equals(otp_email)) {
            error_email.setVisibility(View.VISIBLE);
            error_email.setText("Email does not match the one used for OTP.");
            hasError = true;
        } else {
            // Check if OTP is expired
            long currentTime = System.currentTimeMillis() / 1000;
            SharedPreferences sharedPreferences_timer = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            long otpExpiration = sharedPreferences_timer.getLong(KEY_OTP_EXPIRATION, 0);

            if (otpExpiration < currentTime) {
                error_email.setVisibility(View.VISIBLE);
                error_email.setText("OTP has expired. Please request a new OTP.");
                hasError = true;
            } else {
                // Email and OTP are valid, and OTP has not expired
                error_email.setVisibility(View.GONE);
            }
        }

        // Validate contact
        if (contact_update.isEmpty()) {
            error_contact.setVisibility(View.VISIBLE);
            error_contact.setText("Contact cannot be empty.");
            hasError = true;
        } else if (contact_update.equals(stored_contact)) {
            error_contact.setVisibility(View.VISIBLE);
            error_contact.setText("You cannot use the previous contact number.");
            return;
        } else if (!contact_update.matches("^09\\d{9}$")) {
            error_contact.setVisibility(View.VISIBLE);
            error_contact.setText("Must start with '09' and be 11 digits.");
            return;
        } else {
            error_contact.setVisibility(View.GONE);
        }

        // Validate username
        if (username_update.isEmpty()) {
            error_username.setVisibility(View.VISIBLE);
            error_username.setText("Username cannot be empty.");
            hasError = true;
        } else if (username_update.equals(stored_username)) {
            error_username.setVisibility(View.VISIBLE);
            error_username.setText("You cannot use the previous username.");
            return;
        } else if (!username_update.matches("^[a-zA-Z0-9]{7,20}$")) {
            error_username.setVisibility(View.VISIBLE);
            error_username.setText("Username must be 7-20 characters letters/numbers only.");
            return;
        } else {
            error_username.setVisibility(View.GONE);
        }

        // Check if there are any validation errors
        if (hasError) {
            return;
        }

        StringRequest stringRequest = new StringRequest(Request.Method.POST, URL,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        // Handle the response from the PHP script
                        Log.d("ServerResponse", "Response: " + response);
                        if ("success".equalsIgnoreCase(response)) {
                            Toast.makeText(Consumer_Profile.this, "Profile Updated successfully", Toast.LENGTH_SHORT).show();
                            // Update SharedPreferences with the new values
                            SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
                            SharedPreferences.Editor editor = sharedPreferences.edit();
                            editor.putString("contact", contact_update);
                            editor.putString("email", email_update);
                            editor.putString("username", username_update);
                            // Clear OTP-related data
                            editor.remove(KEY_OTP);
                            editor.remove(KEY_OTP_EMAIL);
                            editor.remove(KEY_OTP_EXPIRATION);
                            editor.apply();
                            clearFields();
                            clearErrors();
                            updateUI();
                            // Dismiss the dialog if it's still showing
                            if (profileDialog != null && profileDialog.isShowing()) {
                                profileDialog.dismiss();
                            }
                        } else if ("failure".equalsIgnoreCase(response)) {
                            Toast.makeText(Consumer_Profile.this, "Update Failed!", Toast.LENGTH_SHORT).show();
                        } else if ("email_exists".equalsIgnoreCase(response)) {
                            Toast.makeText(Consumer_Profile.this, "Email already exists! Please use a different email.", Toast.LENGTH_SHORT).show();
                        } else if ("contact_exists".equalsIgnoreCase(response)) {
                            Toast.makeText(Consumer_Profile.this, "Contact already exists! Please use a different contact number.", Toast.LENGTH_SHORT).show();
                        } else if ("username_exists".equalsIgnoreCase(response)) {
                            Toast.makeText(Consumer_Profile.this, "Username already taken! Please choose a different username.", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(Consumer_Profile.this, "Unexpected error occurred!", Toast.LENGTH_SHORT).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        String message = "";

                        if (error instanceof TimeoutError) {
                            message = "Request timed out";
                        } else if (error instanceof NoConnectionError) {
                            message = "No internet connection";
                        } else if (error instanceof ServerError) {
                            message = "Server error";
                        } else if (error instanceof NetworkError) {
                            message = "Network error";
                        } else {
                            message = "Updating profile failed. Please try again.";
                        }

                        Toast.makeText(Consumer_Profile.this, message, Toast.LENGTH_SHORT).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                // Add parameters to the request
                Map<String, String> params = new HashMap<>();
                params.put("contact_update", contact_update);
                params.put("email_update", email_update);
                params.put("r_idString", r_idString);
                params.put("username_update", username_update);

                // Log parameters
                Log.d("RequestParams", "contact_update: " + contact_update);
                Log.d("RequestParams", "email_update: " + email_update);
                Log.d("RequestParams", "r_idString: " + r_idString);
                Log.d("RequestParams", "username_update: " + username_update);

                return params;
            }
        };

        RequestQueue requestQueue = Volley.newRequestQueue(getApplicationContext());
        requestQueue.add(stringRequest);
    }

    private void logout() {
        // Create a confirmation dialog
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Logout");
        builder.setMessage("Are you sure you want to logout?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Call PHP script for logout
                clearSessionData();
                Toast.makeText(Consumer_Profile.this, "Logged out successfully", Toast.LENGTH_SHORT).show();

                // Redirect to MainActivity
                Intent intent = new Intent(Consumer_Profile.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Clear the back stack
                startActivity(intent);
                finish(); // Finish the current activity to prevent returning to it by pressing the back button
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Do nothing, simply dismiss the dialog
                dialogInterface.dismiss();
            }
        });

        // Display the dialog
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void clearSessionData() {
        // Clear user session data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("isLoggedIn", false);
        editor.clear();
        editor.apply();
    }

    private void saveUserData() {
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        // Save the user data to SharedPreferences
        editor.putString("username", textViewUsername.getText().toString());
        editor.putString("firstname", textViewFirstname.getText().toString());
        editor.putString("lastname", textViewLastname.getText().toString());
        editor.putString("suffix", textViewSuffix.getText().toString());
        editor.putString("contact", textViewContact.getText().toString());
        editor.putString("barangay", textViewbarangay.getText().toString());
        editor.putString("email", textViewEmail.getText().toString());
        editor.putString("meter_number", textViewMeter.getText().toString());
        editor.putString("type_of_connection", textViewTypeofConnect.getText().toString());
        editor.apply();
    }

    private void clearFields() {
        dialogOTP.setText("");
        dialogContact.setText("");
        dialogEmail.setText("");
        dialogUsername.setText("");
    }
    private void clearErrors() {
        error_email.setVisibility(View.GONE);
        error_otp.setVisibility(View.GONE);
        error_contact.setVisibility(View.GONE);
    }
    private void updateUI() {
        // Retrieve the updated values from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_sessions", MODE_PRIVATE);
        String updatedContact = sharedPreferences.getString("contact", "");
        String updatedEmail = sharedPreferences.getString("email", "");
        String updatedUsername = sharedPreferences.getString("username", "");

        // HTML formatting for bold text and line breaks
        String bold = "<b>";
        String endBold = "</b>";
        String indent = "<br>";

        // Update the UI elements with the new values using HTML formatting
        textViewContact.setText(Html.fromHtml(bold + "Contact" + endBold + indent + updatedContact));
        textViewEmail.setText(Html.fromHtml(bold + "Email" + endBold + indent + updatedEmail));
        textViewUsername.setText(Html.fromHtml(bold + "Username" + endBold + indent + updatedUsername));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        // Save user data before the activity is destroyed
        saveUserData();
    }
}