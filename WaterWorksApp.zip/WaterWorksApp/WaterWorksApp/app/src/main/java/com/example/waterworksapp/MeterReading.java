package com.example.waterworksapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;

import android.os.Bundle;
import android.text.Html;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.view.View;

import com.android.volley.NetworkError;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.ServerError;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;



public class MeterReading extends AppCompatActivity {
    private String URL = "https://luisianawaterworks.com/WaterWorks/Capstone/android/meter_android_reading.php";
    private EditText editTextPresentReading, editTextPastReading;
    private Button submitmeter;

    private TextView errorPastTextView,
            textViewStatus, textViewDate, textViewMeterNumber,
            textViewTypeOfConnection, textViewContact, textViewFullName, textViewReaderFullName;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_meter_reading);

        // Initialize views
        editTextPastReading = findViewById(R.id.editTextPastReading);
        editTextPresentReading = findViewById(R.id.editTextPresentReading);
        submitmeter = findViewById(R.id.submitmeter);
        errorPastTextView = findViewById(R.id.errorPastTextView);


        textViewReaderFullName = findViewById(R.id.textViewReaderFullName);
        textViewFullName = findViewById(R.id.textViewFullName);
        textViewContact = findViewById(R.id.textViewContact);
        textViewTypeOfConnection = findViewById(R.id.textViewTypeOfConnection);
        textViewMeterNumber = findViewById(R.id.textViewMeterNumber);
        textViewStatus = findViewById(R.id.textViewStatus);
        textViewDate = findViewById(R.id.textViewDate);

        ImageView backImageView = findViewById(R.id.backImageView);
        backImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed(); // Simulate pressing the back button
            }
        });

        String bold = "<b>";
        String endBold = "</b>";
        String indent = "<br>"; // HTML entity for space repeated for indentation

        // Retrieve data from SharedPreferences
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        String firstname = sharedPreferences.getString("firstname", "");
        String lastname = sharedPreferences.getString("lastname", "");
        textViewReaderFullName.setText(Html.fromHtml(bold + "Reader Fullname" + endBold + indent + firstname + " " + lastname));

        // Retrieve data from Intent
        Intent intent = getIntent();
        // From meter_reading table
        String past = intent.getStringExtra("present");
        String status = intent.getStringExtra("status");
        String date = intent.getStringExtra("date");


        // From reading table
        String r_id = intent.getStringExtra("r_id");

        // Retrieve data from the reading table
        String fname = intent.getStringExtra("fname");
        String lname = intent.getStringExtra("lname");
        String suffix = intent.getStringExtra("suffix");
        String email = intent.getStringExtra("contact");
        String type_of_connection = intent.getStringExtra("type_of_connection");
        String meter_number = intent.getStringExtra("meter_number");




        // Setting Consumer (Full Name)
        textViewFullName.setText(Html.fromHtml(bold + "Consumer" + endBold + indent + fname + " " + lname + " " + suffix));

        // Setting Email
        textViewContact.setText(Html.fromHtml(bold + "Email" + endBold + indent + email));

        // Setting Connection Type
        textViewTypeOfConnection.setText(Html.fromHtml(bold + "Connection Type" + endBold + indent + type_of_connection));

        // Setting Meter Number
        textViewMeterNumber.setText(Html.fromHtml(bold + "Meter Number" + endBold + indent + meter_number));

        // Setting Past Reading to EditText
        editTextPastReading.setText(Html.fromHtml(bold + endBold + indent + past));

        // Setting Status
        textViewStatus.setText(Html.fromHtml(bold + "Status" + endBold + indent + status));

        // Setting Date
        textViewDate.setText(Html.fromHtml(bold + "Date" + endBold + indent + date));

        // Set up OnClickListener for the submit button
        submitmeter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitMeterReading();
            }
        });
    }

    private void submitMeterReading() {
        //Readers
        SharedPreferences sharedPreferences = getSharedPreferences("user_session", MODE_PRIVATE);
        String readers_firstname = sharedPreferences.getString("firstname", "");
        String readers_lastname = sharedPreferences.getString("lastname", "");


        Intent intent = getIntent();
        String r_id = intent.getStringExtra("r_id");
        String type_of_connection = intent.getStringExtra("type_of_connection");
        String con_firstname = intent.getStringExtra("fname");
        String con_lastname = intent.getStringExtra("lname");
        String suffix = intent.getStringExtra("suffix");
        String email = intent.getStringExtra("contact");
        String pastReading = editTextPastReading.getText().toString().trim();
        String presentReading = editTextPresentReading.getText().toString().trim();
        String barangay = intent.getStringExtra("barangay");

        errorPastTextView.setVisibility(View.VISIBLE);
        errorPastTextView.setVisibility(View.VISIBLE);

        boolean hasError = false;
        boolean proceedWithOperation = false; // Introduce the variable to track the status of readings comparison

        if (pastReading.isEmpty()) {
            errorPastTextView.setText("Please enter previous reading");
            errorPastTextView.setVisibility(View.VISIBLE);
            hasError = true;
        } else {
            errorPastTextView.setVisibility(View.GONE);
        }


        if (!pastReading.isEmpty() && !presentReading.isEmpty()) {
                // Perform your calculations or proceed when past and present readings are equal or present is greater than past
                proceedWithOperation = true; // Set the flag to true indicating that it's safe to proceed
        }

        String status = intent.getStringExtra("status");



        if (status != null && status.equalsIgnoreCase("unpaid")) {
            if (!pastReading.isEmpty() && !presentReading.isEmpty()) {
                int past = Integer.parseInt(pastReading);
                int present = Integer.parseInt(presentReading);

                if (present < past) {
                    errorPastTextView.setText("New reading must be greater than previous reading");
                    errorPastTextView.setVisibility(View.VISIBLE);
                    hasError = true;
                } else {
                    // Perform your calculations or proceed when past and present readings are equal or present is greater than past
                    proceedWithOperation = true; // Set the flag to true indicating that it's safe to proceed
                }
                // Perform your calculations or proceed when past and present readings are equal or present is greater than past
                proceedWithOperation = true; // Set the flag to true indicating that it's safe to proceed
            } else {
                // Handle if either past or present reading is empty
                errorPastTextView.setText("New reading is empty");
                errorPastTextView.setVisibility(View.VISIBLE);
                return; // Return from the method if either past or present reading is empty
            }
        }

        // Check if status is "paid"
        if (status != null && status.equalsIgnoreCase("paid")) {
            // Check if present reading is greater than past reading
            if (!pastReading.isEmpty() && !presentReading.isEmpty()) {
                int past = Integer.parseInt(pastReading);
                int present = Integer.parseInt(presentReading);

                if (present < past) {
                    errorPastTextView.setText("New reading must be greater than previous reading");
                    errorPastTextView.setVisibility(View.VISIBLE);
                    hasError = true;
                } else {
                    // Perform your calculations or proceed when past and present readings are equal or present is greater than past
                    proceedWithOperation = true; // Set the flag to true indicating that it's safe to proceed
                }
                    // Perform your calculations or proceed when past and present readings are equal or present is greater than past
                    proceedWithOperation = true; // Set the flag to true indicating that it's safe to proceed
            } else {
                // Handle if either past or present reading is empty
                errorPastTextView.setText("New reading is empty");
                errorPastTextView.setVisibility(View.VISIBLE);
                return; // Return from the method if either past or present reading is empty
            }
        }

        // Check if status is "new" comment
        /*if (status != null && status.equalsIgnoreCase("new")) {
            // Add your condition here for the "new" status
            // For example, if present reading is empty, display an error message
            if (presentReading.isEmpty()) {
                errorPresentTextView.setText("Present reading is empty.");
                errorPresentTextView.setVisibility(View.VISIBLE);
                return; // Return from the method if status is new and present reading is empty
            } else if (!pastReading.isEmpty() && !presentReading.isEmpty()) {
                int past = Integer.parseInt(pastReading);
                int present = Integer.parseInt(presentReading);

                if (present <= past) {
                    errorPresentTextView.setText("Present reading must be greater than past reading");
                    errorPresentTextView.setVisibility(View.VISIBLE);
                    return; // Return from the method if present reading is not greater than past reading
                } else {
                    // Perform your calculations or proceed when past and present readings are equal or present is greater than past
                    proceedWithOperation = true; // Set the flag to true indicating that it's safe to proceed
                }
            }
        } else {
            // Hide the error message
            errorPresentTextView.setVisibility(View.GONE);
        }*/

        if (hasError) {
            return;
        }


        String residential = "Residential";
        String commercial = "Commercial";
        String water_refilling = "Water Refilling Station";
        String result = "";
        String resultValueString = "";


        int past = Integer.parseInt(pastReading);
        int present = Integer.parseInt(presentReading);
        int resultValue = present - past; // Calculate the result
        double rate = 0;
        resultValueString = String.valueOf(resultValue);
        rate = 0;
        if (proceedWithOperation) {
            if (type_of_connection.equals(residential)) {

                if (resultValue <= 10) {
                    rate = 120.00;
                } else if (resultValue <= 20) {
                    rate = 120.00 + (resultValue - 10) * 14.00;
                } else if (resultValue == 21) {
                    rate = 276.00;
                } else if (resultValue > 21) {
                    // Cubic meters above 21
                    rate = 276.00;
                    for (int i = 22; i <= resultValue; i++) {
                        rate += 16.00;
                    }
                }
                if (resultValue == 31) {
                    rate = 438.00;
                } else if (resultValue > 31) {
                    rate = 438.00;
                    for (int i = 32; i <= resultValue; i++) {
                        rate += 18.00;
                    }
                }
                if (resultValue == 41) {
                    rate = 620.00;
                } else if (resultValue > 41) {
                    rate = 620.00;
                    for (int i = 42; i <= resultValue; i++) {
                        rate += 20.00;
                    }
                }
                if (resultValue == 51) {
                    rate = 822.00;
                } else if (resultValue > 51) {
                    rate = 822.00;
                    for (int i = 52; i <= resultValue; i++) {
                        rate += 22.00;
                    }
                }
                if (resultValue == 61) {
                    rate = 1042.00;
                } else if (resultValue > 61) {

                    rate = 1042.00;
                    for (int i = 62; i <= resultValue; i++) {
                        rate += 22.00;
                    }
                }
                if (resultValue == 71) {
                    rate = 1262.00;
                } else if (resultValue > 71) {

                    rate = 1262.00;
                    for (int i = 72; i <= resultValue; i++) {
                        rate += 22.00;
                    }
                }
                if (resultValue == 81) {
                    rate = 1482.00;
                } else if (resultValue > 81) {

                    rate = 1482.00;
                    for (int i = 82; i <= resultValue; i++) {
                        rate += 22.00;
                    }
                }
                if (resultValue == 91) {
                    rate = 1702.00;
                } else if (resultValue > 91) {

                    rate = 1702.00;
                    for (int i = 92; i <= resultValue; i++) {
                        rate += 22.00;
                    }
                }
                if (resultValue > 100) {
                    rate = 1702.00;
                    for (int i = 101; i <= resultValue; i++) {
                        rate += 40.00;
                    }
                }
                // Log the calculated rate
                Log.d("Rate", "Calculated rate for residential: " + rate);

                // Log the difference between present and past readings
                Log.d("Difference", "Difference between present and past readings: " + resultValue);
            } else if (type_of_connection.equals(commercial)) {
                if (resultValue <= 10) {
                    rate = 180.00;
                } else if (resultValue <= 20) {
                    rate = 180.00 + (resultValue - 10) * 20.00;
                } else if (resultValue == 21) {
                    rate = 402.00;
                } else if (resultValue > 21) {
                    // Cubic meters above 21
                    rate = 402.00;
                    for (int i = 22; i <= resultValue; i++) {
                        rate += 22.00;
                    }
                }
                if (resultValue == 31) {
                    rate = 624.00;
                } else if (resultValue > 31) {
                    rate = 624.00;
                    for (int i = 32; i <= resultValue; i++) {
                        rate += 24.00;
                    }
                }
                if (resultValue == 41) {
                    rate = 866.00;
                } else if (resultValue > 41) {
                    rate = 866.00;
                    for (int i = 42; i <= resultValue; i++) {
                        rate += 26.00;
                    }
                }
                if (resultValue == 51) {
                    rate = 1128.00;
                } else if (resultValue > 51) {
                    rate = 1128.00;
                    for (int i = 52; i <= resultValue; i++) {
                        rate += 28.00;
                    }
                }
                if (resultValue == 61) {
                    rate = 1408.00;
                } else if (resultValue > 61) {

                    rate = 1408.00;
                    for (int i = 62; i <= resultValue; i++) {
                        rate += 28.00;
                    }
                }
                if (resultValue == 71) {
                    rate = 1688.00;
                } else if (resultValue > 71) {

                    rate = 1688.00;
                    for (int i = 72; i <= resultValue; i++) {
                        rate += 28.00;
                    }
                }
                if (resultValue == 81) {
                    rate = 1968.00;
                } else if (resultValue > 81) {

                    rate = 1968.00;
                    for (int i = 82; i <= resultValue; i++) {
                        rate += 28.00;
                    }
                }
                if (resultValue == 91) {
                    rate = 2248.00;
                } else if (resultValue > 91) {

                    rate = 2248.00;
                    for (int i = 92; i <= resultValue; i++) {
                        rate += 28.00;
                    }
                }
                if (resultValue > 100) {
                    rate = 2248.00;
                    for (int i = 101; i <= resultValue; i++) {
                        rate += 40.00;
                    }
                }
                Log.d("Rate", "Calculated rate for commercial: " + rate);
            }else if (type_of_connection.equals(water_refilling)) {
                if (resultValue <= 10) {
                    rate = 300.00;
                } else if (resultValue <= 20) {
                    rate = 300.00 + (resultValue - 10) * 32.00;
                } else if (resultValue == 21) {
                    rate = 654.00;
                } else if (resultValue > 21) {
                    // Cubic meters above 21
                    rate = 654.00;
                    for (int i = 22; i <= resultValue; i++) {
                        rate += 34.00;
                    }
                }
                if (resultValue == 31) {
                    rate = 996.00;
                } else if (resultValue > 31) {
                    rate = 996.00;
                    for (int i = 32; i <= resultValue; i++) {
                        rate += 36.00;
                    }
                }
                if (resultValue == 41) {
                    rate = 1358.00;
                } else if (resultValue > 41) {
                    rate = 1358.00;
                    for (int i = 42; i <= resultValue; i++) {
                        rate += 38.00;
                    }
                }
                if (resultValue == 51) {
                    rate = 1740.00;
                } else if (resultValue > 51) {
                    rate = 1740.00;
                    for (int i = 52; i <= resultValue; i++) {
                        rate += 40.00;
                    }
                }
                if (resultValue > 60) {
                    rate = 2100.00;
                    for (int i = 52; i <= resultValue; i++) {
                        rate += 40.00;
                    }
                }
                Log.d("Rate", "Calculated rate for water refilling: " + rate);
            }

            String finalResultValueString = resultValueString;
            double finalRate = rate;
            StringRequest stringRequest = new StringRequest(Request.Method.POST, URL, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        // Parse the JSON response
                        JSONObject jsonResponse = new JSONObject(response);
                        String status = jsonResponse.getString("status");

                        // Handle the response based on status
                        if ("success".equalsIgnoreCase(status)) {

                            // Success response, start the next activity
                            Toast.makeText(MeterReading.this, "Meter Reading Bill sent to: "  + email , Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(MeterReading.this, Reading.class);
                            startActivity(intent);
                            finish();
                        } else if ("failure".equalsIgnoreCase(status)) {
                            // Failure response
                            Toast.makeText(MeterReading.this, "Failed to send email", Toast.LENGTH_SHORT).show();
                        } else {
                            // Other error response
                            Toast.makeText(MeterReading.this, "Error: " + status, Toast.LENGTH_SHORT).show();
                        }
                    } catch (JSONException e) {
                        // Error occurred while parsing JSON
                        e.printStackTrace();
                        Toast.makeText(MeterReading.this, "Error: Unable to parse response", Toast.LENGTH_SHORT).show();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String message = ""; // Initialize message as blank

                    // Handle specific VolleyError instances
                    if (error instanceof TimeoutError) {
                        message = "Request timed out";
                    } else if (error instanceof NoConnectionError) {
                        message = "No internet connection";
                    } else if (error instanceof ServerError) {
                        message = "Server error";
                    } else if (error instanceof NetworkError) {
                        message = "Network error";
                    } else {
                        message = "Reading processed failed. Please try again."; // Fallback for any other error types
                    }

                    // Display Toast message based on the error response
                    Toast.makeText(MeterReading.this, message, Toast.LENGTH_SHORT).show();
                }
            }) {
                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<>();
                    params.put("r_id", r_id);
                    params.put("past_reading", pastReading);
                    params.put("present_reading", presentReading);
                    params.put("type_of_connection", type_of_connection);
                    params.put("finalResult", finalResultValueString);
                    params.put("price", String.valueOf(finalRate));
                    params.put("email", email);
                    params.put("con_firstname", con_firstname);
                    params.put("con_lastname", con_lastname);
                    params.put("suffix", suffix);
                    params.put("readers_firstname", readers_firstname);
                    params.put("readers_lastname", readers_lastname);
                    params.put("barangay", barangay);
                    return params;
                }
            };

            // Add the request to the RequestQueue
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);

        }
    }

}