package com.example.waterworksapp;

public class History_Bill_Call {
    private String readingId;
    private String past;
    private String present;
    private String m3;
    private String price;
    private String status;
    private String date;
    private String dueDate;

    public History_Bill_Call(String readingId, String past, String present, String m3, String price, String status, String date,String dueDate) {
        this.readingId = readingId;
        this.past = past;
        this.present = present;
        this.m3 = m3;
        this.price = price;
        this.status = status;
        this.date = date;
        this.dueDate = dueDate;
    }

    public String getReadingId() {
        return readingId;
    }

    public String getPast() {
        return past;
    }

    public String getPresent() {
        return present;
    }

    public String getM3() {
        return m3;
    }

    public String getPrice() {
        return price;
    }

    public String getStatus() {
        return status;
    }

    public String getDate() {
        return date;
    }

    public String getDueDate() {
        return dueDate;
    }
}
