package com.example.waterworksapp;

import android.content.Context;

import android.content.DialogInterface;
import android.content.Intent;
import android.text.Html;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import java.util.Collections;
import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Notification_History_Adapter extends RecyclerView.Adapter<Notification_History_Adapter.UsersHolder> {

    Context context;
    List<Notification_History_Call> notifList;

    public Notification_History_Adapter(Context context, List<Notification_History_Call> notifList) {
        this.context = context;
        this.notifList = notifList;
    }

    @NonNull
    @Override
    public UsersHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View UserLayout = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_history_card,parent,false);
        return new UsersHolder(UserLayout);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersHolder holder, int position) {
        // Ensure the list is sorted first
        sortNotificationsByDate(notifList);
        holder.notif_card.setClickable(true);
        Notification_History_Call user = notifList.get(position);

        // Extract data for this position
        String notifId = user.getNotif_id();
        String contentTitle = user.getContent_title();
        String contentText = user.getContent_text();
        String dateTime = user.getDate_time();

        // Define HTML formatting strings
        String bold = "<b>";
        String endBold = "</b>";
        String indent = "<br>"; // HTML entity for line break or space for indentation

        // Format the notification details for individual TextViews
        String formattedTitle = bold + "Title: " + endBold + contentTitle;
        String formattedContent = bold + "Content: " + endBold + contentText;

        // Convert dateTime to 12-hour format
        String formattedDateTime = formatDateTo12HourFormat(dateTime);

        // Bind data to the respective TextViews
        holder.titleTextView.setText(Html.fromHtml(formattedTitle, Html.FROM_HTML_MODE_LEGACY));
        holder.content.setText(Html.fromHtml(formattedContent, Html.FROM_HTML_MODE_LEGACY));
        holder.date_time.setText(Html.fromHtml(bold + formattedDateTime + endBold, Html.FROM_HTML_MODE_LEGACY));

        holder.notif_card.setOnClickListener(v -> {
            Intent intent = null;


            // Log the contentTitle to check its value
            Log.d("ContentTitle", "Content Title: " + contentTitle);
            if (contentTitle != null) {
                Log.d("ContentTitle", "Checking contentTitle for keywords...");

                if (contentTitle.toLowerCase().contains("report action being taken")) {
                    Log.d("ContentTitle", "Matched 'Report Action Being Taken'");
                    intent = new Intent(holder.itemView.getContext(), Report_Problem.class);
                }
                if (contentTitle.toLowerCase().contains("report accepted")) {
                    Log.d("ContentTitle", "Matched 'Report accepted'");
                    intent = new Intent(holder.itemView.getContext(), Report_Problem.class);
                }
                if (contentTitle.toLowerCase().contains("report declined")) {
                    Log.d("ContentTitle", "Matched 'Report declined'");
                    intent = new Intent(holder.itemView.getContext(), Report_Problem.class);
                }
                if (contentTitle.toLowerCase().contains("unpaid bills overdue")) {
                    Log.d("ContentTitle", "Matched 'Unpaid Bills overdue'");
                    intent = new Intent(holder.itemView.getContext(), Consumer_Violation.class);
                }
                if (contentTitle.toLowerCase().contains("disconnection notice")) {
                    Log.d("ContentTitle", "Matched 'Disconnection Notice'");
                    intent = new Intent(holder.itemView.getContext(), Consumer_Violation.class);
                }
                if (contentTitle.toLowerCase().contains("unpaid bills due today")) {
                    Log.d("ContentTitle", "Matched 'Unpaid Bills Due Today'");
                    intent = new Intent(holder.itemView.getContext(), ConsumerHome.class);
                }
                if (contentTitle.toLowerCase().contains("unpaid bills reminder")) {
                    Log.d("ContentTitle", "Matched 'Unpaid Bills Reminder'");
                    intent = new Intent(holder.itemView.getContext(), ConsumerHome.class);
                }
            }

// If a valid intent is created, start the activity
            if (intent != null) {
                holder.itemView.getContext().startActivity(intent);
            } else {
                Log.d("ContentTitle", "No matching keyword found, intent not set.");
            }

        });

    }

    // Method to sort notifications by date, closest to today's date first
    private void sortNotificationsByDate(List<Notification_History_Call> notifList) {
        // Get current date for comparison (today's date without the time part)
        SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
        Date currentDate = new Date(); // Current date and time
        String currentDateString = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(currentDate); // Format today to compare

        // Sort the list based on date
        Collections.sort(notifList, (notif1, notif2) -> {
            try {
                // Parse both notification dates
                Date date1 = inputFormat.parse(notif1.getDate_time());
                Date date2 = inputFormat.parse(notif2.getDate_time());

                // Compare dates and find the closest to currentDate
                long diff1 = Math.abs(date1.getTime() - currentDate.getTime());
                long diff2 = Math.abs(date2.getTime() - currentDate.getTime());

                return Long.compare(diff1, diff2); // Ascending order, closest date first
            } catch (Exception e) {
                e.printStackTrace();
                return 0; // If there's an error parsing the dates, keep the original order
            }
        });
    }

    // Convert dateTime to 12-hour format
    private String formatDateTo12HourFormat(String dateTime) {
        try {
            // Parse the input dateTime (assuming it's in the format "yyyy-MM-dd HH:mm:ss" or similar)
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            Date date = inputFormat.parse(dateTime);

            // Format the date to the desired format: "MMMM dd, yyyy h:mm a"
            SimpleDateFormat outputFormat = new SimpleDateFormat("MMMM dd, yyyy h:mm a", Locale.getDefault());
            return outputFormat.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            return "Invalid date"; // Return a default error message if parsing fails
        }
    }

    @Override
    public int getItemCount() {
        return notifList.size();
    }

    public class UsersHolder extends RecyclerView.ViewHolder {
        TextView titleTextView, content, date_time;
        LinearLayout layout;
        CardView notif_card;

        public UsersHolder(@NonNull View itemView) {
            super(itemView);
            // Find all the required views
            titleTextView = itemView.findViewById(R.id.title_txt);
            content = itemView.findViewById(R.id.content);
            date_time = itemView.findViewById(R.id.date_time);
            layout = itemView.findViewById(R.id.notif_layout);
            notif_card = itemView.findViewById(R.id.notif_card);
        }
    }
}