package com.example.waterworksapp;

import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.text.Html;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class Report_Problem_Adapter extends RecyclerView.Adapter<Report_Problem_Adapter.UsersHolder> {

    Context context;
    List<Report_Problem_Class> usersList;

    public Report_Problem_Adapter(Context context, List<Report_Problem_Class> usersList) {
        this.context = context;
        this.usersList = usersList;
    }

    @NonNull
    @Override
    public UsersHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View UserLayout = LayoutInflater.from(parent.getContext()).inflate(R.layout.reports_card, parent, false);
        return new UsersHolder(UserLayout);
    }

    @Override
    public void onBindViewHolder(@NonNull UsersHolder holder, int position) {
        Report_Problem_Class user = usersList.get(position);
        holder.bind(user);
    }

    @Override
    public int getItemCount() {
        return usersList.size();
    }

    public class UsersHolder extends RecyclerView.ViewHolder {
        TextView description_report,label_picture,date_of_visit;
        Button view_button;
        ConstraintLayout Layout;
        Report_Problem_Class reportProblem;
        ImageView capturedImageView;

        public UsersHolder(@NonNull View itemView) {
            super(itemView);
            description_report = itemView.findViewById(R.id.description_report);
            label_picture = itemView.findViewById(R.id.label_picture);
            date_of_visit = itemView.findViewById(R.id.date_of_visit);
            Layout = itemView.findViewById(R.id.reports_card);
            capturedImageView = itemView.findViewById(R.id.capturedImageView);

            description_report.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showDetailDialog(reportProblem);
                }
            });
        }

        // Method to bind data to the ViewHolder
        public void bind(Report_Problem_Class reportProblem) {
            this.reportProblem = reportProblem;
            String bold = "<b>";
            String endBold = "</b>";
            String indent = "<br>"; // HTML entity for space repeated for indentation

            description_report.setText(Html.fromHtml(bold + "Description" + endBold + indent + reportProblem.getDescription()));
        }

        private void showDetailDialog(Report_Problem_Class reportProblem) {
            // Inflate the dialog layout
            LayoutInflater inflater = LayoutInflater.from(itemView.getContext());
            View dialogView = inflater.inflate(R.layout.dialog_report_detail, null);

            // Find views in the dialog layout
            TextView detailDate = dialogView.findViewById(R.id.detail_date);
            TextView detailStatusDesc = dialogView.findViewById(R.id.detail_status_desc);
            TextView detail_status = dialogView.findViewById(R.id.detail_status);
            TextView date_of_visit = dialogView.findViewById(R.id.date_of_visit);
            TextView label_picture = dialogView.findViewById(R.id.label_picture);
            ImageView capturedImageView = dialogView.findViewById(R.id.capturedImageView);

            // Set data to the dialog views
            String bold = "<b>";
            String endBold = "</b>";
            String indent = "<br>";

            detail_status.setText(Html.fromHtml(bold + "Status" + endBold + indent + reportProblem.getStatus(), Html.FROM_HTML_MODE_LEGACY));
            detailDate.setText(Html.fromHtml(bold + "Report Date & Time" + endBold + indent + reportProblem.getReport_time(), Html.FROM_HTML_MODE_LEGACY));
            detailStatusDesc.setText(Html.fromHtml(bold + "Status Description" + endBold + indent + reportProblem.getStatus_desc(), Html.FROM_HTML_MODE_LEGACY));
            String dateOfVisit = reportProblem.getDateOfVisit();
            if ("0000-00-00".equals(dateOfVisit)) {
                date_of_visit.setVisibility(View.GONE);
            } else {
                date_of_visit.setVisibility(View.VISIBLE);
                date_of_visit.setText(Html.fromHtml(bold + "Date of Visit" + endBold + indent + dateOfVisit, Html.FROM_HTML_MODE_LEGACY));
            }

            // Set image if available
            Bitmap bitmap = reportProblem.getPicture();
            if (bitmap != null) {
                capturedImageView.setImageBitmap(bitmap);
                label_picture.setVisibility(View.GONE);

            } else {
                label_picture.setVisibility(View.VISIBLE); // Placeholder image if no picture is available
            }

            // Create and show the dialog
            AlertDialog.Builder builder = new AlertDialog.Builder(itemView.getContext());
            builder.setTitle("Report Details")
                    .setView(dialogView)
                    .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            dialog.dismiss();
                        }
                    })
                    .create()
                    .show();
        }
    }
}
